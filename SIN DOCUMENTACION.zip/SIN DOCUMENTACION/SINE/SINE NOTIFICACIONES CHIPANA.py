import sys
import os
import time
import threading
from datetime import date, datetime
import pandas as pd
import logging
 
# Selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
 
# Tkinter
import tkinter as tk
from tkinter import ttk, messagebox
 
# ============================================================
# VARIABLES GLOBALES DE CONTROL
# ============================================================
is_paused = False
is_cancelled = False

class LazyFileHandler(logging.Handler):
    #Crea el archivo de log solo cuando se registra un error
    def __init__(self, filename, encoding="utf-8"):
        super().__init__()
        self.filename = filename
        self.encoding = encoding

    def emit(self, record):
        try:
            message = self.format(record)
            with open(self.filename, "a", encoding=self.encoding) as log_file:
                log_file.write(message + "\n")
        except Exception:
            self.handleError(record)

# Configurar logging para errores
def setup_logging(path):
    log_file = os.path.join(path, f"error_log_{date.today().strftime('%d%m%Y_%H%M%S')}.txt")
    logger = logging.getLogger()
    logger.setLevel(logging.ERROR)
    logger.handlers.clear()

    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

    file_handler = LazyFileHandler(log_file)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    return log_file

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
 
# ============================================================
# UI
# ============================================================
class App:
    def __init__(self, root, fecha_defecto):
        self.root = root
        self.root.title("SEGUIMIENTO SINE")
        self.root.resizable(False, False)
 
        self.values = {}
 
        frame = ttk.Frame(root, padding=12)
        frame.grid()
 
        # FECHAS
        ttk.Label(frame, text="Fecha inicio:").grid(row=0, column=0, sticky='w')
        self.entry_ini = ttk.Entry(frame, width=18)
        self.entry_ini.grid(row=0, column=1, padx=5, pady=5)
        self.entry_ini.insert(0, fecha_defecto)
 
        ttk.Label(frame, text="Fecha fin:").grid(row=1, column=0, sticky='w')
        self.entry_fin = ttk.Entry(frame, width=18)
        self.entry_fin.grid(row=1, column=1, padx=5, pady=5)
        self.entry_fin.insert(0, fecha_defecto)
 
        # Barra principal
        self.progress = ttk.Progressbar(frame, length=260, mode='determinate')
        self.progress.grid(row=2, column=0, columnspan=2, pady=10)
 
        self.label_estado = ttk.Label(frame, text="Esperando inicio...")
        self.label_estado.grid(row=3, column=0, columnspan=2)
 
        # NUEVA barra RESPONSABLE
        self.progress_resp = ttk.Progressbar(frame, length=260, mode='determinate')
        self.progress_resp.grid(row=4, column=0, columnspan=2, pady=5)
 
        self.label_resp = ttk.Label(frame, text="Responsables: 0%")
        self.label_resp.grid(row=5, column=0, columnspan=2)
 
        # Botones
        ttk.Button(frame, text="INICIAR", command=self.start).grid(row=6, column=0, sticky="ew", pady=2)
        # Tecla Enter -> iniciar
        root.bind('<Return>', lambda e: self.start())

        ttk.Button(frame, text="PAUSAR", command=self.pause).grid(row=6, column=1, sticky="ew", pady=2)
        ttk.Button(frame, text="CONTINUAR", command=self.resume).grid(row=7, column=0, sticky="ew", pady=2)
        ttk.Button(frame, text="CANCELAR", command=self.cancel).grid(row=7, column=1, sticky="ew", pady=2)
 
    def start(self):
        global is_cancelled
        is_cancelled = False
 
        # VALIDACIÓN
        
        self.values["-fecinico-"] = self.entry_ini.get().strip()
        self.values["-fecfin-"] = self.entry_fin.get().strip()
 
        self.label_estado.config(text="Iniciando extracción de datos...")
 
        threading.Thread(target=main, args=(self,), daemon=True).start()
 
    def pause(self):
        global is_paused
        is_paused = True
        self.label_estado.config(text=" Pausado")
 
    def resume(self):
        global is_paused
        is_paused = False
        self.label_estado.config(text=" En ejecución")
 
    def cancel(self):
        global is_cancelled
        is_cancelled = True
        self.label_estado.config(text=" Cancelando...")
 
    def update_progress(self, actual, total):
        if total == 0:
            return
        porcentaje = int((actual / total) * 100)
        self.progress["value"] = porcentaje
        self.label_estado.config(text=f"Procesando... {porcentaje}%")
        self.root.update_idletasks()
    
    def update_progress_resp(self, actual, total):
        if total == 0:
            return
        porcentaje = int((actual / total) * 100)
        self.progress_resp["value"] = porcentaje
        self.label_resp.config(text=f"Responsables...{porcentaje}%")
        self.root.update_idletasks()
 
# ============================================================
# FUNCIONES AUXILIARES
# ============================================================
def click_xpath(driver, wait, xpath):
    wait.until(EC.element_to_be_clickable((By.XPATH, xpath))).click()

def click_with_retry(driver, xpath, max_retries=5):
    for attempt in range(max_retries):
        try:
            element = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, xpath)))
            element.click()
            return True
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            time.sleep(10)
    return False

def espera_de_elementos(driver, locator_type, locator_value, max_retries=5):
    for attempt in range(max_retries):
        try:
            return WebDriverWait(driver, 5).until(EC.presence_of_element_located((locator_type, locator_value)))
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            time.sleep(1)

def obtener_paginas(driver):
    try:
        paginador = driver.find_element(By.CSS_SELECTOR, "#tblSeguimientoPedido_paginate span")
        botones = paginador.find_elements(By.TAG_NAME, "a")
        return len(botones) if botones else 1
    except:
        return 1

# Función para obtener responsables
def obtener_responsable(driver, wait, nro_pedido):
    try:
       
        try:
            btn_limpiar = wait.until(EC.element_to_be_clickable((By.ID, "btnLimpiar")))
            btn_limpiar.click()
        #time.sleep(1)
        except:
            pass
        # Input
        input_pedido = wait.until(EC.presence_of_element_located((By.ID, "nroPedido")))
 
        # Limpieza fuerte
        driver.execute_script("arguments[0].value = '';", input_pedido)
        #time.sleep(0.5)
 
        input_pedido.send_keys(nro_pedido)
 
        # Quitar foco
        driver.execute_script("arguments[0].blur();", input_pedido)
 
        # Consultar
        driver.find_element(By.ID, "btnConsultar").click()
 
        #time.sleep(0.5)
 
        # Click primer resultado
        primer_link = wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, "#tblSeguimientoPedido tbody tr td a")
        ))
        primer_link.click()
 
        # Esperar tabla
        wait.until(EC.presence_of_element_located((By.ID, "tblListaSeguimientos")))
 
        filas = driver.find_elements(By.CSS_SELECTOR, "#tblListaSeguimientos tbody tr")
 
        if not filas:
            # RETORNAR CORRECTAMENTE
            btn_retornar = wait.until(EC.element_to_be_clickable((By.ID, "btnRetornar")))
            btn_retornar.click()
            wait.until(EC.presence_of_element_located((By.ID, "nroPedido")))
            return "SIN DATOS"
 
        ultima = filas[-1]
        tds = ultima.find_elements(By.TAG_NAME, "td")
 
        responsable = tds[2].text if len(tds) >= 3 else "SIN RESPONSABLE"
 
        # RETORNAR CORRECTAMENTE
        btn_retornar = wait.until(EC.element_to_be_clickable((By.ID, "btnRetornar")))
        btn_retornar.click()
 
        wait.until(EC.presence_of_element_located((By.ID, "nroPedido")))
        #time.sleep(0.5)
 
        return responsable
 
    except Exception as e:
        logging.error(f"Error en pedido {nro_pedido}: {e}")
 
        try:
            btn_retornar = driver.find_element(By.ID, "btnRetornar")
            btn_retornar.click()
            #time.sleep(1)
        except:
            pass
 
        return "ERROR"
      
# ============================================================
# MAIN
# ============================================================
def main(app):
    global is_paused, is_cancelled
 
    values = app.values
    path = os.getcwd()
    
    # Configurar logging
    log_file = setup_logging(path)
 
    chrome_options = Options()
    # Segundo plano
    chrome_options.add_argument("--headless=new")
 
    driver_path = os.path.join(path,"chromedriver.exe")
    if not os.path.exists(driver_path):
        messagebox.showerror("Error",f"No se encontró Chromedriver en:\n{driver_path}")
        return
    service = Service(driver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)
 
    wait = WebDriverWait(driver, 20)
    temp = []
 
    try:

        # LOGIN
        driver.get("http://intranet/cl-at-iamenu/menuS01Alias")

        # Leer credenciales (asegúrate de que existan los archivos)
        with open(os.path.join(path, "usuario.txt"), "r", encoding="utf-8") as f:
            usuario_intranet = f.read().strip()
        with open(os.path.join(path, "contraseña.txt"), "r", encoding="utf-8") as f:
            contrasena_intranet = f.read().strip()

        # Login
        driver.find_element(By.NAME, "cuenta").send_keys(usuario_intranet)
        driver.find_element(By.NAME, "password").send_keys(contrasena_intranet)
        driver.find_element(By.XPATH, "/html/body/table/tbody/tr/td[1]/div[2]/form/table/tbody/tr/td/table[2]/tbody/tr/td/table/tbody/tr[3]/td/input").click()

        # Navegación
        driver.maximize_window()
        time.sleep(3)
        driver.get('http://intranet/cl-at-iamenu/menuS03Alias?accion=invocarPrograma&programa=5:5.52.1&nm=1')
        click_with_retry(driver, "//*[@id='nivel2Cuerpo_10']") #Desplegar "SISTEMA DE NOTIFICACIONES"
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//*[@id='nivel4_5_52_1_23']")))
        click_with_retry(driver, "//*[@id='nivel4_5_52_1_23']")
        espera_de_elementos(driver, By.CSS_SELECTOR, "#iDivApplication > iframe")
        iframe=driver.find_element(By.CSS_SELECTOR, "#iDivApplication > iframe")
        driver.switch_to.frame(iframe)
        driver.switch_to.frame("det")
        click_with_retry(driver, "//select[@id='dependencia']/option[@value='0021                ']")
        click_with_retry(driver, "//select[@id='selTipoProceso']/option[@value='01']")
        driver.find_element(By.XPATH, "//*[@id='fecPedidoDesde']").send_keys(values['-fecinico-'])
        driver.find_element(By.XPATH, "//*[@id='fecPedidoHasta']").send_keys(values['-fecfin-'])
 
        select_doc = Select(driver.find_element(By.ID, "selTipoDocumento"))

        valores_extra = {"80010C", "80023A", "80027D"}
 
        opciones_007 = [
        opt for opt in select_doc.options
        if opt.get_attribute("value").startswith("007")
        or opt.get_attribute("value") in valores_extra
        ]
 
        total_docs = len(opciones_007)
        contador = 0
 
        for opt in opciones_007:
 
            if is_cancelled:
                break
 
            while is_paused:
                time.sleep(1)
 
            select_doc.select_by_value(opt.get_attribute("value"))
            click_with_retry(driver, "//*[@id='btnConsultar']")
 
            paginas = obtener_paginas(driver)
 
            for _ in range(paginas):
 
                if is_cancelled:
                    break
 
                while is_paused:
                    time.sleep(1)
 
                filas = driver.find_elements(By.CSS_SELECTOR, "#tblSeguimientoPedido tbody tr")
 
                for row in filas:
                    tds = row.find_elements(By.TAG_NAME, "td")
                    if len(tds) >= 7:
                        temp.append({
                            'Nro Pedido': tds[0].text,
                            'Dependencia': tds[1].text,
                            'Tipo Documento': tds[2].text,
                            'Area Solicitante': tds[3].text,
                            'Estado': tds[4].text,
                            'Cantidad': tds[5].text,
                            'Fecha pedido': tds[6].text
                        })
 
                next_btn = driver.find_element(By.ID, "tblSeguimientoPedido_next")
                if "disabled" not in next_btn.get_attribute("class"):
                    next_btn.click()
 
            contador += 1
            app.update_progress(contador, total_docs)
 
        df = pd.DataFrame(temp)
        df = df[~df["Estado"].isin(["PUBLICADO", "REVERTIDO"])]
        df = df[df["Area Solicitante"].str.contains("COBRANZA", na=False)]

        # ============================================
        # BLOQUE RESPONSABLES
        # ============================================
        responsables = []
        total_filas = len(df)
 
        for i, nro in enumerate(df["Nro Pedido"], start=1):
 
            if is_cancelled:
                break
 
            while is_paused:
                time.sleep(1)
 
            app.label_resp.config(text=f"Buscando responsable {i}/{total_filas}")
 
            resp = obtener_responsable(driver, wait, nro)
            responsables.append(resp)
 
            app.update_progress_resp(i, total_filas)
 
        df["Responsable"] = responsables

        df["Fec_reporte"] = datetime.now()
        # Orden de columnas
        columnas_ordenadas = ["Dependencia","Nro Pedido","Fecha pedido","Tipo Documento","Area Solicitante","Estado","Cantidad","Responsable","Fec_reporte"]
        df = df[columnas_ordenadas]
        # GUARDAR
        out_xlsx = os.path.join(path, "RESULTADOS.xlsx")
        df.to_excel(out_xlsx, index=False)
 
        if not is_cancelled:
            messagebox.showinfo("Proceso finalizado","Extracción de datos completado correctamente")
 
    except Exception as e:
        # Capturar cualquier error y guardarlo en log
        error_message = f"Error durante la ejecución: {str(e)}\nTipo de error: {type(e).__name__}"
        logging.error(error_message, exc_info=True)
        messagebox.showerror("Error en el proceso", f"Se ha producido un error:\n{error_message}\n\nVerifique el archivo de log para más detalles.")
    
    finally:
        driver.quit()
 
# ============================================================
# EJECUCIÓN
# ============================================================
if __name__ == "__main__":
    root = tk.Tk()
    try:
        root.iconbitmap(resource_path("SINE.ico"))
    except:
        pass
    fecha_defecto = date.today().strftime('%d/%m/%Y')
    app = App(root, fecha_defecto)
    root.mainloop()