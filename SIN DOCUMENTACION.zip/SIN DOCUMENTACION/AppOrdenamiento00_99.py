import os
import shutil
import time
import pandas as pd
import tkinter as tk
from tkinter import Tk, Label, Button, filedialog, messagebox
from tkinter import ttk
from datetime import datetime
import win32com.client as win32
import threading
import json
import re

# Variable global para detener el proceso
detener_proceso = False

# Nombre del archivo para rastrear archivos procesados
archivo_procesados = "procesados.txt"


def guardar_estado_proceso(directorio, archivos_pendientes):
    """Guardar el estado del proceso en un archivo JSON."""
    estado_path = os.path.join(directorio, "estado_proceso.json")
    with open(estado_path, "w") as f:
        json.dump(archivos_pendientes, f)
    print(f"Estado del proceso guardado en {estado_path}")

def cargar_estado_proceso(directorio):
    """Cargar el estado del proceso desde un archivo JSON."""
    estado_path = os.path.join(directorio, "estado_proceso.json")
    if os.path.exists(estado_path):
        with open(estado_path, "r") as f:
            return json.load(f)
    return None

def normalizar_nombre_archivo(nombre_archivo):
    """Normalizar la extensión a .pdf y eliminar duplicados como .pdf.PDF, .PDF, .pdf.pdf."""
    if not nombre_archivo.lower().endswith(".pdf"):
        return nombre_archivo

    partes = nombre_archivo.split('.')
    idx = len(partes) - 1
    while idx >= 0 and partes[idx].lower() == "pdf":
        idx -= 1

    nombre_base = ".".join(partes[:idx+1]) if idx >= 0 else partes[0]
    return f"{nombre_base}.pdf"


def es_archivo_duplicado(nombre_archivo):
    """Detectar si un archivo final contiene un sufijo de duplicado como _1, _2, etc."""
    nombre_sin_ext, ext = os.path.splitext(nombre_archivo)
    if ext.lower() != ".pdf":
        return False
    partes = nombre_sin_ext.rsplit("_", 1)
    return len(partes) == 2 and partes[1].isdigit()


def es_archivo_ordenable(archivo):
    """Validar que el nombre siga el patrón 'RUC_#campo' o 'RUC-#campo' con al menos 5 dígitos en el segundo campo."""
    nombre_sin_ext = os.path.splitext(archivo)[0]
    partes = [parte for parte in re.split(r'[_-]', nombre_sin_ext) if parte != ""]

    if len(partes) < 2:
        return False

    segundo_campo = partes[1]
    if not segundo_campo.isdigit():
        return False

    return len(segundo_campo) >= 5


def guardar_resultados_excel(excel_file, archivos_por_carpeta):
    """Guardar los resultados parciales en un archivo Excel."""
    data_detalles = []

    # Leer datos existentes si el archivo ya exista
    if os.path.exists(excel_file):
        df_existente = pd.read_excel(excel_file, sheet_name="Detalles de Archivos", dtype={"Carpeta": str})
        if "Duplicado" not in df_existente.columns:
            df_existente["Duplicado"] = ""
        data_detalles.extend(df_existente.to_dict("records"))

    # Agregar nuevos datos
    for carpeta, archivos in archivos_por_carpeta.items():
        for archivo_info in archivos:
            # Asegurar que la carpeta se guarde en formato de dos dígitos como texto
            data_detalles.append({
                "Carpeta": str(carpeta).zfill(2),
                "Nombre de archivo": archivo_info["Nombre de archivo"],
                "Duplicado": archivo_info.get("Duplicado", "")
            })

    # Guardar en el archivo Excel
    df_detalles = pd.DataFrame(data_detalles)
    df_detalles = df_detalles[["Carpeta", "Nombre de archivo", "Duplicado"]]
    with pd.ExcelWriter(excel_file, engine="openpyxl") as writer:
        df_detalles.to_excel(writer, index=False, sheet_name="Detalles de Archivos")
        worksheet = writer.sheets["Detalles de Archivos"]
        worksheet.column_dimensions["A"].width = 8
        worksheet.column_dimensions["B"].width = 32
        worksheet.column_dimensions["C"].width = 10


def organizar_pdfs(ruta_directorio, progress_var=None, root=None, progress_label=None):
    global detener_proceso
    if not os.path.exists(ruta_directorio):
        print("El directorio no existe.")
        return

    inicio = time.time()

    # Leer estado previo si existe
    archivos_pendientes = cargar_estado_proceso(ruta_directorio)
    if archivos_pendientes is None:
        # Si no hay estado previo, identificar los archivos pendientes desde el inicio
        archivos_totales = []
        for archivo in os.listdir(ruta_directorio):
            if archivo.lower().endswith(".pdf"):
                archivo_normalizado = normalizar_nombre_archivo(archivo)
                if es_archivo_ordenable(archivo_normalizado):
                    archivos_totales.append(archivo)

        # Restricción de solo reconocer la estructura #RUC_#RC
        archivos_pendientes = archivos_totales

    total_archivos = len(archivos_pendientes)
    procesados_en_esta_ejecucion = 0
    archivos_por_carpeta = {}
    duplicados = 0

    try:
        for archivo in archivos_pendientes:
            if not es_archivo_ordenable(archivo):
                continue
            if detener_proceso:
                # Guardar los archivos restantes al detener el proceso
                pendientes_restantes = archivos_pendientes[procesados_en_esta_ejecucion:]
                guardar_estado_proceso(ruta_directorio, pendientes_restantes)
                print("Proceso detenido por el usuario.")
                messagebox.showinfo("Proceso detenido", "El proceso fue detenido y los resultados parciales se guardaron.")
                break

            archivo_normalizado = normalizar_nombre_archivo(archivo)
            ruta_origen = os.path.join(ruta_directorio, archivo)
            es_duplicado = False
            if archivo_normalizado != archivo:
                ruta_normalizada = os.path.join(ruta_directorio, archivo_normalizado)
                mismo_archivo = os.path.normcase(os.path.abspath(ruta_origen)) == os.path.normcase(os.path.abspath(ruta_normalizada))

                nombre_original_sin_ext, ext_original = os.path.splitext(archivo)
                nombre_normalizado_sin_ext, ext_normalizado = os.path.splitext(archivo_normalizado)
                solo_correccion_extension = (
                    (nombre_original_sin_ext == nombre_normalizado_sin_ext or
                     nombre_original_sin_ext.lower() == nombre_normalizado_sin_ext.lower()) and
                    ext_original.lower() != ext_normalizado.lower()
                )

                if os.path.exists(ruta_normalizada) and not mismo_archivo:
                    base, _ = os.path.splitext(archivo_normalizado)
                    contador = 1
                    while True:
                        nombre_alterno = f"{base}_{contador}.pdf"
                        ruta_alterno = os.path.join(ruta_directorio, nombre_alterno)
                        if not os.path.exists(ruta_alterno):
                            archivo_normalizado = nombre_alterno
                            ruta_normalizada = ruta_alterno
                            if not solo_correccion_extension:
                                es_duplicado = True
                            break
                        contador += 1

                os.rename(ruta_origen, ruta_normalizada)
                archivo = archivo_normalizado
                ruta_origen = ruta_normalizada

            nombre = re.split(r'[_-]', archivo)
            if 5 <= len(nombre[0]) <= 11: #Verifica que el RUC tenga entre 5 y 11 dígitos
                ruc = nombre[0]
                ultimos_digitos_ruc = ruc[-2:].zfill(2)  # Siempre asegurar dos dígitos
                carpeta_destino = os.path.join(ruta_directorio, ultimos_digitos_ruc)

                # Crear carpeta si no existe
                if not os.path.exists(carpeta_destino):
                    os.makedirs(carpeta_destino)

                ruta_destino = os.path.join(carpeta_destino, archivo)
                if os.path.exists(ruta_destino):
                    base, _ = os.path.splitext(archivo)
                    contador = 1
                    while True:
                        nombre_alterno = f"{base}_{contador}.pdf"
                        ruta_destino = os.path.join(carpeta_destino, nombre_alterno)
                        if not os.path.exists(ruta_destino):
                            archivo = nombre_alterno
                            es_duplicado = True
                            break
                        contador += 1

                shutil.move(ruta_origen, ruta_destino)

                if ultimos_digitos_ruc not in archivos_por_carpeta:
                    archivos_por_carpeta[ultimos_digitos_ruc] = []
                archivos_por_carpeta[ultimos_digitos_ruc].append({
                    "Nombre de archivo": archivo,
                    "Duplicado": "SI" if es_duplicado else ""
                })
                if es_duplicado:
                    duplicados += 1

                procesados_en_esta_ejecucion += 1
                if total_archivos > 0:
                    progreso = (procesados_en_esta_ejecucion / total_archivos) * 100
                else:
                    progreso = 0
                print(f"Progreso: {progreso:.2f}% - Archivos procesados: {procesados_en_esta_ejecucion}/{total_archivos}")
                if progress_var is not None:
                    progress_var.set(progreso)
                if progress_label is not None:
                    progress_label.config(text=f"Progreso: {progreso:.0f}%")
                if root is not None:
                    root.update_idletasks()

        # Guardar resultados parciales en el archivo Excel
        excel_file = os.path.join(ruta_directorio, "Resultado_Data_Ordenada.xlsx")
        guardar_resultados_excel(excel_file, archivos_por_carpeta)

        # Calcular tiempos
        fin = time.time()
        tiempo_total = fin - inicio

        # Si el proceso termina, eliminar el archivo de estado
        if not detener_proceso:
            estado_path = os.path.join(ruta_directorio, "estado_proceso.json")
            if os.path.exists(estado_path):
                os.remove(estado_path)

            if progress_var is not None:
                progress_var.set(100)
            if progress_label is not None:
                progress_label.config(text="Progreso: 100%")
            if root is not None:
                root.update_idletasks()

            messagebox.showinfo(
                "Resumen",
                f"EL PROCESO HA FINALIZADO EXITOSAMENTE!\n"
                f"Total de archivos procesados: {procesados_en_esta_ejecucion}\n"
                f"Número duplicados: {duplicados}\n"
                f"Tiempo total: {tiempo_total:.2f} segundos"
            )

    except Exception as e:
        print(f"Error durante el proceso: {e}")

def iniciar_interfaz():
    global detener_proceso
    detener_proceso = False

    # Ventana principal
    root = Tk()
    root.title("Organizador de Archivos PDF")
    root.geometry("600x550")
    root.resizable(False, False)
    root.configure(bg="#f5f5f5")

    # Etiqueta de título
    titulo = Label(root, text="Organizador de Archivos PDF", font=("Arial", 16, "bold"), bg="#4caf50", fg="white", pady=10)
    titulo.pack(fill="x")

    Label(root, text="", bg="#f5f5f5").pack()

    label_instruccion = Label(root, text="Seleccione el directorio base para organizar los archivos PDF\n"
                                         "y presione 'Continuar' para iniciar el proceso.",
                              font=("Arial", 12), bg="#f5f5f5", fg="#333")
    label_instruccion.pack(pady=10)

    def seleccionar_directorio():
        directorio = filedialog.askdirectory()
        if directorio:
            print(f"Directorio seleccionado: {directorio}")
            label_directorio.config(text=f"Directorio: {directorio}")
            boton_continuar.config(state="normal")
        else:
            label_directorio.config(text="No se ha seleccionado ningún directorio.")

    label_directorio = Label(root, text="No se ha seleccionado ningún directorio.", font=("Arial", 10), bg="#f5f5f5", fg="#555")
    label_directorio.pack(pady=10)

    boton_seleccionar = Button(root, text="Seleccionar Directorio", command=seleccionar_directorio,
                               font=("Arial", 12), bg="#2196f3", fg="white", pady=5, padx=10)
    boton_seleccionar.pack(pady=10)

    boton_continuar = Button(root, text="Continuar", font=("Arial", 12),
                             bg="#4caf50", fg="white", pady=5, padx=10, state="disabled")
    boton_continuar.pack(pady=20)

    def detener_proceso_func():
        global detener_proceso
        detener_proceso = True
        boton_detener.config(state="disabled")

    boton_detener = Button(root, text="Detener", command=detener_proceso_func, font=("Arial", 12),
                           bg="#f44336", fg="white", pady=5, padx=10, state="disabled")
    boton_detener.pack(pady=10)

    Label(root, text="", bg="#f5f5f5").pack()

    label_progreso = Label(root, text="Progreso: 0%", font=("Arial", 10), bg="#f5f5f5", fg="#555")
    label_progreso.pack(pady=(10, 0))

    progress_var = tk.DoubleVar()
    progress_bar = ttk.Progressbar(root, variable=progress_var, maximum=100, length=400)
    progress_bar.pack(pady=(5, 10), padx=20)

    def actualizar_progreso(porcentaje):
        progress_var.set(porcentaje)
        label_progreso.config(text=f"Progreso: {porcentaje:.0f}%")
        if root is not None:
            root.update_idletasks()

    Label(root, text="", bg="#f5f5f5").pack()

    def continuar_proceso_actualizado():
        global detener_proceso
        detener_proceso = False
        directorio = label_directorio.cget("text").replace("Directorio: ", "")
        if os.path.exists(directorio):
            boton_detener.config(state="normal")
            boton_continuar.config(state="disabled")
            boton_seleccionar.config(state="disabled")
            label_progreso.config(text="Progreso: 0%")
            progress_var.set(0)
            threading.Thread(target=lambda: [
                organizar_pdfs(directorio, progress_var, root, label_progreso),
                boton_continuar.config(state="normal"),
                boton_seleccionar.config(state="normal"),
                label_progreso.config(text=f"Progreso: {progress_var.get():.0f}%"),
                progress_var.set(progress_var.get())
            ]).start()
        else:
            messagebox.showerror("Error", "Por favor, seleccione un directorio válido antes de continuar.")

    boton_continuar.config(command=continuar_proceso_actualizado)

    root.mainloop()

# Iniciar la interfaz gráfica
iniciar_interfaz()
