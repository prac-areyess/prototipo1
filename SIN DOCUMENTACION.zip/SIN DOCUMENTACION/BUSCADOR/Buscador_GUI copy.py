import os
import sys
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
from datetime import datetime
import shutil
import time

def formatea_tiempo(segundos):
    segundos = int(segundos)
    if segundos < 60:
        return f"{segundos}s"
    minutos, s = divmod(segundos, 60)
    if minutos < 60:
        return f"{minutos}m {s}s"
    horas, m = divmod(minutos, 60)
    return f"{horas}h {m}m {s}s"

class BuscadorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Buscador de Documentos")
        self.root.geometry("900x700")
        self.root.configure(bg="#f0f0f0")
        
        # Obtener la ruta de la carpeta principal
        if hasattr(sys, 'frozen'):
            self.carpeta_principal = os.path.dirname(sys.executable)
        else:
            self.carpeta_principal = os.path.dirname(os.path.abspath(__file__))
        
        self.archivo_entrada = os.path.join(self.carpeta_principal, "RUC_RC_a_buscar.txt")
        
        # Ruta de red para búsqueda
        self.ruta_red = r"\\fsmir01\data$"
        self.subcarpetas = [self.ruta_red]
        
        # Variables para los Entry widgets de las carpetas
        self.entry_carpetas = []
        self.resultados_actuales = {}
        self.crear_interfaz()
        
    def crear_interfaz(self):
        # Frame superior - Entrada
        frame_superior = ttk.Frame(self.root)
        frame_superior.pack(padx=15, pady=15, fill="x")
        
        ttk.Label(frame_superior, text="Cargar términos desde:", font=("Arial", 10, "bold")).pack(side="left", padx=5)
        
        ttk.Button(frame_superior, text="RUC_RC_a_buscar.txt", command=self.cargar_archivo).pack(side="left", padx=5)
        ttk.Button(frame_superior, text="Buscar", command=self.ejecutar_busqueda).pack(side="left", padx=5)
        
        # Frame de carpetas de búsqueda
        frame_carpetas = ttk.LabelFrame(self.root, text="RUTA DE BÚSQUEDA", padding=10)
        frame_carpetas.pack(padx=15, pady=10, fill="x")
        
        frame_carpeta = ttk.Frame(frame_carpetas)
        frame_carpeta.pack(fill="x", pady=5)
        
        ttk.Label(frame_carpeta, text="Ruta:", width=12, font=("Arial", 9)).pack(side="left", padx=5)
        
        entry = ttk.Entry(frame_carpeta, width=60, font=("Arial", 9))
        entry.pack(side="left", padx=5, fill="x", expand=True)
        entry.insert(0, self.ruta_red)
        self.entry_carpetas.append(entry)
        
        # Frame estado
        self.label_estado = ttk.Label(self.root, text="Listo", foreground="green", font=("Arial", 9))
        self.label_estado.pack(padx=15, pady=5, fill="x")
        
        # Frame de resultados
        frame_resultados = ttk.LabelFrame(self.root, text="RESULTADOS", padding=10)
        frame_resultados.pack(padx=15, pady=10, fill="both", expand=True)
        
        # Scrolled text para mostrar resultados
        self.texto_resultados = scrolledtext.ScrolledText(
            frame_resultados, 
            height=25, 
            width=100,
            font=("Courier New", 9),
            bg="white",
            fg="black"
        )
        self.texto_resultados.pack(fill="both", expand=True)
        self.texto_resultados.bind("<Configure>", self.on_text_configure)
        
        # Frame inferior - Botones de acción
        frame_inferior = ttk.Frame(self.root)
        frame_inferior.pack(padx=15, pady=10, fill="x")
        
        ttk.Button(frame_inferior, text="Copiar ruta seleccionada", command=self.copiar_ruta).pack(side="left", padx=5)
        ttk.Button(frame_inferior, text="Abrir archivo", command=self.abrir_archivo).pack(side="left", padx=5)
        ttk.Button(frame_inferior, text="Limpiar", command=self.limpiar).pack(side="left", padx=5)
        ttk.Button(frame_inferior, text="Guardar resultados", command=self.guardar_resultados).pack(side="left", padx=5)
    
    def cargar_archivo(self):
        """Carga y muestra los números del archivo"""
        if not os.path.exists(self.archivo_entrada):
            messagebox.showerror("Error", f"Archivo no encontrado: {self.archivo_entrada}")
            return
        
        try:
            with open(self.archivo_entrada, 'r', encoding='utf-8') as f:
                contenido = f.read()
            
            self.texto_resultados.delete("1.0", tk.END)
            self.texto_resultados.insert("1.0", contenido)
            self.label_estado.config(text="Archivo cargado", foreground="green")
        except Exception as e:
            messagebox.showerror("Error", f"Error al cargar archivo: {str(e)}")
    
    def ejecutar_busqueda(self):
        """Ejecuta la búsqueda en thread separado"""
        self.label_estado.config(text="Buscando...", foreground="blue")
        self.texto_resultados.delete("1.0", tk.END)
        
        thread = threading.Thread(target=self._busqueda_thread)
        thread.start()
    
    def _busqueda_thread(self):
        """Thread de búsqueda"""
        try:
            # Obtener ruta de búsqueda
            ruta_busqueda = self.entry_carpetas[0].get() if self.entry_carpetas else self.ruta_red
            
            # Verificar acceso a la ruta
            self.root.after(0, lambda: self.label_estado.config(text="Verificando acceso a ruta...", foreground="blue"))
            acceso_ok, mensaje = self.verificar_acceso_ruta(ruta_busqueda)
            
            if not acceso_ok:
                self.root.after(0, lambda: messagebox.showerror("Error de acceso", f"{mensaje}\n\nVerifica que:\n- La ruta es correcta\n- Tienes permisos de acceso\n- La ruta de red está disponible"))
                self.label_estado.config(text="Error: sin acceso a la ruta", foreground="red")
                return
            
            # Leer términos de búsqueda del archivo
            terminos = self.leer_numeros()
            
            if not terminos:
                self.root.after(0, lambda: messagebox.showwarning("Aviso", "No hay términos para buscar"))
                self.label_estado.config(text="Error: sin términos", foreground="red")
                return
            
            # Realizar búsquedas
            resultados = {}
            tiempo_total_inicio = time.time()
            for i, termino in enumerate(terminos, 1):
                tiempo_inicio = time.time()
                tiempo_formateado = formatea_tiempo(int(time.time() - tiempo_inicio))
                self.root.after(0, lambda idx=i, total=len(terminos), term=termino, t=tiempo_formateado: self.label_estado.config(
                    text=f"Término {idx}/{total}: '{term}' | Tiempo: {t} | Archivos: 0",
                    foreground="blue"
                ))
                resultados[termino] = self.buscar_ruc_rc(termino, tiempo_inicio, i, len(terminos))
                tiempo_transcurrido = time.time() - tiempo_inicio
                print(f"Término '{termino}': {len(resultados[termino])} encontrados en {tiempo_transcurrido:.2f}s")
            
            tiempo_total = time.time() - tiempo_total_inicio
            print(f"\nTiempo total de búsqueda: {tiempo_total:.2f}s")
            
            # Contar total de resultados
            total_encontrados = sum(len(v) for v in resultados.values())
            
            # Crear carpeta de resultados si hay coincidencias
            ruta_carpeta = None
            nombre_carpeta = None
            if total_encontrados > 0:
                ruta_carpeta, nombre_carpeta = self.crear_carpeta_resultados()
                
                # Copiar archivos a la carpeta
                for termino in terminos:
                    for resultado in resultados[termino]:
                        self.copiar_archivos_a_carpeta(resultado['ruta'], ruta_carpeta)
            
            # Mostrar en interfaz
            self.root.after(0, self._mostrar_resultados, resultados, terminos, ruta_carpeta, nombre_carpeta)
            
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Error", f"Error en búsqueda: {str(e)}"))
            self.label_estado.config(text="Error", foreground="red")
    
    def leer_numeros(self):
        """Lee términos de búsqueda del archivo (números, texto o mezcla)"""
        terminos = []
        try:
            with open(self.archivo_entrada, 'r', encoding='utf-8') as f:
                lineas = f.readlines()
            
            for linea in lineas:
                linea = linea.strip()
                if linea and not linea.startswith('#'):  # Ignorar líneas vacías y comentarios
                    terminos.append(linea)
        except Exception as e:
            print(f"Error al leer archivo: {str(e)}")
        
        return terminos
    
    def verificar_acceso_ruta(self, ruta):
        """Verifica si se puede acceder a la ruta"""
        try:
            if not os.path.exists(ruta):
                return False, f"Ruta no accesible: {ruta}"
            
            # Intentar listar archivos de la ruta
            test_list = os.listdir(ruta)
            return True, "Acceso OK"
        except PermissionError:
            return False, f"Permiso denegado en: {ruta}"
        except Exception as e:
            return False, f"Error de acceso: {str(e)}"
    
    def buscar_ruc_rc(self, termino_busqueda, tiempo_inicio=None, numero_termino=1, total_terminos=1):
        """Busca un término (número, texto o mezcla) en la ruta de red y todas sus subcarpetas"""
        resultados = []
        contador_archivos = 0
        
        if tiempo_inicio is None:
            tiempo_inicio = time.time()
        
        # Obtener ruta de búsqueda desde Entry widget
        ruta_busqueda = self.entry_carpetas[0].get() if self.entry_carpetas else self.ruta_red
        
        if not os.path.exists(ruta_busqueda):
            return resultados
        
        try:
            for raiz, directorios, archivos in os.walk(ruta_busqueda):
                for archivo in archivos:
                    contador_archivos += 1
                    # Actualizar estado cada 50 archivos procesados
                    if contador_archivos % 50 == 0:
                        tiempo_transcurrido = int(time.time() - tiempo_inicio)
                        tiempo_formateado = formatea_tiempo(tiempo_transcurrido)
                        self.root.after(0, lambda c=contador_archivos, t=tiempo_formateado, term=termino_busqueda, idx=numero_termino, tot=total_terminos: 
                            self.label_estado.config(
                                text=f"Término {idx}/{tot}: '{term}' | Tiempo: {t} | Archivos: {c}",
                                foreground="blue"
                            )
                        )
                        self.root.update()
                    
                    # Búsqueda insensible a mayúsculas/minúsculas
                    if termino_busqueda.lower() in archivo.lower():
                        ruta_completa = os.path.join(raiz, archivo)
                        resultados.append({
                            'archivo': archivo,
                            'ruta': ruta_completa,
                            'subcarpeta': ruta_busqueda
                        })
        except PermissionError:
            print(f"Permiso denegado en: {ruta_busqueda}")
        except Exception as e:
            print(f"Error al buscar en {ruta_busqueda}: {str(e)}")
        
        tiempo_total_busqueda = time.time() - tiempo_inicio
        print(f"Búsqueda de '{termino_busqueda}': {contador_archivos} archivos procesados, {len(resultados)} encontrados ({tiempo_total_busqueda:.2f}s)")
        return resultados
    
    def crear_carpeta_resultados(self):
        """Crea la carpeta con nombre dinámico BUSQUEDA_VVC_USUARIO_FECHA_HORA"""
        ahora = datetime.now()
        nombre_usuario = os.getenv('USERNAME')
        # Formato: BUSQUEDA_VVC_USUARIO_DDMMYYYY_HHMMSS
        nombre_carpeta = f"BUSQUEDA_VVC_{nombre_usuario}_{ahora.day:02d}{ahora.month:02d}{ahora.year}_{ahora.hour:02d}{ahora.minute:02d}{ahora.second:02d}"
        ruta_carpeta = os.path.join(self.carpeta_principal, nombre_carpeta)
        
        # Crear carpeta si no existe
        if not os.path.exists(ruta_carpeta):
            os.makedirs(ruta_carpeta)
        
        return ruta_carpeta, nombre_carpeta
    
    def copiar_archivos_a_carpeta(self, ruta_origen, ruta_carpeta_destino):
        """Copia un archivo a la carpeta de resultados"""
        try:
            if os.path.isfile(ruta_origen):
                nombre_archivo = os.path.basename(ruta_origen)
                ruta_destino = os.path.join(ruta_carpeta_destino, nombre_archivo)
                
                # Si ya existe, agregar número para evitar duplicados
                if os.path.exists(ruta_destino):
                    nombre_base, extensión = os.path.splitext(nombre_archivo)
                    contador = 1
                    while os.path.exists(ruta_destino):
                        nombre_archivo = f"{nombre_base}_{contador}{extensión}"
                        ruta_destino = os.path.join(ruta_carpeta_destino, nombre_archivo)
                        contador += 1
                
                shutil.copy2(ruta_origen, ruta_destino)
                return True
            return False
        except Exception as e:
            print(f"Error copiando {ruta_origen}: {str(e)}")
            return False
    
    def _mostrar_resultados(self, resultados, terminos, ruta_carpeta=None, nombre_carpeta=None):
        """Muestra los resultados en la interfaz"""
        self.texto_resultados.delete("1.0", tk.END)
        self.resultados_actuales = {}
        
        # Guardar rutas en archivo RUTAS_COINCIDENCIAS.txt
        if ruta_carpeta:
            self._guardar_rutas_coincidencias(resultados, ruta_carpeta)
        
        texto = f"{'='*100}\n"
        texto += f"RESULTADO DE BÚSQUEDA DE DOCUMENTOS\n"
        texto += f"Fecha y Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        texto += f"{'='*100}\n\n"
        
        # Mostrar carpeta de resultados si se creó
        if ruta_carpeta and nombre_carpeta:
            texto += f"CARPETA DE RESULTADOS CREADA:\n"
            texto += f"   Nombre: {nombre_carpeta}\n"
            texto += f"   Ruta: {ruta_carpeta}\n"
            texto += f"\n{'='*100}\n\n"
        
        contador_global = 0
        
        for termino in terminos:
            lista_resultados = resultados.get(termino, [])
            
            texto += f"BÚSQUEDA: {termino}\n"
            texto += f"{'-'*100}\n\n"
            
            if lista_resultados:
                texto += f"COINCIDENCIAS: {len(lista_resultados)} encontrada(s)\n\n"
                
                for i, resultado in enumerate(lista_resultados, 1):
                    contador_global += 1
                    nombre_archivo = os.path.basename(resultado['ruta'])
                    
                    self.resultados_actuales[contador_global] = resultado['ruta']
                    
                    texto += f"[{contador_global}] {nombre_archivo}\n"
                    texto += f"    Ruta original: {resultado['ruta']}\n"
                    if ruta_carpeta:
                        texto += f"    Copiado a: {ruta_carpeta}\n"
                    texto += f"\n"
            else:
                texto += f"COINCIDENCIAS: 0 encontrada(s)\n\n"
            
            texto += "\n"
        
        texto += f"{'='*100}\n"
        texto += f"TOTAL DE RESULTADOS: {contador_global}\n"
        texto += f"{'='*100}\n\n"
        
        if ruta_carpeta:
            texto += f"Todos los archivos han sido copiados a: {nombre_carpeta}\n\n"
        
        self.texto_resultados.insert("1.0", texto)
        
        total_encontrados = sum(len(v) for v in resultados.values())
        self.label_estado.config(
            text=f"Búsqueda completada - {total_encontrados} resultado(s) encontrado(s)",
            foreground="green"
        )
    
    def on_text_configure(self, event):
        """Hacer que el texto sea seleccionable"""
        self.texto_resultados.config(state="normal")
    
    def copiar_ruta(self):
        """Copia la ruta seleccionada al portapapeles"""
        try:
            # Obtener texto seleccionado
            sel_start = self.texto_resultados.index("sel.first")
            sel_end = self.texto_resultados.index("sel.last")
            texto_seleccionado = self.texto_resultados.get(sel_start, sel_end).strip()
            
            if not texto_seleccionado:
                messagebox.showwarning("Aviso", "Selecciona una ruta primero")
                return
            
            # Copiar al portapapeles
            self.root.clipboard_clear()
            self.root.clipboard_append(texto_seleccionado)
            
            messagebox.showinfo("Éxito", f"Ruta copiada:\n{texto_seleccionado[:60]}...")
        
        except tk.TclError:
            messagebox.showwarning("Aviso", "Selecciona una ruta del texto")
    
    def abrir_archivo(self):
        """Abre el archivo seleccionado"""
        try:
            # Obtener texto seleccionado
            sel_start = self.texto_resultados.index("sel.first")
            sel_end = self.texto_resultados.index("sel.last")
            ruta_seleccionada = self.texto_resultados.get(sel_start, sel_end).strip()
            
            if not ruta_seleccionada:
                messagebox.showwarning("Aviso", "Selecciona una ruta primero")
                return
            
            # Verificar que sea una ruta válida
            if not os.path.exists(ruta_seleccionada):
                messagebox.showerror("Error", f"Archivo no encontrado:\n{ruta_seleccionada}")
                return
            
            # Abrir archivo
            if sys.platform == "win32":
                os.startfile(ruta_seleccionada)
            
            messagebox.showinfo("Éxito", f"Abriendo archivo...")
        
        except tk.TclError:
            messagebox.showwarning("Aviso", "Selecciona una ruta válida del texto")
        except Exception as e:
            messagebox.showerror("Error", f"Error al abrir archivo: {str(e)}")
    
    def guardar_resultados(self):
        """Información sobre dónde están guardados los resultados"""
        mensaje = "Los resultados están guardados automáticamente en:\n\n"
        mensaje += f"   Ubicación: {self.carpeta_principal}\n\n"
        mensaje += f" Archivo: RUTAS_COINCIDENCIAS.txt\n"
        mensaje += f"   (dentro de la carpeta de resultados)\n\n"
        mensaje += "Nota: Los archivos encontrados también se copian\n"
        mensaje += "automáticamente a esa carpeta."
        messagebox.showinfo("Resultados guardados", mensaje)
    
    def limpiar(self):
        """Limpia los resultados"""
        self.texto_resultados.delete("1.0", tk.END)
        self.label_estado.config(text="Listo", foreground="green")
        self.resultados_actuales = {}
    
    def _guardar_rutas_coincidencias(self, resultados, ruta_carpeta):
        """Guarda las rutas de coincidencias en RUTAS_COINCIDENCIAS.txt"""
        try:
            ruta_archivo = os.path.join(ruta_carpeta, "RUTAS_COINCIDENCIAS.txt")
            
            with open(ruta_archivo, 'w', encoding='utf-8') as f:
                f.write(f"ARCHIVO DE RUTAS DE COINCIDENCIAS\n")
                f.write(f"Fecha y Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"{'='*100}\n\n")
                
                contador = 0
                for termino, lista_resultados in resultados.items():
                    f.write(f"BÚSQUEDA: {termino}\n")
                    f.write(f"{'-'*100}\n\n")
                    
                    if lista_resultados:
                        for resultado in lista_resultados:
                            contador += 1
                            f.write(f"[{contador}] {resultado['ruta']}\n")
                    else:
                        f.write(f"Sin coincidencias\n")
                    
                    f.write(f"\n")
                
                f.write(f"\n{'='*100}\n")
                f.write(f"TOTAL DE COINCIDENCIAS: {contador}\n")
        except Exception as e:
            print(f"Error guardando rutas: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = BuscadorGUI(root)
    root.mainloop()
