import os
import sys
from datetime import datetime

def leer_numeros_busqueda(archivo_txt):
    """Lee los números del archivo de texto"""
    numeros = []
    
    try:
        with open(archivo_txt, 'r', encoding='utf-8') as f:
            lineas = f.readlines()
        
        for linea in lineas:
            linea = linea.strip()
            # Ignorar líneas vacías y comentarios
            if linea and not linea.startswith('#'):
                numeros.append(linea)
        
        return numeros
    
    except FileNotFoundError:
        print(f"ERROR: El archivo '{archivo_txt}' no existe.")
        print("Por favor, crea el archivo RUC_RC_a_buscar.txt en la carpeta principal.")
        input("Presiona ENTER para salir...")
        exit(1)
    except Exception as e:
        print(f"ERROR al leer el archivo: {str(e)}")
        return numeros

def buscar_ruc_rc(numero, subcarpetas, carpeta_principal):
    """Busca un número RUC o RC en todas las subcarpetas"""
    resultados = []
    
    for subcarpeta in subcarpetas:
        ruta_subcarpeta = os.path.join(carpeta_principal, subcarpeta)
        
        if not os.path.exists(ruta_subcarpeta):
            continue
        
        # Recorrer todos los archivos recursivamente
        for raiz, directorios, archivos in os.walk(ruta_subcarpeta):
            for archivo in archivos:
                # Buscar en el nombre del archivo
                if numero.lower() in archivo.lower():
                    ruta_completa = os.path.join(raiz, archivo)
                    resultados.append({
                        'archivo': archivo,
                        'ruta': ruta_completa,
                        'subcarpeta': subcarpeta
                    })
    
    return resultados

def guardar_resultados(archivo_salida, todos_resultados):
    """Guarda los resultados en un archivo de salida"""
    try:
        with open(archivo_salida, 'w', encoding='utf-8') as f:
            f.write("="*100 + "\n")
            f.write(f"RESULTADO DE BÚSQUEDA DE RUC/RC\n")
            f.write(f"Fecha y Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("="*100 + "\n\n")
            
            if todos_resultados:
                for numero, resultados in todos_resultados.items():
                    f.write(f"BÚSQUEDA: {numero}\n")
                    f.write("-"*100 + "\n\n")
                    
                    if resultados:
                        f.write(f"COINCIDENCIAS: {len(resultados)} encontrada(s)\n\n")
                        for i, resultado in enumerate(resultados, 1):
                            # Obtener solo el nombre del archivo
                            nombre_archivo = os.path.basename(resultado['ruta'])
                            
                            f.write(f"{i}. {nombre_archivo}\n")
                            f.write(f"   {resultado['ruta']}\n\n")
                    else:
                        f.write(f"COINCIDENCIAS: 0 encontrada(s)\n\n")
                    
                    f.write("\n")
            else:
                f.write("No se ingresaron números para buscar.\n")
            
            f.write("="*100 + "\n")
        
        return True
    except Exception as e:
        print(f"ERROR al guardar resultados: {str(e)}")
        return False

def main():
    # Obtener la ruta de la carpeta principal
    # Si es ejecutable (.exe), usar el directorio donde está el ejecutable
    # Si es script .py, usar el directorio del script
    
    if hasattr(sys, 'frozen'):  # Si es ejecutable .exe
        carpeta_principal = os.path.dirname(sys.executable)
    else:  # Si es script .py
        carpeta_principal = os.path.dirname(os.path.abspath(__file__))
    
    archivo_entrada = os.path.join(carpeta_principal, "RUC_RC_a_buscar.txt")
    archivo_salida = os.path.join(carpeta_principal, "RUTAS_COINCIDENCIAS.txt")
    
    subcarpetas = [
        "RC COURIER CARITO Y PUBLICACIONES 2016 - 2024 EDUARDO",
        "RC VARIOS EN CAJAS ANTIGUAS"
    ]
    
    print("\n" + "="*100)
    print("="*100)
    print("BUSCADOR DE RUC/RC - COURIER Y PUB.ANTIGUOS".center(100))
    print("="*100)
    print("="*100)
    
    print(f"\nCarpeta Principal: {carpeta_principal}")
    print(f"Archivo de entrada: {archivo_entrada}")
    print(f"Archivo de salida: {archivo_salida}\n")
    
    # Leer números del archivo
    numeros = leer_numeros_busqueda(archivo_entrada)
    
    if not numeros:
        print("No se encontraron números para buscar en el archivo.")
        print(f"Abre el archivo '{archivo_entrada}' e ingresa los números.\n")
        input("Presiona ENTER para salir...")
        return
    
    print(f"Se leyeron {len(numeros)} número(s) para buscar:\n")
    for num in numeros:
        print(f"  - {num}")
    
    print("\n" + "="*100)
    print("INICIANDO BÚSQUEDA...")
    print("="*100 + "\n")
    
    todos_resultados = {}
    total_encontrados = 0
    
    for numero in numeros:
        print(f"Buscando: {numero}...", end=" ", flush=True)
        resultados = buscar_ruc_rc(numero, subcarpetas, carpeta_principal)
        todos_resultados[numero] = resultados
        
        if resultados:
            print(f"[{len(resultados)} coincidencia(s)]")
            total_encontrados += len(resultados)
        else:
            print("[Sin resultados]")
    
    print("\n" + "="*100)
    print(f"BÚSQUEDA COMPLETADA - Total de coincidencias: {total_encontrados}")
    print("="*100 + "\n")
    
    # Mostrar resultados en consola
    for numero, resultados in todos_resultados.items():
        print(f"\n{'='*100}")
        print(f"BÚSQUEDA: {numero}")
        print(f"{'='*100}\n")
        
        if resultados:
            print(f"COINCIDENCIAS: {len(resultados)} encontrada(s)\n")
            for i, resultado in enumerate(resultados, 1):
                # Obtener solo el nombre del archivo
                nombre_archivo = os.path.basename(resultado['ruta'])
                
                print(f"{i}. {nombre_archivo}")
                print(f"   {resultado['ruta']}\n")
        else:
            print("COINCIDENCIAS: 0 encontrada(s)\n")
    
    # Guardar resultados
    print("\n" + "="*100)
    print("Guardando resultados...", end=" ", flush=True)
    
    if guardar_resultados(archivo_salida, todos_resultados):
        print(f"[Completado]\n")
        print(f"Resultados guardados en:\n   {archivo_salida}\n")
    else:
        print("[Error]\n")
    
    print("="*100)
    input("\nPresiona ENTER para salir...")

if __name__ == "__main__":
    main()
