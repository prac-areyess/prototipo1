import os
import sys
import re
import json
import time
import uuid
import sqlite3
import tempfile
import threading
import zipfile
import shutil
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext

try:
    from send2trash import send2trash
except ImportError:
    send2trash = None

DEFAULT_ROOT = r"D:/Data"
DEFAULT_DEST = r"D:\Extraccion"
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(__file__)
PROGRESS_FILE = os.path.join(BASE_DIR, 'Progreso.json')
DB_DIR = os.path.join(BASE_DIR, 'db')
DB_FILE = os.path.join(DB_DIR, 'db.db')

PATTERN = re.compile(r'^(?P<prefix>\d{7,11})_(?P<rc>\d{5,13})\.pdf$', re.I)
DUPLICATE_PATTERN_TEMPLATE = r'^{name}(?:[_\-\s]?0*\d+|\(\s*0*\d+\s*\)){ext}$'

SEVEN_ZIP_PATHS = [
    r"C:\Program Files\7-Zip\7z.exe",
    r"C:\Program Files (x86)\7-Zip\7z.exe",
]

COMPRESSED_EXTENSIONS = ('.zip', '.rar', '.7z')


def find_7zip():
    for path in SEVEN_ZIP_PATHS:
        if os.path.isfile(path):
            return path
    return None


def is_pdf(filename):
    """Verifica si un archivo es PDF (acepta .pdf y .PDF)."""
    _, ext = os.path.splitext(filename)
    return ext.lower() == '.pdf'


def move_to_trash(path):
    """Enviar un archivo a la papelera en lugar de eliminarlo definitivamente."""
    path = os.path.normpath(os.path.abspath(path))
    if not os.path.exists(path):
        raise FileNotFoundError(f'Archivo no encontrado para mover a la papelera: {path}')

    if send2trash is not None:
        try:
            send2trash(path)
            return True
        except Exception as e:
            raise OSError(f'send2trash falló: {e}') from e

    if sys.platform == 'win32':
        try:
            import ctypes
            from ctypes import wintypes

            FO_DELETE = 3
            FOF_ALLOWUNDO = 0x0040
            FOF_NOCONFIRMATION = 0x0010

            class SHFILEOPSTRUCTW(ctypes.Structure):
                _fields_ = [
                    ('hwnd', wintypes.HWND),
                    ('wFunc', wintypes.UINT),
                    ('pFrom', wintypes.LPCWSTR),
                    ('pTo', wintypes.LPCWSTR),
                    ('fFlags', ctypes.c_uint16),
                    ('fAnyOperationsAborted', wintypes.BOOL),
                    ('hNameMappings', wintypes.LPVOID),
                    ('lpszProgressTitle', wintypes.LPCWSTR),
                ]

            path_buf = ctypes.create_unicode_buffer(path + '\0\0')
            op = SHFILEOPSTRUCTW()
            op.hwnd = None
            op.wFunc = FO_DELETE
            op.pFrom = path_buf
            op.pTo = None
            op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION

            result = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
            if result != 0:
                raise OSError(f'SHFileOperationW falló con código {result}')
            return True
        except Exception as e:
            raise OSError(f'Error nativo enviando a la papelera: {e}') from e

    raise OSError('No se pudo enviar a la papelera: método no soportado')


def insert_missing_underscore(filename):
    """
    Intenta insertar un guion bajo faltante en archivos sin separador.
    Solo para archivos que son principalmente dígitos (16-24 dígitos).
    
    Ejemplos:
    - '101045435320230073369485.pdf' -> '10104543532_0230073369485.pdf' (si 021/023 válido)
    - '12345678901234567890.pdf' -> Sin cambios (sin 021/023)
    """
    name_no_ext, ext = os.path.splitext(filename.strip())
    
    # Si ya tiene guion bajo, no hace falta
    if '_' in name_no_ext:
        return filename
    
    # Si no es todo dígitos, no procesar
    if not name_no_ext.isdigit():
        return filename
    
    # Si no está en rango 16-24 dígitos, no procesar
    if not (16 <= len(name_no_ext) <= 24):
        return filename
    
    # Buscar la primera ocurrencia de 021 o 023
    for pattern in ['021', '023']:
        pos = name_no_ext.find(pattern)
        if pos > 0:  # Debe estar después de algunos dígitos
            # Validar que antes haya entre 7 y 11 dígitos
            prefix_len = pos
            if 7 <= prefix_len <= 11:
                # Validar que el RC resultante tenga entre 5 y 13 dígitos
                rc_len = len(name_no_ext) - prefix_len
                if 5 <= rc_len <= 13:
                    # Insertar guion bajo
                    result = name_no_ext[:prefix_len] + '_' + name_no_ext[prefix_len:] + ext
                    return result
    
    return filename


def should_normalize(filename):
    """
    Determina si un archivo debe ser normalizado.
    Solo normaliza archivos que contienen principalmente:
    - Dígitos
    - Espacios
    - Guiones bajos (_)
    - Guiones (-)
    - Extensiones redundantes (.pdf.pdf, etc)
    
    NO normaliza:
    - Archivos con texto/palabras (letras alfanuméricas comunes)
    Ejemplos:
    - "10104543532_ 0230073369481.PDF" -> SÍ normalizar
    - "10104543532-0230073369481.PDF" -> SÍ normalizar (- se convierte a _)
    - "CARTA SUNAT SANTOS.pdf" -> NO normalizar
    """
    name_no_ext, ext = os.path.splitext(filename.strip())
    
    # Si tiene extensión redundante, sí normalizar
    if re.search(r'\.pdf+$', name_no_ext, re.I):
        return True
    
    # Contar caracteres: dígitos, espacios, guiones bajos, guiones
    # vs caracteres alfanuméricos (letras)
    digits_spaces_underscore = sum(1 for c in name_no_ext if c.isdigit() or c in ' _-')
    letters = sum(1 for c in name_no_ext if c.isalpha())
    
    # Si tiene letras, NO normalizar (es texto común)
    if letters > 0:
        return False
    
    # Si es principalmente números/espacios/guiones, SÍ normalizar
    return digits_spaces_underscore > 0


def normalize_filename(filename):
    """
    Normaliza SOLO archivos que cumplan criterios selectivos.
    Si no debe normalizarse, retorna EXACTAMENTE igual (sin cambios).
    
    Ejemplos de normalización (SÍ):
    - '10100296107 _0230073118790 ' -> '10100296107_0230073118790.pdf'
    - '10104543532_ 0230073369481' -> '10104543532_0230073369481.pdf'
    - '20392883208_0230075048306.pdf.pdf' -> '20392883208_0230075048306.pdf'
    - '10104543532-0230073369481.PDF' -> '10104543532_0230073369481.pdf' (- a _)
    - '101045435320230073369485.pdf' -> '10104543532_0230073369485.pdf' (insertar _ faltante)
    
    Ejemplos de NO normalización (retorna igual):
    - 'CARTA SUNAT SANTOS.PDF' -> 'CARTA SUNAT SANTOS.PDF'
    - 'DETRACCIONES 202202 SUNAT.pdf' -> 'DETRACCIONES 202202 SUNAT.pdf'
    """
    cleaned = filename.strip()
    
    # Si no debe normalizarse, retornar EXACTAMENTE igual
    if not should_normalize(filename):
        return cleaned
    
    # Intenta insertar guion bajo faltante (16-24 dígitos)
    cleaned = insert_missing_underscore(cleaned)
    
    # Normalización completa para archivos numéricos sucios
    name_no_ext, ext = os.path.splitext(cleaned)
    name_no_ext = re.sub(r'\s+_\s+', '_', name_no_ext)  # " _ " -> "_"
    name_no_ext = re.sub(r'_\s+', '_', name_no_ext)     # "_ " -> "_"
    name_no_ext = re.sub(r'\s+_', '_', name_no_ext)     # " _" -> "_"
    name_no_ext = re.sub(r'-', '_', name_no_ext)        # "-" -> "_"
    name_no_ext = name_no_ext.strip()
    
    # Remover extensiones redundantes .pdf
    name_no_ext = re.sub(r'\.pdf+$', '', name_no_ext, flags=re.I)
    
    return name_no_ext + '.pdf'


def is_duplicate(filename, canonical_base, ext):
    pattern = re.compile(
        DUPLICATE_PATTERN_TEMPLATE.format(
            name=re.escape(canonical_base),
            ext=re.escape(ext)
        ),
        re.I
    )
    return pattern.match(filename) is not None


def format_duration(seconds):
    seconds = int(seconds)
    d = seconds // 86400
    h = (seconds % 86400) // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if d > 0:
        return f'{d}d {h:02d}:{m:02d}:{s:02d}'
    return f'{h:02d}:{m:02d}:{s:02d}'


def canonical_db_name(name):
    return name.lower()


class DestinationIndexDB:
    """Gestor de índice SQLite para archivos en la carpeta destino."""
    
    def __init__(self, db_path):
        self.db_path = db_path
        self.conn = None
        self._init_db()
    
    def _init_db(self):
        """Inicializar la base de datos con esquema."""
        try:
            self.conn = sqlite3.connect(self.db_path, timeout=10, check_same_thread=False)
            self.conn.execute('PRAGMA journal_mode=WAL')
            self.conn.execute('PRAGMA synchronous=NORMAL')
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS indexed_files (
                    name TEXT PRIMARY KEY,
                    added_at REAL
                )
            ''')
            self.conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_name ON indexed_files(name COLLATE NOCASE)
            ''')
            self.conn.commit()
        except Exception as e:
            print(f'Error inicializando DB: {e}')
    
    def exists(self, filename):
        """Comprobar si un archivo está indexado (case-insensitive)."""
        try:
            cursor = self.conn.execute('SELECT 1 FROM indexed_files WHERE LOWER(name) = LOWER(?)', (filename,))
            return cursor.fetchone() is not None
        except Exception:
            return False
    
    def add(self, filenames):
        """Añadir múltiples archivos al índice (transacción)."""
        try:
            timestamp = time.time()
            data = []
            for name in filenames:
                if not isinstance(name, str):
                    continue
                canonical = canonical_db_name(name)
                data.append((canonical, timestamp))
            self.conn.executemany(
                'INSERT OR IGNORE INTO indexed_files (name, added_at) VALUES (?, ?)',
                data
            )
            self.conn.commit()
        except Exception as e:
            print(f'Error añadiendo archivos a DB: {e}')
    
    def get_count(self):
        """Obtener cantidad de archivos indexados."""
        try:
            cursor = self.conn.execute('SELECT COUNT(*) FROM indexed_files')
            return cursor.fetchone()[0]
        except Exception:
            return 0
    
    def close(self):
        """Cerrar conexión."""
        if self.conn:
            self.conn.close()


class ZipScannerApp:
    def __init__(self, root):
        self.root = root
        self.root.title('ScannerRC - Buscar PDFs RUC/DNI_RC')
        self.root.geometry('820x680')

        self.root_path = tk.StringVar(value=DEFAULT_ROOT)
        self.dest_path = tk.StringVar(value=DEFAULT_DEST)

        # 7-Zip
        self.seven_zip_path = find_7zip()

        # Crear carpeta db si no existe
        os.makedirs(DB_DIR, exist_ok=True)

        # DB y estado
        self.dest_db = DestinationIndexDB(DB_FILE)
        self._index_thread = None
        self._thread = None
        self._pause_event = threading.Event()

        # progreso
        self.processed_dirs = set()
        self.processed_zips = set()
        self.found_count = 0
        self.moved_count = 0
        self.deleted_count = 0
        self.skipped_count = 0
        self.total_files = 0
        self.normalized_count = 0

        # listas de archivos para validación
        self.list_extraidos = []
        self.list_movidos = []
        self.list_eliminados = []
        self.list_omitidos = []

        # timer
        self._start_time = None
        self._elapsed_pause = 0.0
        self._pause_start = None
        self._timer_running = False
        
        # indexación en background
        self._indexing_complete = threading.Event()
        self._indexing_count = 0
        self._indexing_total = 0

        self.construir_interfaz()
        self.cargar_progreso()

    def construir_interfaz(self):
        frm_top = ttk.Frame(self.root)
        frm_top.pack(fill='x', padx=8, pady=8)

        ttk.Label(frm_top, text='Ruta a escanear:').pack(side='left')
        ttk.Entry(frm_top, textvariable=self.root_path, width=60).pack(side='left', padx=6)
        ttk.Button(frm_top, text='Examinar', command=self.seleccionar_carpeta_origen).pack(side='left')

        frm_dest = ttk.Frame(self.root)
        frm_dest.pack(fill='x', padx=8)
        ttk.Label(frm_dest, text='Carpeta destino (extraídos):').pack(side='left')
        ttk.Entry(frm_dest, textvariable=self.dest_path, width=58).pack(side='left', padx=6)

        frm_buttons = ttk.Frame(self.root)
        frm_buttons.pack(fill='x', padx=8, pady=8)
        ttk.Button(frm_buttons, text='Iniciar', command=self.iniciar).pack(side='left', padx=4)
        ttk.Button(frm_buttons, text='Pausar', command=self.pausar).pack(side='left', padx=4)
        ttk.Button(frm_buttons, text='Reanudar', command=self.reanudar).pack(side='left', padx=4)
        ttk.Button(frm_buttons, text='Cargar Progreso', command=self.cargar_progreso).pack(side='right')

        # estado 7zip
        if self.seven_zip_path:
            seven_zip_msg = f'7-Zip encontrado: {self.seven_zip_path} - Se procesarán comprimidos .zip, .rar y .7z'
            seven_zip_color = 'green'
        else:
            seven_zip_msg = '7-Zip no encontrado. Se procesarán solo archivos comprimidos .zip'
            seven_zip_color = 'orange'

        lbl_7zip = ttk.Label(self.root, text=seven_zip_msg, foreground=seven_zip_color)
        lbl_7zip.pack(fill='x', padx=8)

        # estado
        self.status_var = tk.StringVar(value='Listo')
        lbl_status = ttk.Label(self.root, textvariable=self.status_var, foreground='blue')
        lbl_status.pack(fill='x', padx=8)

        # indexación destino
        self.index_status_var = tk.StringVar(value='Indexando destino... 0/0')
        lbl_index = ttk.Label(self.root, textvariable=self.index_status_var, foreground='purple')
        lbl_index.pack(fill='x', padx=8)

        frm_timer = ttk.LabelFrame(self.root, text='Temporizacion del proceso')
        frm_timer.pack(fill='x', padx=8, pady=4)

        frm_timer_inner = ttk.Frame(frm_timer)
        frm_timer_inner.pack(fill='x', padx=6, pady=4)

        ttk.Label(frm_timer_inner, text='Tiempo transcurrido:', font=('Segoe UI', 9, 'bold')).pack(side='left')
        self.elapsed_var = tk.StringVar(value='00:00:00')
        ttk.Label(frm_timer_inner, textvariable=self.elapsed_var,
                  foreground='dark violet', font=('Courier New', 10, 'bold'), width=10).pack(side='left', padx=(4, 20))

        ttk.Label(frm_timer_inner, text='Tiempo estimado restante:', font=('Segoe UI', 9, 'bold')).pack(side='left')
        self.eta_var = tk.StringVar(value='--:--:--')
        ttk.Label(frm_timer_inner, textvariable=self.eta_var,
                  foreground='dark green', font=('Courier New', 10, 'bold'), width=16).pack(side='left', padx=(4, 20))

        ttk.Label(frm_timer_inner, text='Velocidad:', font=('Segoe UI', 9, 'bold')).pack(side='left')
        self.speed_var = tk.StringVar(value='-- arch/min')
        ttk.Label(frm_timer_inner, textvariable=self.speed_var,
                  foreground='navy', font=('Segoe UI', 9)).pack(side='left', padx=(4, 0))

        self.timer_var = tk.StringVar(value='')

        # Panel de logs/progreso
        frame_logs = ttk.LabelFrame(self.root, text='Progreso / Logs')
        frame_logs.pack(fill='both', expand=True, padx=8, pady=6)

        self.txt_logs = scrolledtext.ScrolledText(frame_logs, height=18)
        self.txt_logs.pack(fill='both', expand=True)
        self.registrar_log('Aplicación lista. Ruta por defecto: %s' % DEFAULT_ROOT)

        # resumen rapido
        frm_summary = ttk.Frame(self.root)
        frm_summary.pack(fill='x', padx=8, pady=6)
        self.summary_var = tk.StringVar(value='Carpetas: 0 | Comprimidos: 0 | Extraídos: 0 | Movidos: 0 | Eliminados: 0 | Omitidos: 0 | Inspeccionados: 0 | Normalizados: 0')
        ttk.Label(frm_summary, textvariable=self.summary_var).pack(side='left')

    def seleccionar_carpeta_origen(self):
        d = filedialog.askdirectory(initialdir=self.root_path.get() or os.path.expanduser('~'))
        if d:
            self.root_path.set(d)

    def registrar_log(self, msg):
        self.txt_logs.insert('end', f'{msg}\n')
        self.txt_logs.see('end')

    # ------------------------------------------------------------------
    # Timer
    # ------------------------------------------------------------------
    def tick_temporizador(self):
        if not self._timer_running:
            return

        if self._start_time is None:
            self.root.after(1000, self.tick_temporizador)
            return

        if self._pause_start is not None:
            elapsed = self._start_time + (self._pause_start - self._start_time) - self._elapsed_pause
        else:
            elapsed = time.time() - self._start_time - self._elapsed_pause

        elapsed = max(0.0, elapsed)
        elapsed_str = format_duration(elapsed)

        eta_str = '--:--:--'
        speed_str = '-- arch/min'

        if elapsed > 5 and self.total_files > 0:
            speed = self.total_files / elapsed
            files_per_min = speed * 60
            speed_str = f'{files_per_min:.0f} arch/min'

            if elapsed > 10:
                dirs_done = len(self.processed_dirs)
                if dirs_done > 0:
                    secs_per_dir = elapsed / dirs_done
                    remaining_dirs_est = max(dirs_done * 0.15, 1)
                    eta_secs = int(remaining_dirs_est * secs_per_dir)
                    eta_str = format_duration(eta_secs)

        self.elapsed_var.set(elapsed_str)
        self.eta_var.set(eta_str)
        self.speed_var.set(speed_str)
        self.timer_var.set(f'{elapsed_str} | {eta_str}')

        self.root.after(1000, self.tick_temporizador)

    def iniciar_temporizador(self):
        self._start_time = time.time()
        self._elapsed_pause = 0.0
        self._pause_start = None
        self._timer_running = True
        self.tick_temporizador()

    def pausar_temporizador(self):
        if self._pause_start is None:
            self._pause_start = time.time()

    def reanudar_temporizador(self):
        if self._pause_start is not None:
            self._elapsed_pause += time.time() - self._pause_start
            self._pause_start = None

    def detener_temporizador(self):
        self._timer_running = False
        self._pause_start = None

    # ------------------------------------------------------------------
    # Progreso JSON
    # ------------------------------------------------------------------
    def guardar_progreso(self, log=True, state_override=None):
        state = state_override if state_override is not None else (
            'pausado' if self._pause_event.is_set() else 'ejecutando'
        )
        data = {
            'ruta_origen': self.root_path.get(),
            'ruta_destino': self.dest_path.get(),
            'carpetas_procesadas': list(self.processed_dirs),
            'comprimidos_procesados': list(self.processed_zips),
            'total_archivos_extraidos': self.found_count,
            'total_archivos_movidos': self.moved_count,
            'total_archivos_eliminados': self.deleted_count,
            'total_archivos_omitidos': self.skipped_count,
            'total_archivos_inspeccionados': self.total_files,
            'total_archivos_normalizados': self.normalized_count,
            'estado_proceso': state,
            'detalle_extraidos': self.list_extraidos,
            'detalle_movidos': self.list_movidos,
            'detalle_eliminados': self.list_eliminados,
            'detalle_omitidos': self.list_omitidos,
        }
        try:
            with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            if log:
                self.registrar_log(f'Checkpoint guardado: {PROGRESS_FILE}')
        except Exception as e:
            self.registrar_log(f'Error guardando progreso: {e}')

    def cargar_progreso(self):
        if os.path.exists(PROGRESS_FILE):
            try:
                with open(PROGRESS_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self.processed_dirs = set(data.get('carpetas_procesadas', []))
                self.processed_zips = set(data.get('comprimidos_procesados', []))
                self.found_count = data.get('total_archivos_extraidos', 0)
                self.moved_count = data.get('total_archivos_movidos', 0)
                self.deleted_count = data.get('total_archivos_eliminados', 0)
                self.skipped_count = data.get('total_archivos_omitidos', 0)
                self.total_files = data.get('total_archivos_inspeccionados', 0)
                self.normalized_count = data.get('total_archivos_normalizados', 0)
                self.list_extraidos = data.get('detalle_extraidos', [])
                self.list_movidos = data.get('detalle_movidos', [])
                self.list_eliminados = data.get('detalle_eliminados', [])
                self.list_omitidos = data.get('detalle_omitidos', [])
                self.root_path.set(data.get('ruta_origen', self.root_path.get()))
                self.dest_path.set(data.get('ruta_destino', self.dest_path.get()))
                self.actualizar_resumen()
                state = data.get('estado_proceso', 'detenido')
                if state == 'pausado':
                    self.status_var.set('Pausado')
                elif state == 'ejecutando':
                    self.status_var.set('En ejecución (guardado)')
                elif state == 'finalizado':
                    self.status_var.set('Finalizado')
                else:
                    self.status_var.set(state.capitalize())
                self.registrar_log(f'Progreso cargado desde {PROGRESS_FILE} (estado={state})')
            except Exception as e:
                self.registrar_log(f'Error cargando progreso: {e}')
        else:
            self.registrar_log('No se encontró archivo de progreso. Se iniciará desde cero.')

    def actualizar_resumen(self):
        self.summary_var.set(
            f'Carpetas: {len(self.processed_dirs)} | '
            f'Comprimidos: {len(self.processed_zips)} | '
            f'Extraídos: {self.found_count} | '
            f'Movidos: {self.moved_count} | '
            f'Eliminados: {self.deleted_count} | '
            f'Omitidos: {self.skipped_count} | '
            f'Inspeccionados: {self.total_files} | '
            f'Normalizados: {self.normalized_count}'
        )

    # ------------------------------------------------------------------
    # Control de escaneo
    # ------------------------------------------------------------------
    def iniciar(self):
        if self._thread and self._thread.is_alive():
            messagebox.showinfo('Info', 'Ya está en ejecución')
            return

        root = self.root_path.get()
        if not os.path.exists(root):
            messagebox.showerror('Error', f'Ruta no encontrada: {root}')
            return

        dest = self.dest_path.get()
        if not os.path.exists(dest):
            os.makedirs(dest, exist_ok=True)

        # Vicar si DB ya está indexada
        db_count = self.dest_db.get_count()
        if db_count == 0:
            # Indexar ahora
            self.status_var.set('Indexando destino...')
            self.registrar_log('Indexando carpeta destino... esto puede tardar')
            self.root.update_idletasks()

            try:
                all_files = []
                total_scanned = 0

                for dirpath, dirnames, filenames in os.walk(dest):
                    for f in filenames:
                        if is_pdf(f):
                            normalized = normalize_filename(f)
                            all_files.append(normalized)
                            total_scanned += 1
                            if total_scanned % 10000 == 0:
                                self.index_status_var.set(f'Indexando destino... {total_scanned:,}')
                                self.root.update_idletasks()

                if all_files:
                    self.dest_db.add(all_files)
                    self.index_status_var.set(f'Destino indexado: {len(all_files):,} archivos')
                    self.registrar_log(f'Indexación completada: {len(all_files):,} PDFs en destino')
                else:
                    self.index_status_var.set('Carpeta destino vacía')
                    self.registrar_log('Carpeta destino vacía o sin PDFs')

            except Exception as e:
                messagebox.showerror('Error', f'Error indexando destino: {e}')
                self.status_var.set('Error')
                return
        else:
            self.index_status_var.set(f'Destino ya indexado: {db_count:,} archivos')
            self.registrar_log(f'Usando índice existente con {db_count:,} archivos')

        self._pause_event.clear()

        self.iniciar_temporizador()

        self._thread = threading.Thread(target=self.hilo_escaneo, daemon=True)
        self._thread.start()
        self.status_var.set('Ejecutando...')
        self.registrar_log('Inicio de escaneo')

    def pausar(self):
        if not self._thread or not self._thread.is_alive():
            return
        self._pause_event.set()
        self.pausar_temporizador()
        self.guardar_progreso()
        self.status_var.set('Pausado')
        self.registrar_log('Pausa solicitada - puede cerrar el programa de forma segura')

    def reanudar(self):
        self.reanudar_temporizador()
        if not self._thread or not self._thread.is_alive():
            self._pause_event.clear()
            if not self._timer_running:
                self._timer_running = True
                self.tick_temporizador()
            self._thread = threading.Thread(target=self.hilo_escaneo, daemon=True)
            self._thread.start()
            self.status_var.set('Reanudado')
            self.registrar_log('Reanudando (nuevo hilo)')
            return
        self._pause_event.clear()
        self.status_var.set('Ejecutando...')
        self.registrar_log('Reanudar solicitada')

    def verificar_pausa(self):
        while self._pause_event.is_set():
            threading.Event().wait(0.5)
        return False

    def ruta_destino_para(self, filename):
        return os.path.join(self.dest_path.get(), filename)

    # ------------------------------------------------------------------
    # Procesamiento de archivos SUELTOS en carpetas
    # ------------------------------------------------------------------
    def procesar_archivos_sueltos(self, dirpath, filenames):
        correct = []
        duplicates = []

        for fname in filenames:
            if not is_pdf(fname):
                continue
            
            # Normalizar nombre
            normalized = normalize_filename(fname)
            if should_normalize(fname) and normalized != fname:
                self.normalized_count += 1
                self.registrar_log(f'Normalizado: "{fname}" -> "{normalized}"')
            
            if PATTERN.match(normalized):
                correct.append((fname, normalized))
            else:
                duplicates.append((fname, normalized))

        moved_bases = set()
        existing_bases = set()

        for fname, normalized in correct:
            if self.verificar_pausa():
                return
            fpath = os.path.join(dirpath, fname)
            dest = self.ruta_destino_para(normalized)
            self.total_files += 1
            base_no_ext = os.path.splitext(normalized)[0]

            if os.path.exists(dest) or self.dest_db.exists(normalized):
                try:
                    deleted_ok = move_to_trash(fpath)
                    if not deleted_ok:
                        raise OSError('No se pudo enviar a la papelera')
                    self.deleted_count += 1
                    self.list_eliminados.append({'archivo': fname, 'origen': dirpath, 'normalizado': normalized})
                    existing_bases.add(base_no_ext)
                    self.registrar_log(f'Eliminado de origen (ya existe en destino): {fname}')
                except Exception as e:
                    self.registrar_log(f'Error eliminando {fname} de origen: {e}')
            else:
                try:
                    shutil.move(fpath, dest)
                    self.moved_count += 1
                    moved_bases.add(base_no_ext)
                    self.list_movidos.append({'archivo': fname, 'origen': dirpath, 'normalizado': normalized})
                    self.dest_db.add([normalized])
                    self.registrar_log(f'Movido: {fname} -> {normalized}')
                except Exception as e:
                    self.registrar_log(f'Error moviendo {fname}: {e}')

        bases_con_destino = moved_bases | existing_bases

        for fname, normalized in duplicates:
            if self.verificar_pausa():
                return
            name_no_ext, ext = os.path.splitext(normalized)
            fpath = os.path.join(dirpath, fname)
            if not os.path.exists(fpath):
                continue
            for base in bases_con_destino:
                if is_duplicate(normalized, base, ext):
                    try:
                        deleted_ok = move_to_trash(fpath)
                        if not deleted_ok:
                            raise OSError('No se pudo enviar a la papelera')
                        self.deleted_count += 1
                        self.list_eliminados.append({'archivo': fname, 'origen': dirpath, 'normalizado': normalized})
                        self.registrar_log(f'Eliminado duplicado: {fname}')
                    except Exception as e:
                        self.registrar_log(f'Error eliminando duplicado {fname}: {e}')
                    break

    # ------------------------------------------------------------------
    # Procesamiento de ZIPs nativos
    def procesar_zip(self, zpath):
        try:
            with zipfile.ZipFile(zpath, 'r') as zf:
                members = zf.namelist()
                correct_in_zip = set()
                for member in members:
                    base = os.path.basename(member)
                    if not base or not is_pdf(base):
                        continue
                    normalized = normalize_filename(base)
                    if PATTERN.match(normalized):
                        correct_in_zip.add(normalized)

                for member in members:
                    if self.verificar_pausa():
                        return
                    base = os.path.basename(member)
                    if not base or not is_pdf(base):
                        continue

                    normalized = normalize_filename(base)
                    if should_normalize(base) and normalized != base:
                        self.normalized_count += 1

                    self.total_files += 1

                    if PATTERN.match(normalized):
                        dest = self.ruta_destino_para(normalized)
                        if self.dest_db.exists(normalized):
                            self.registrar_log(f'Ya existe en destino, omitido: {base}')
                            self.skipped_count += 1
                            entry = {'archivo': base, 'origen': zpath, 'normalizado': normalized}
                            if entry not in self.list_omitidos:
                                self.list_omitidos.append(entry)
                        else:
                            try:
                                with zf.open(member) as src, open(dest, 'wb') as out:
                                    shutil.copyfileobj(src, out)
                                self.found_count += 1
                                self.dest_db.add([normalized])
                                self.list_extraidos.append({'archivo': base, 'origen': zpath, 'normalizado': normalized})
                                self.registrar_log(f'Extraído: {base} ({normalized}) desde {zpath}')
                            except Exception as e:
                                self.registrar_log(f'Error extrayendo {member} de {zpath}: {e}')
                    else:
                        name_no_ext, ext = os.path.splitext(normalized)
                        for canonical_base in [os.path.splitext(c)[0] for c in correct_in_zip]:
                            if is_duplicate(normalized, canonical_base, ext):
                                self.registrar_log(f'Ignorado duplicado en ZIP: {base}')
                                break

        except zipfile.BadZipFile:
            self.registrar_log(f'ZIP dañado o inválido: {zpath}')
        except Exception as e:
            self.registrar_log(f'Error leyendo zip {zpath}: {e}')

    # ------------------------------------------------------------------
    # Procesamiento de RAR / 7Z por 7-Zip externo
    # ------------------------------------------------------------------
    @staticmethod
    def sin_ventana():
        if sys.platform == 'win32':
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
            return {'startupinfo': si, 'creationflags': subprocess.CREATE_NO_WINDOW}
        return {}

    def listar_7zip(self, fpath):
        try:
            result = subprocess.run(
                [self.seven_zip_path, 'l', '-ba', '-slt', fpath],
                capture_output=True, text=True, timeout=60,
                **self.sin_ventana()
            )
            if result.returncode != 0:
                detalle = (result.stderr or result.stdout or '').strip()
                detalle = detalle.replace('\n', ' ').replace('\r', '')[:200]
                self.registrar_log(f'Error listando {fpath} (RC={result.returncode}): {detalle}')
                return []
            names = []
            for line in result.stdout.splitlines():
                line = line.strip()
                if line.startswith('Path = '):
                    names.append(line[7:])
            return names
        except subprocess.TimeoutExpired:
            self.registrar_log(f'Tiempo de espera agotado listando {fpath}')
            return []
        except FileNotFoundError:
            self.registrar_log(f'No se encontro el ejecutable de 7-Zip en: {self.seven_zip_path}')
            return []
        except Exception as e:
            self.registrar_log(f'Error listando {fpath} con 7-Zip: {e}')
            return []

    def extraer_7zip(self, fpath, member, dest_final):
        tmp_dir = os.path.join(tempfile.gettempdir(), f'extract7z_{uuid.uuid4().hex}')
        try:
            os.makedirs(tmp_dir, exist_ok=True)
            result = subprocess.run(
                [self.seven_zip_path, 'x', fpath, f'-o{tmp_dir}', member, '-y'],
                capture_output=True, text=True, timeout=120,
                **self.sin_ventana()
            )
            if result.returncode != 0:
                detalle = (result.stderr or result.stdout or '').strip()
                detalle = detalle.replace('\n', ' ').replace('\r', '')[:200]
                self.registrar_log(f'Fallo extraccion (RC={result.returncode}) "{member}" de {fpath}: {detalle}')
                return False

            extracted_path = os.path.join(tmp_dir, member.replace('/', os.sep))
            if not os.path.isfile(extracted_path):
                base = os.path.basename(member)
                found = None
                for root_dir, _, files in os.walk(tmp_dir):
                    if base in files:
                        found = os.path.join(root_dir, base)
                        break
                if not found:
                    self.registrar_log(f'No se localizo el archivo extraido "{member}" de {fpath}')
                    return False
                extracted_path = found

            os.makedirs(os.path.dirname(dest_final), exist_ok=True)
            shutil.move(extracted_path, dest_final)
            return True
        except subprocess.TimeoutExpired:
            self.registrar_log(f'Tiempo de espera agotado extrayendo "{member}" de {fpath}')
            return False
        except FileNotFoundError:
            self.registrar_log(f'No se encontro el ejecutable de 7-Zip en: {self.seven_zip_path}')
            return False
        except Exception as e:
            self.registrar_log(f'Error extrayendo "{member}" de {fpath} con 7-Zip: {e}')
            return False
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    def procesar_archivo_7zip(self, fpath):
        members = self.listar_7zip(fpath)

        correct_in_archive = set()
        for member in members:
            base = os.path.basename(member)
            if not base or not is_pdf(base):
                continue
            normalized = normalize_filename(base)
            if PATTERN.match(normalized):
                correct_in_archive.add(normalized)

        for member in members:
            if self.verificar_pausa():
                return
            base = os.path.basename(member)
            if not base or not is_pdf(base):
                continue

            normalized = normalize_filename(base)
            if should_normalize(base) and normalized != base:
                self.normalized_count += 1

            self.total_files += 1

            if PATTERN.match(normalized):
                dest = self.ruta_destino_para(normalized)
                if self.dest_db.exists(normalized):
                    self.registrar_log(f'Ya existe en destino, omitido: {base}')
                    self.skipped_count += 1
                    entry = {'archivo': base, 'origen': fpath, 'normalizado': normalized}
                    if entry not in self.list_omitidos:
                        self.list_omitidos.append(entry)
                else:
                    success = self.extraer_7zip(fpath, member, dest)
                    if success:
                        self.found_count += 1
                        self.dest_db.add([normalized])
                        self.list_extraidos.append({'archivo': base, 'origen': fpath, 'normalizado': normalized})
                        self.registrar_log(f'Extraido: {base} ({normalized}) desde {fpath}')
            else:
                name_no_ext, ext = os.path.splitext(normalized)
                for canonical_base in [os.path.splitext(c)[0] for c in correct_in_archive]:
                    if is_duplicate(normalized, canonical_base, ext):
                        self.registrar_log(f'Ignorado duplicado en comprimido: {base}')
                        break

    # ------------------------------------------------------------------
    # Hilo principal de escaneo
    # ------------------------------------------------------------------
    def hilo_escaneo(self):
        root = self.root_path.get()
        list_count = 0

        try:
            for dirpath, dirnames, filenames in os.walk(root):
                if self.verificar_pausa():
                    break

                if dirpath in self.processed_dirs:
                    continue

                compressed_files = []
                loose_files = []

                for fname in filenames:
                    ext = os.path.splitext(fname)[1].lower()
                    if ext == '.zip':
                        compressed_files.append((fname, 'zip'))
                    elif ext in ('.rar', '.7z') and self.seven_zip_path:
                        compressed_files.append((fname, '7z'))
                    elif ext == '.pdf':
                        loose_files.append(fname)

                if loose_files:
                    self.procesar_archivos_sueltos(dirpath, loose_files)

                for fname, ctype in compressed_files:
                    if self.verificar_pausa():
                        break

                    zpath = os.path.join(dirpath, fname)
                    if zpath in self.processed_zips:
                        continue

                    self.total_files += 1

                    if ctype == 'zip':
                        self.procesar_zip(zpath)
                    else:
                        self.procesar_archivo_7zip(zpath)

                    self.processed_zips.add(zpath)

                    if len(self.processed_zips) % 20 == 0:
                        self.guardar_progreso(log=False)

                self.processed_dirs.add(dirpath)
                list_count += 1
                if list_count % 10 == 0:
                    self.guardar_progreso(log=False)

                self.actualizar_resumen()

            self.detener_temporizador()
            self.guardar_progreso(log=True, state_override='finalizado')
            self.registrar_log('Escaneo finalizado')
            self.status_var.set('Finalizado')

        except Exception as e:
            self.registrar_log(f'Error en hilo de escaneo: {e}')
            self.status_var.set('Error')
        finally:
            if self.dest_db:
                self.dest_db.close()


if __name__ == '__main__':
    root = tk.Tk()
    app = ZipScannerApp(root)
    root.mainloop()
