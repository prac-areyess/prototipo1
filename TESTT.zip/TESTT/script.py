from pywinauto.application import Application
from pywinauto.keyboard import send_keys
from pynput import keyboard, mouse
import threading
import time
import os

# --- Parámetros ---
shortcut_path = r'D:\Usuarios\prac-areyess\Documents\Proyectos\Testeo\Actualiza RSIRAT.lnk'
dependencia_text = "0021 I.R. Lima - PRICO"
password = "12345678abc@"
interferencia_detectada = False

# --- Función para bloquear pantalla ---
def bloquear():
    global interferencia_detectada
    if not interferencia_detectada:
        interferencia_detectada = True
        print("🔒 Interferencia detectada. Bloqueando pantalla...")
        os.system("rundll32.exe user32.dll,LockWorkStation")

# --- Listeners de teclado y mouse ---
def iniciar_monitoreo():
    def on_key(key):
        bloquear()

    def on_move(x, y):
        bloquear()

    def on_click(x, y, button, pressed):
        if pressed:
            bloquear()

    keyboard_listener = keyboard.Listener(on_press=on_key)
    mouse_listener = mouse.Listener(on_move=on_move, on_click=on_click)

    keyboard_listener.start()
    mouse_listener.start()

# --- Iniciar monitoreo en segundo plano ---
monitoreo_thread = threading.Thread(target=iniciar_monitoreo, daemon=True)
monitoreo_thread.start()

# --- Ejecutar RSIRAT ---
try:
    os.startfile(shortcut_path)
    print("🟢 RSIRAT iniciado desde acceso directo.")
except Exception as e:
    print(f"❌ Error al iniciar RSIRAT: {e}")
    exit()

# --- Esperar a que cargue ---
time.sleep(10)

# --- Conectar con la aplicación ---
try:
    app = Application(backend="uia").connect(title_re=".*SIRAT.*")
    windows = app.windows()
    if not windows:
        print("❌ No se encontró ninguna ventana de SIRAT.")
        exit()
    target_window = app.window(handle=windows[-1].handle)
    print("✅ Conectado a la ventana de RSIRAT.")
except Exception as e:
    print(f"❌ Error al conectar con RSIRAT: {e}")
    exit()

# --- Paso 1: Escribir la dependencia ---
try:
    combo_edit = target_window.child_window(control_type="Edit", found_index=0)
    combo_edit.set_edit_text(dependencia_text)
    print(f"✅ Dependencia escrita: {dependencia_text}")
except Exception as e:
    print("❌ No se pudo escribir la dependencia:", e)

# --- Paso 2: Ingresar la contraseña ---
try:
    edits = target_window.descendants(control_type="Edit")
    password_field = next((e for e in edits if e.element_info.automation_id == "1005"), edits[-1])
    password_field.set_focus()
    password_field.type_keys(password, with_spaces=True)
    print("✅ Contraseña ingresada.")
except Exception as e:
    print("❌ No se pudo ingresar la contraseña:", e)

# --- Paso 3: Activar "Aceptar" usando Alt + A ---
try:
    send_keys('%a')  # Alt + A
    print("✅ Se hizo clic en 'Aceptar' usando Alt+A.")
except Exception as e:
    print("❌ No se pudo activar 'Aceptar' con Alt+A:", e)

# --- Fin del script ---
print("🏁 Script finalizado. Monitoreo de seguridad sigue activo.")

