import time
import os
import re
import sys
from pathlib import Path

import cv2
import numpy as np
import pyautogui


def _obtener_ruta_base():
    """Obtiene la ruta base del proyecto.
    
    Usa sys.argv[0] (más robusto para script y ejecutable).
    Fallback a sys.executable si sys.argv[0] no es confiable.
    
    Nota: Los archivos deben estar en la MISMA carpeta que el ejecutable/script.
    """
    try:
        # sys.argv[0] funciona tanto en script como en ejecutable
        ruta = os.path.dirname(os.path.abspath(sys.argv[0]))
        if ruta:
            return Path(ruta)
    except Exception:
        pass
    
    # Fallback: usar sys.executable (ejecutable)
    try:
        if getattr(sys, 'frozen', False):
            return Path(sys.executable).resolve().parent
    except Exception:
        pass
    
    # Último fallback: __file__
    return Path(__file__).resolve().parent


BASE_DIR = str(_obtener_ruta_base())
DEBUG_DIR = os.path.join(BASE_DIR, "debug_automatizador")
CONFIG_CORTES = os.path.join(BASE_DIR, "configuracion_corte.txt")
os.makedirs(DEBUG_DIR, exist_ok=True)


def _leer_config(ruta=CONFIG_CORTES):
    """Lee configuracion_corte.txt como {clave: valor} (ignora vacíos y comentarios)."""
    cfg = {}
    if not os.path.exists(ruta):
        return cfg
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                clave, valor = [p.strip() for p in linea.split("=", 1)]
                cfg[clave.lower()] = valor
    except Exception:
        return {}
    return cfg


def _primer_valor(cfg, claves, convertir=float, validar=None):
    """Devuelve el primer valor válido entre `claves` (en orden de prioridad).

    Las claves `2p_*` van primero; se mantienen las claves sin prefijo por compatibilidad.
    """
    for clave in claves:
        if clave not in cfg:
            continue
        try:
            valor = convertir(cfg[clave])
        except ValueError:
            continue
        if validar is None or validar(valor):
            return valor
    return None


def leer_porcentajes_celdas(ruta=CONFIG_CORTES, fila=None):
    """Lee porcentajes por celda desde el TXT externo.

    Claves globales (prioridad 2p_, luego sin prefijo):
      2p_celda_0=15 ... 2p_celda_3=35
    Override opcional por fila:
      2p_fila_0=10,25,30,35
    """
    cfg = _leer_config(ruta)
    if not cfg:
        return None

    if fila is not None:
        for clave in (f"2p_fila_{fila}", f"fila_{fila}"):
            if clave in cfg:
                try:
                    partes = [float(x.strip()) for x in cfg[clave].split(",") if x.strip()]
                except ValueError:
                    continue
                if len(partes) == 4 and sum(partes) > 0:
                    total = sum(partes)
                    return [v / total for v in partes]

    valores = []
    for i in range(4):
        v = _primer_valor(cfg, (f"2p_celda_{i}", f"celda_{i}"))
        if v is None:
            return None
        valores.append(v)

    total = sum(valores)
    if total <= 0:
        return None
    return [v / total for v in valores]


def leer_pulsaciones_derecha(ruta=CONFIG_CORTES):
    """Lee la cantidad exacta de pulsaciones a la derecha desde el archivo de config."""
    cfg = _leer_config(ruta)
    v = _primer_valor(
        cfg,
        ("2p_pulsaciones_derecha", "pulsaciones_derecha", "derecha_pulsaciones"),
        convertir=lambda s: int(float(s)),
        validar=lambda n: n > 0,
    )
    return v if v is not None else 8


def leer_roi_config(ruta=CONFIG_CORTES):
    """Lee el porcentaje y píxeles mínimos para el recorte ROI."""
    cfg = _leer_config(ruta)
    entero_pos = dict(convertir=lambda s: int(float(s)), validar=lambda n: n > 0)
    porcentaje = _primer_valor(cfg, ("2p_roi_porcentaje", "roi_porcentaje", "roi_percent"), **entero_pos)
    min_px = _primer_valor(cfg, ("2p_roi_min_px", "roi_min_px", "roi_minimo_px"), **entero_pos)
    return (porcentaje if porcentaje is not None else 15), (min_px if min_px is not None else 450)


def leer_ancho_base_pantalla(ruta=CONFIG_CORTES):
    """Lee el ancho de referencia de la pantalla para ajustar por resolucion."""
    cfg = _leer_config(ruta)
    v = _primer_valor(
        cfg,
        ("2p_ancho_pantalla_base", "ancho_pantalla_base", "screen_width_base", "base_width", "1p_ancho_pantalla_base"),
        convertir=lambda s: int(float(s)),
        validar=lambda n: n > 0,
    )
    return v if v is not None else 1920


def calcular_pulsaciones_derecha(ruta=CONFIG_CORTES):
    """Ajusta el valor base segun el ancho real de la pantalla del equipo."""
    base = leer_pulsaciones_derecha(ruta)
    ancho_base = leer_ancho_base_pantalla(ruta)
    ancho_actual = pyautogui.size().width
    if ancho_actual <= 0 or ancho_base <= 0:
        return base
    ratio = ancho_actual / ancho_base
    pulsaciones = int(round(base * ratio))
    return max(1, pulsaciones)


def mover_hasta_ultima_columna(pulsaciones=None):
    if pulsaciones is None:
        pulsaciones = leer_pulsaciones_derecha()
    for _ in range(pulsaciones):
        pyautogui.press("right")
        time.sleep(0.03)
    time.sleep(0.08)


def detectar_fila_azul(img_bgr):
    """Busca el bloque azul de la fila activa dentro de la captura completa."""
    h, w = img_bgr.shape[:2]
    b = img_bgr[:, :, 0].astype(np.int16)
    g = img_bgr[:, :, 1].astype(np.int16)
    r = img_bgr[:, :, 2].astype(np.int16)

    mascara_azul = (b > 110) & (b > g + 25) & (b > r + 25)
    num_componentes, _, stats, _ = cv2.connectedComponentsWithStats(
        mascara_azul.astype(np.uint8), 8
    )

    candidatos = []
    for i in range(1, num_componentes):
        x, y, ancho, alto, area = stats[i]
        if ancho > 80 and alto > 8 and area > 300:
            candidatos.append((area, x, y, ancho, alto))

    if not candidatos:
        return None

    _, x, y, ancho, alto = max(candidatos, key=lambda t: t[0])
    y0 = max(0, y - 5)
    y1 = min(h, y + alto + 10)
    x0 = max(0, x - 10)
    x1 = min(w, x + ancho + 10)
    return (x0, y0, x1, y1)


def recortar_ultima_parte_fila(img_bgr, coords):
    x0, y0, x1, y1 = coords
    ancho_total = x1 - x0
    # Lee configuración del ROI desde el archivo de config
    roi_porcentaje, roi_min_px = leer_roi_config()
    # Calcula el ancho del recorte usando el porcentaje y el mínimo configurado
    ancho_ultimos_datos = max(roi_min_px, int(ancho_total * roi_porcentaje / 100))
    x_recorte_izq = max(0, x1 - ancho_ultimos_datos)
    # Mantenemos el margen superior y recortamos un poco más la parte inferior.
    margen_superior = max(0, (y1 - y0) // 8)
    margen_inferior = max(0, (y1 - y0) // 12)
    y0_ajustado = y0 + margen_superior
    y1_ajustado = y1 - margen_inferior
    print(f"    [DEBUG] Recorte: ancho_total={ancho_total}, ancho_recorte={ancho_ultimos_datos} (config: {roi_porcentaje}% / min {roi_min_px}px), x={x_recorte_izq}:{x1}, y={y0_ajustado}:{y1_ajustado}")
    return img_bgr[y0_ajustado:y1_ajustado, x_recorte_izq:x1]


def _parece_digito_cero(c):
    """Identifica el glifo 0 por su contorno (tolerante a distintos tamaños de fuente)."""
    alto, ancho = c.shape
    if not (3 <= ancho <= 14 and 6 <= alto <= 24):
        return False
    if np.count_nonzero(c[0]) < 2 or np.count_nonzero(c[-1]) < 2:
        return False
    if np.count_nonzero(c[:, 0]) / alto < 0.5 or np.count_nonzero(c[:, -1]) / alto < 0.5:
        return False
    if any(np.count_nonzero(f) == ancho for f in c[1:-1]):
        return False
    return True


def _mascara_texto(roi_bgr):
    """Máscara del texto claro dentro de la banda azul, sin líneas de la grilla ni zona blanca inferior."""
    b = roi_bgr[:, :, 0].astype(np.int16)
    r = roi_bgr[:, :, 2].astype(np.int16)
    azul = (b > 150) & (b > r + 60)
    filas = np.where(azul.mean(axis=1) > 0.5)[0]
    if len(filas) == 0:
        return None
    y0, y1 = filas.min(), filas.max()
    cols = np.where(azul[y0:y1 + 1].mean(axis=0) > 0.3)[0]
    x_max = cols.max()
    luz = roi_bgr.min(axis=2) > 130
    banda = luz[y0:y1 + 1, :x_max + 1].copy()
    lineas = banda.mean(axis=0) > 0.9          # líneas verticales de la grilla
    banda[:, lineas] = False
    banda = cv2.morphologyEx(banda.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8)) > 0
    banda[:, lineas] = False
    return banda


def extraer_ultimos_4_valores(fila_bgr, paso=0):
    """Lee los 4 valores finales (0 = cero, 1 = distinto de cero)."""
    cv2.imwrite(os.path.join(DEBUG_DIR, f"fila_{paso:02d}_roi.png"), fila_bgr)
    h, w = fila_bgr.shape[:2]
    if w < 20:
        return None

    porcentajes = leer_porcentajes_celdas(fila=paso)
    if porcentajes is None:
        porcentajes = [0.25] * 4
    bordes = [0] + [int(round(w * sum(porcentajes[:i + 1]))) for i in range(3)] + [w]

    mask = _mascara_texto(fila_bgr)
    if mask is None:
        return None
    cv2.imwrite(os.path.join(DEBUG_DIR, f"fila_{paso:02d}_mascara.png"), mask.astype(np.uint8) * 255)

    n, lab, st, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    glifos = [[] for _ in range(4)]
    for k in range(1, n):
        x, y, a, alto, area = st[k]
        if area < 6 or a < 3:            # ruido / restos de línea
            continue
        centro = x + a / 2
        idx = next(i for i in range(4) if bordes[i] <= centro < bordes[i + 1]) if centro < bordes[4] else 3
        glifos[idx].append(lab[y:y + alto, x:x + a] == k)

    valores = []
    for idx in range(4):
        valor = 0 if all(_parece_digito_cero(g) for g in glifos[idx]) else 1
        valores.append(valor)
        print(f"[{paso}] Celda {idx}: x={bordes[idx]}:{bordes[idx+1]}, glifos={len(glifos[idx])}, valor={valor}")
        cv2.imwrite(os.path.join(DEBUG_DIR, f"fila_{paso:02d}_celda_{idx}.png"),
                    cv2.cvtColor(fila_bgr[:, bordes[idx]:bordes[idx + 1]], cv2.COLOR_BGR2GRAY))

    print(f"[{paso}] Valores analizados (0=cero, 1=distinto de cero): {valores}")
    return valores


def cumple_patron(valores):
    """Patrón objetivo: 0, 0, x, 0 donde x es cualquier valor distinto de 0."""
    if len(valores) != 4:
        return False
    return valores[0] == 0 and valores[1] == 0 and valores[2] != 0 and valores[3] == 0


def ejecutar_automatizacion(max_filas=20):
    y_anterior = None
    pulsaciones_derecha = leer_pulsaciones_derecha()

    for paso in range(max_filas):
        # Paso 1: aseguramos que estemos al extremo derecho antes de cada captura
        print(f"[{paso}] Moviendo a la derecha ({pulsaciones_derecha} pulsaciones exactas del TXT)...")
        mover_hasta_ultima_columna(pulsaciones=pulsaciones_derecha)
        time.sleep(0.2)

        # Paso 2: capturamos la pantalla completa sin depender del nombre de la ventana
        print(f"[{paso}] Capturando pantalla...")
        pantalla = pyautogui.screenshot()
        img_bgr = cv2.cvtColor(np.array(pantalla), cv2.COLOR_RGB2BGR)

        # Paso 3: detectamos la fila azul/seleccionada dentro de la imagen
        coords = detectar_fila_azul(img_bgr)
        if coords is None:
            print(f"[{paso}] No se detectó fila activa. Fin.")
            break

        x0, y0, x1, y1 = coords
        print(f"[{paso}] Fila detectada en posición: x={x0}:{x1}, y={y0}:{y1}")

        # Verificación de coordenada ANTES de leer o marcar: si la Y se repite, el DOWN no movió la
        # selección, es la misma fila ya procesada y no hay más filas. Se termina sin tocarla.
        if y0 == y_anterior:
            print(f"[{paso}] Coordenada repetida (y={y0}): no hay más filas. Finalizando.")
            break
        y_anterior = y0

        # Hacemos clic en la región detectada para dirigir la interacción a la ventana visible
        x_click = x0 + 20
        y_click = (y0 + y1) // 2
        pyautogui.click(x_click, y_click)
        time.sleep(0.15)
        print(f"[{paso}] Click hecho sobre la fila detectada para asegurar foco visual.")

        # Presionamos Home para asegurar que estamos al inicio de la fila
        pyautogui.press("home")
        time.sleep(0.1)
        print(f"[{paso}] Home presionado para resetear posición horizontal.")

        # Paso 4: Recortamos la parte derecha con los 4 valores finales
        fila_derecha = recortar_ultima_parte_fila(img_bgr, coords)
        cv2.imwrite(os.path.join(DEBUG_DIR, f"fila_{paso:02d}_derecha.png"), fila_derecha)

        # Paso 5: Extraemos los valores
        valores = extraer_ultimos_4_valores(fila_derecha, paso=paso)

        # Paso 6: Evaluamos si cumple el patrón
        if valores is None:
            print(f"[{paso}] No se pudieron leer los 4 valores. Se pasa a la siguiente fila.")
        else:
            print(f"[{paso}] Valores leídos: {valores}")
            if cumple_patron(valores):
                print(f"[{paso}] CUMPLE patrón 0,0,x,0 -> marcando con ESPACIO")
                pyautogui.press("space")
                time.sleep(0.15)
                print(f"[{paso}] Espacio presionado. Volviendo a mover a la derecha...")
                mover_hasta_ultima_columna(pulsaciones=leer_pulsaciones_derecha())
                time.sleep(0.1)
            else:
                print(f"[{paso}] No cumple. Se continúa.")

        # Paso 7: Movemos a la siguiente fila con Down
        print(f"[{paso}] Presionando tecla Down para ir a la siguiente fila...")
        pyautogui.press("down")
        time.sleep(0.2)


if __name__ == "__main__":
    print("Inicializando automatización sin depender del título de la ventana...")
    time.sleep(1)
    ejecutar_automatizacion()
    input("\nProceso finalizado. Presione Enter para cerrar la consola...")