from pathlib import Path
import logging
import sys
import time
import pyautogui
import pandas as pd
import os
import re
import tkinter as tk
from tkinter import ttk
import subprocess
from datetime import datetime
from pywinauto import Desktop

# Intentar imports relativos (cuando se ejecuta como módulo)
# Si falla, usar imports absolutos (cuando se ejecuta directamente)
try:
    from .controlador import ControladorApp
    from .util_imagen import buscar_plantilla_pantalla, _obtener_ruta_base
except ImportError:
    # Agregar el directorio actual al path si se ejecuta directamente
    sys.path.insert(0, str(Path(__file__).parent))
    from controlador import ControladorApp
    from util_imagen import buscar_plantilla_pantalla, _obtener_ruta_base


# Usar la función centralizada para obtener la ruta base
PROJECT_DIR = _obtener_ruta_base()
SCRIPT_DIR = PROJECT_DIR
IMG_DIR = PROJECT_DIR / "IMG"
DATA_FILE = PROJECT_DIR / "DATA.xlsx"
SHORTCUT_PATH = PROJECT_DIR / "RSIRAT.lnk"
LEGACY_SHORTCUT_PATH = PROJECT_DIR / "Actualiza RSIRAT.lnk"
CONFIG_CORTES = PROJECT_DIR / "configuracion_corte.txt"
DEBUG_DIR = PROJECT_DIR / "debug_automatizador"
RESULT_DIR = PROJECT_DIR / "resultado"
EXPEDIENTE_REF_DIR = DEBUG_DIR / "expediente_referencia"
MARCACION_DIR = DEBUG_DIR / "marcacion_expedientes"
RESOLUCIONES_DIR = DEBUG_DIR / "resoluciones"
TERMINAL_LOG = RESULT_DIR / "terminal_log.txt"

for carpeta in (DEBUG_DIR, RESULT_DIR, EXPEDIENTE_REF_DIR, MARCACION_DIR, RESOLUCIONES_DIR):
    try:
        carpeta.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def obtener_shortcut_efectivo() -> Path:
    """Devuelve la ruta del acceso directo actual, soportando el nombre nuevo y el legado."""
    for ruta in (SHORTCUT_PATH, LEGACY_SHORTCUT_PATH):
        if ruta.exists():
            return ruta
    return SHORTCUT_PATH


def configurar_logger():
    logger = logging.getLogger("robot_rsirat")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    try:
        fh = logging.FileHandler(TERMINAL_LOG, encoding="utf-8")
        fh.setLevel(logging.INFO)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
    except Exception:
        pass

    return logger


def pausar_si_es_terminal(mensaje: str = "Presione Enter para continuar..."):
    """Pausa la ejecución solo en terminal interactivo para ver errores o mensajes finales."""
    try:
        if sys.stdin is not None and hasattr(sys.stdin, "isatty") and sys.stdin.isatty():
            input(mensaje)
    except EOFError:
        pass


def crear_campo_contraseña(parent, textvariable, texto_label, ancho=30, font=None):
    """Crea un campo de contraseña con etiqueta a la izquierda y botón al final."""
    frame = tk.Frame(parent, bg="#f3f6fb", padx=8, pady=6)
    tk.Label(frame, text=texto_label, width=18, anchor="w", font=font, bg="#f3f6fb").pack(side="left")

    entry_frame = tk.Frame(frame, bg="#f3f6fb")
    entry = tk.Entry(
        entry_frame,
        textvariable=textvariable,
        show="*",
        width=ancho,
        font=font,
        bd=2,
        relief="solid",
        highlightthickness=1,
        highlightbackground="#c7d2e0",
        highlightcolor="#4a90e2",
        insertbackground="#1f2937"
    )
    entry.pack(side="left", padx=(0, 8))

    def alternar_mostrar():
        valor_actual = entry.cget("show")
        entry.config(show="" if valor_actual == "*" else "*")
        boton.config(text="Ocultar" if valor_actual == "*" else "Mostrar")

    boton = tk.Button(
        entry_frame,
        text="Mostrar",
        command=alternar_mostrar,
        width=10,
        font=("Segoe UI", 10, "bold"),
        relief="raised",
        bd=1,
        padx=6,
        pady=4,
        bg="#eaf2ff",
        fg="#17375e",
        activebackground="#d7e8ff",
        activeforeground="#17375e",
        cursor="hand2"
    )
    boton.pack(side="left")
    entry_frame.pack(side="left")
    frame.pack(fill="x", padx=8, pady=5)
    return entry


def solicitar_datos_ejecucion():
    """
    Diálogo con la selección de modo:
    - 0: flujo normal con contraseña RSIRAT
    - 1: inicia directamente desde Cobranza Coactiva, sin pasar por login
    """
    root = tk.Tk()
    root.title("RSIRAT - Inicio")
    root.geometry("560x300")
    root.minsize(520, 250)
    root.attributes("-topmost", True)
    root.withdraw()

    dialog = tk.Toplevel(root)
    dialog.title("RSIRAT - Inicio")
    dialog.geometry("560x300")
    dialog.minsize(520, 250)
    dialog.attributes("-topmost", True)
    dialog.resizable(True, True)

    font_label = ("Segoe UI", 12, "bold")
    font_entry = ("Segoe UI", 12)

    modo_var = tk.StringVar(value="0")
    password_sirat_var = tk.StringVar(value="")

    tk.Label(dialog, text="Acceso a RSIRAT", anchor="w", font=("Segoe UI", 14, "bold")).pack(fill="x", padx=22, pady=(18, 12))

    frame_modo = tk.Frame(dialog, bg="#ffffff", padx=10, pady=8)
    tk.Label(frame_modo, text="Modo de ejecución:", anchor="w", font=font_label, bg="#ffffff").pack(fill="x", pady=(4, 6))
    combo = ttk.Combobox(
        frame_modo,
        textvariable=modo_var,
        values=["0", "1"],
        state="readonly",
        width=18,
        font=font_entry,
    )
    combo.pack(fill="x")
    tk.Label(frame_modo, text="0 = Contraseña   |   1 = Directo a Cobranza Coactiva", anchor="w", font=("Segoe UI", 10), bg="#ffffff", fg="#4b5563").pack(fill="x", pady=(8, 0))
    frame_modo.pack(fill="x", padx=18, pady=(0, 0))

    password_frame = tk.Frame(dialog, bg="#ffffff", padx=10, pady=8)
    tk.Label(password_frame, text="Contraseña RSIRAT:", anchor="w", font=font_label, bg="#ffffff").pack(fill="x", pady=(8, 10))
    crear_campo_contraseña(password_frame, password_sirat_var, "Contraseña:", ancho=30, font=font_entry)

    def actualizar_vista_modo():
        if modo_var.get() == "1":
            password_frame.pack_forget()
        else:
            password_frame.pack(fill="x", padx=18, pady=(12, 0))

    combo.bind("<<ComboboxSelected>>", lambda _event: actualizar_vista_modo())
    actualizar_vista_modo()

    def aceptar():
        dialog.destroy()
        root.destroy()

    def cancelar():
        password_sirat_var.set("")
        dialog.destroy()
        root.destroy()

    buttons = tk.Frame(dialog, bg="#ffffff")
    tk.Button(
        buttons,
        text="Aceptar",
        command=aceptar,
        width=12,
        font=("Segoe UI", 11, "bold"),
        bg="#2a7ae2",
        fg="white",
        activebackground="#1d5fc4",
        activeforeground="white",
        relief="raised",
        padx=10,
        pady=6
    ).pack(side="right", padx=(0, 8))
    tk.Button(
        buttons,
        text="Cancelar",
        command=cancelar,
        width=12,
        font=("Segoe UI", 11),
        bg="#eef2f8",
        fg="#24364d",
        relief="raised",
        padx=10,
        pady=6
    ).pack(side="right")
    buttons.pack(fill="x", padx=18, pady=(20, 18))

    dialog.protocol("WM_DELETE_WINDOW", cancelar)
    dialog.wait_window(dialog)

    return int(modo_var.get()), "", "", password_sirat_var.get()


def normalizar_dependencia(dependencia: str) -> str:
    """
    Normaliza el código de dependencia a su nombre completo.
    """
    dep_code = str(dependencia).strip()
    dep_map = {
        "21": "0021 I.R. Lima - PRICO",
        "021": "0021 I.R. Lima - PRICO",
        "0021": "0021 I.R. Lima - PRICO",
        "23": "0023 I.R. Lima - MEPECO",
        "023": "0023 I.R. Lima - MEPECO",
        "0023": "0023 I.R. Lima - MEPECO",
    }
    return dep_map.get(dep_code, dep_code)


def validar_expediente_numerico(expediente: str) -> bool:
    """Valida que el número de expediente contenga solo dígitos numéricos."""
    expediente_str = str(expediente).strip()
    return bool(re.match(r'^\d+$', expediente_str))


def obtener_cantidad_esperada_columna_c(fila: pd.Series):
    """Devuelve el valor esperado para la columna C, si existe y es numérico."""
    try:
        for nombre in ("C", "NRO ACUM", "CANTIDAD", "CANT"):
            if nombre in fila.index:
                valor = str(fila[nombre]).strip()
                if valor and re.fullmatch(r"\d+", valor):
                    return int(valor)
        if len(fila) > 2:
            valor = str(fila.iloc[2]).strip()
            if valor and re.fullmatch(r"\d+", valor):
                return int(valor)
    except Exception:
        pass
    return None


def ejecutar_marcacion_separacion(max_filas: int = 20) -> int:
    """
    Reutiliza automatizador_expedientes.py para marcar filas que cumplan el patrón.
    Cuenta cuántas veces se presiona la tecla ESPACIO, ya que eso indica una marca válida.
    """
    try:
        import automatizador_expedientes as auto
    except Exception as exc:
        logging.getLogger("robot_rsirat").error(f"No se pudo importar automatizador_expedientes.py: {exc}")
        return 0

    contador = {"space": 0}
    original_press = auto.pyautogui.press

    def press_conteo(tecla):
        if str(tecla).lower() == "space":
            contador["space"] += 1
        return original_press(tecla)

    auto.pyautogui.press = press_conteo
    try:
        auto.ejecutar_automatizacion(max_filas=max_filas)
    finally:
        auto.pyautogui.press = original_press

    return contador["space"]


def leer_threshold_coincidencia(config_path: Path = CONFIG_CORTES) -> float:
    """Lee el umbral de coincidencia para la validación azul posterior a 007.png.

    Acepta valores en porcentaje (70) o decimal (0.70).
    Prioriza la configuración de la primera parte (`1p_threshold`) para la fila azul.
    """
    default_threshold = 0.70
    if not config_path.exists():
        return default_threshold

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                clave, valor = [p.strip() for p in linea.split("=", 1)]
                if clave in {"1p_threshold", "1p_thresold"}:
                    try:
                        umbral = float(valor)
                        return umbral if umbral <= 1.0 else umbral / 100.0
                    except ValueError:
                        pass
                if clave in {"threshold_default", "default_threshold", "threshold_coincidencia", "coincidencia_threshold"}:
                    try:
                        umbral = float(valor)
                        return umbral if umbral <= 1.0 else umbral / 100.0
                    except ValueError:
                        pass
    except Exception:
        pass

    return default_threshold


def buscar_texto_en_controles(textos_clave, timeout=2.0, poll=0.2):
    """Busca texto visible en controles de tipo Text dentro de las ventanas abiertas.

    Devuelve el texto exacto detectado si coincide con alguna clave, o None si no aparece.
    Se reutiliza para mensajes tipo 'Desea Continuar', 'Desea grabar la resolución', etc.
    """
    desktop = Desktop(backend="uia")
    end_time = time.time() + timeout
    claves = [str(x).lower() for x in textos_clave]

    while time.time() < end_time:
        try:
            for win in desktop.windows():
                try:
                    for desc in win.descendants():
                        try:
                            control_type = getattr(getattr(desc, "element_info", None), "control_type", None)
                            texto = str(desc.window_text() or "").strip()
                            if control_type == "Text" and texto:
                                texto_lower = texto.lower()
                                for clave in claves:
                                    if clave in texto_lower:
                                        return texto
                        except Exception:
                            pass
                except Exception:
                    pass
        except Exception:
            pass
        time.sleep(poll)

    return None


def extraer_numero_del_mensaje(mensaje: str) -> str:
    """Extrae el último bloque numérico encontrado en un mensaje textual."""
    if not mensaje:
        return ""
    matches = re.findall(r"\d+", mensaje)
    if not matches:
        return ""
    return matches[-1]


def guardar_resultado_excel(df, indice_fila: int, valor: str):
    """Guarda el valor de RESULTADO en la fila actual del Excel."""
    if df is None:
        return False
    if "RESULTADO" not in df.columns:
        df["RESULTADO"] = ""
    df.at[indice_fila, "RESULTADO"] = str(valor).strip()
    try:
        df.to_excel(DATA_FILE, index=False)
        return True
    except Exception:
        return False


def main():
    logger = configurar_logger()
    logger.info("Iniciando robot — separador de expedientes")
    logger.info(f"Ruta de ejecución (sys.argv[0]): {sys.argv[0]}")
    logger.info(f"Directorio base detectado: {PROJECT_DIR}")
    logger.info(f"Congelado (ejecutable): {getattr(sys, 'frozen', False)}")
    logger.info(f"IMG_DIR: {IMG_DIR}")
    logger.info(f"DATA_FILE: {DATA_FILE}")

    try:
        # 1) Solicitar datos de ejecución
        modo_ejecucion, usuario_windows, password_windows, password_sirat = solicitar_datos_ejecucion()

        if modo_ejecucion not in (0, 1):
            logger.warning("Modo de ejecución no válido. Se usará el modo 0 por defecto.")
            modo_ejecucion = 0

        if modo_ejecucion == 0 and not password_sirat:
            logger.error("Debe ingresar la contraseña RSIRAT para el modo 0.")
            pausar_si_es_terminal("\nError: falta la contraseña RSIRAT. Presione Enter para salir...")
            return 1

        if modo_ejecucion == 1:
            logger.info("Modo 1 seleccionado: se inicia directamente desde Cobranza Coactiva, sin login.")
        else:
            logger.info("Modo 0 seleccionado: flujo normal con contraseña RSIRAT.")

        shortcut_efectivo = obtener_shortcut_efectivo()
        logger.info(f"Modo de ejecución: {modo_ejecucion} | Acceso directo: {shortcut_efectivo}")

        if not DATA_FILE.exists():
            logger.error(f"No se encontró DATA.xlsx en: {DATA_FILE}")
            logger.error(f"Carpeta base del proyecto: {PROJECT_DIR}")
            logger.error(f"Archivos disponibles en carpeta base:")
            try:
                for item in PROJECT_DIR.iterdir():
                    logger.error(f"  - {item.name}")
            except Exception as e:
                logger.error(f"  Error al listar carpeta: {e}")
            pausar_si_es_terminal("\nError: no se encontró el archivo DATA.xlsx. Presione Enter para salir...")
            return 1

        df = pd.read_excel(DATA_FILE, dtype=str, keep_default_na=False)
        requeridas = ["RUC", "ACUMULADOR", "NRO ACUM", "DEPENDENCIA", "RESULTADO"]
        faltantes = [c for c in requeridas if c not in df.columns]
        if faltantes:
            logger.error(f"Faltan columnas en {DATA_FILE}: {faltantes}")
            pausar_si_es_terminal("\nError: faltan columnas en el Excel. Presione Enter para salir...")
            return 1

        debug_dir = PROJECT_DIR / "debug_automatizador"
        debug_dir.mkdir(parents=True, exist_ok=True)

        controlador = ControladorApp(logger, img_dir=IMG_DIR, cache_path=PROJECT_DIR / "coords_cache.json")

        # Se asume que RSIRAT ya está abierto por el usuario antes de iniciar.
        # No se lanza ni se reabre la aplicación desde aquí.
        if not controlador.open_app(shortcut_path=None):
            logger.warning("RSIRAT no está enfocado; se continuará asumiendo que ya está abierto y se intentará buscar Cobranza Coactiva.")

        # La ejecución comienza directamente desde Cobranza Coactiva.
        # Si el modo es 1, se omite el login y la app se usa directamente.
        for idx, fila in df.iterrows():
            fila_numero = idx + 2
            logger.info(f"={'='*80}")
            logger.info(f"Procesando fila {fila_numero} - RUC={fila['RUC']} ACUM={fila['ACUMULADOR']} DEP={fila['DEPENDENCIA']}")
            logger.info(f"{'='*80}")

            expediente = str(fila['ACUMULADOR']).strip()
            if not validar_expediente_numerico(expediente):
                logger.error(f"Fila {fila_numero}: Expediente '{expediente}' contiene caracteres no numéricos. OMITIDA")
                continue

            dependencia_normalizada = normalizar_dependencia(fila['DEPENDENCIA'])
            logger.info(f"Dependencia normalizada: {dependencia_normalizada}")

            # Login desactivado: se asume que la sesión ya está en RSIRAT y se empieza directamente en Cobranza Coactiva.
            time.sleep(0.5)

            # 5) Cobranza Coactiva (002.png) - 60s timeout
            logger.info(f"[{fila_numero}] Buscando Cobranza Coactiva (002.png)...")
            if not controlador.click_image('002.png', timeout=60.0, poll=0.3):
                logger.error(f"[{fila_numero}] No se pudo clickear Cobranza Coactiva (002.png)")
                continue

            time.sleep(0.5)

            # 6) Exp. Cob. Coactiva - Individual (003.png) x4 - 60s timeout
            logger.info(f"[{fila_numero}] Buscando Exp. Cob. Coactiva - Individual (003.png)...")
            if not controlador.click_image('003.png', clicks=4, timeout=60.0, poll=0.3):
                logger.error(f"[{fila_numero}] No se pudo clickear Exp. Cob. Coactiva - Individual (003.png)")
                continue

            time.sleep(0.5)

            # 7) Click referencia 004.png y digitar ACUMULADOR - 60s timeout
            logger.info(f"[{fila_numero}] Buscando campo de expediente (004.png)...")
            if not controlador.click_image_and_type('004.png', expediente, timeout=60.0, poll=0.3):
                logger.error(f"[{fila_numero}] No se pudo ubicar campo de expediente (004.png) o digitar")
                continue

            logger.info(f"[{fila_numero}] Expediente digitado: {expediente}")
            time.sleep(0.3)

            # 8) TAB para pasar al siguiente campo (se activa selección azul)
            logger.info(f"[{fila_numero}] Presionando TAB...")
            pyautogui.press('tab')

            # 9) Extraer selección azul (primera parte de la fila)
            logger.info(f"[{fila_numero}] Buscando selección azul tras TAB (máx. 10 s)...")
            referencia_guardada = controlador.extraer_seleccion_azul_expediente(
                debug_dir=EXPEDIENTE_REF_DIR,
                num_fila=fila_numero,
                timeout=10.0,
                poll=0.05,
            )

            if referencia_guardada is None or not referencia_guardada.exists():
                logger.error(f"[{fila_numero}] No hay selección azul visible o válida para esta fila; se aborta el procesamiento de esta fila.")
                continue

            # Reemplazo solicitado: tras extraer la selección azul NO se hace TAB + ESPACIO.
            # El flujo pasa directo a buscar 010.png y luego continúa con el flujo normal.
            logger.info(f"[{fila_numero}] Validación por selección azul activa. Buscando 010.png y continuando con el flujo normal...")
            if not controlador.click_image('010.png', clicks=2, timeout=60.0, poll=0.3):
                logger.error(f"[{fila_numero}] No se pudo clickear 010.png después de la extracción azul")
                continue

            logger.info(f"[{fila_numero}] 010.png clickeado exitosamente. Siguiendo con 005.png...")
            time.sleep(0.5)

            # 13) Buscar y clickear 005.png (Acumulación Separación Expedientes) - 60s timeout
            logger.info(f"[{fila_numero}] Buscando Acumulación Separación Expedientes (005.png)...")
            if not controlador.click_image('005.png', timeout=60.0, poll=0.3):
                logger.error(f"[{fila_numero}] No se pudo clickear Acumulación Separación Expedientes (005.png)")
                continue

            time.sleep(0.5)

            # 14) Doble clic en 006.png (Separación Expedientes) - 60s timeout
            logger.info(f"[{fila_numero}] Buscando Separación Expedientes (006.png)...")
            if not controlador.click_image('006.png', clicks=2, timeout=60.0, poll=0.3):
                logger.error(f"[{fila_numero}] No se pudo hacer doble clic en Separación Expedientes (006.png)")
                continue

            time.sleep(0.5)

            # 15) Clic en los tres puntos (007.png) - 60s timeout
            logger.info(f"[{fila_numero}] Buscando tres puntos (007.png)...")
            if not controlador.click_image('007.png', timeout=60.0, poll=0.3):
                logger.error(f"[{fila_numero}] No se pudo clickear tres puntos (007.png)")
                continue

            logger.info(f"[{fila_numero}] Fila base procesada exitosamente (007.png clickeado)")

            # Tras 007.png se espera (máx. 15 s, microbúsqueda de 50 ms) a que la fila azul esté visible
            # y estable antes de compararla con la referencia guardada.
            logger.info(f"[{fila_numero}] Esperando fila azul tras 007.png (máx. 15 s, microbúsqueda)...")
            if controlador._esperar_region_azul(timeout_segundos=15.0, poll_segundos=0.05) is None:
                logger.error(f"[{fila_numero}] No apareció la fila azul tras 007.png en 15 s; se aborta el procesamiento de esta fila.")
                continue

            # El flujo continúa con la validación de la fila por comparación azul.
            img_referencia = debug_dir / f"fila_{fila_numero}_expediente.png"

            if not img_referencia.exists():
                logger.warning(f"[{fila_numero}] Imagen de referencia no encontrada: {img_referencia}")
                continue

            logger.info(f"[{fila_numero}] Verificando coincidencia con selección azul actual...")
            encontrado_coincidencia = False
            max_intentos = 10
            intento = 0
            threshold_similitud = leer_threshold_coincidencia()
            y_anterior = None
            sin_mas_selecciones = False

            while intento < max_intentos and not encontrado_coincidencia:
                # Verificación de coordenada: si tras el DOWN la fila azul quedó en la misma Y,
                # la selección no avanzó y ya no hay más selecciones por comparar.
                y_actual = controlador.obtener_coordenada_seleccion_azul()
                if y_actual is not None and y_actual == y_anterior:
                    logger.warning(f"[{fila_numero}] La coordenada de la selección azul se repite (y={y_actual}); no hay más selecciones por buscar.")
                    sin_mas_selecciones = True
                    break
                y_anterior = y_actual

                logger.info(f"[{fila_numero}] Comparación {intento + 1}/{max_intentos}...")
                similitud = controlador.comparar_selecciones_azules(
                    img1_path=img_referencia,
                    debug_dir=EXPEDIENTE_REF_DIR,
                    num_fila_temp=int(f"{fila_numero}{intento:02d}")
                )

                logger.info(f"[{fila_numero}] Similitud: {similitud:.4f} (threshold: {threshold_similitud:.4f})")

                if similitud >= threshold_similitud:
                    logger.info(f"[{fila_numero}] COINCIDENCIA ENCONTRADA (similitud={similitud:.4f})")
                    encontrado_coincidencia = True

                    logger.info(f"[{fila_numero}] Clic en 008.png...")
                    if controlador.click_image('008.png', timeout=60.0, poll=0.3):
                        logger.info(f"[{fila_numero}] 008.png clickeado exitosamente")

                        logger.info(f"[{fila_numero}] Clic en 009.png...")
                        if not controlador.click_image('009.png', timeout=60.0, poll=0.3):
                            logger.error(f"[{fila_numero}] No se pudo clickear 009.png")
                            time.sleep(0.5)
                            continue

                        # Tras 009.png comienza directamente la extracción, comparación y marcación (0,0,x,0)
                        # que realiza automatizador_expedientes.py. Antes se confirma que la fila azul ya está visible.
                        logger.info(f"[{fila_numero}] Esperando fila azul tras 009.png (máx. 10 s, microbúsqueda)...")
                        if controlador._esperar_region_azul(timeout_segundos=10.0, poll_segundos=0.05) is None:
                            logger.error(f"[{fila_numero}] No apareció la fila azul tras 009.png; se aborta la marcación de esta fila.")
                            time.sleep(0.5)
                            continue

                        logger.info(f"[{fila_numero}] Iniciando marcación con automatizador_expedientes()...")
                        cantidad_esperada = obtener_cantidad_esperada_columna_c(fila)
                        cantidad_marcada = ejecutar_marcacion_separacion(
                            max_filas=max(20, int(cantidad_esperada) if cantidad_esperada is not None else 20)
                        )
                        logger.info(
                            f"[{fila_numero}] Marcación ejecutada: {cantidad_marcada}"
                            f" | Esperado en columna C: {cantidad_esperada}"
                        )

                        if cantidad_esperada is not None and cantidad_marcada != cantidad_esperada:
                            logger.warning(
                                f"[{fila_numero}] La cantidad marcada ({cantidad_marcada}) no coincide con "
                                f"la columna C ({cantidad_esperada})."
                            )
                        elif cantidad_esperada is not None:
                            logger.info(f"[{fila_numero}] Cantidad marcada coincide con la columna C.")

                        logger.info(f"[{fila_numero}] Clic en 010.png...")
                        if not controlador.click_image('010.png', timeout=60.0, poll=0.3):
                            logger.error(f"[{fila_numero}] No se pudo clickear 010.png")
                            break

                        logger.info(f"[{fila_numero}] 010.png clickeado exitosamente")
                        logger.info(f"[{fila_numero}] Esperando mensajes posteriores a 010.png (máximo 2 minutos)...")

                        inicio_espera_010 = time.time()
                        resolucion_detectada = False
                        while time.time() - inicio_espera_010 < 120:
                            mensaje_no_info = buscar_texto_en_controles([
                                "no se encontro informacion",
                                "no se encontró información",
                                "informacion para la ayuda seleccionada",
                                "información para la ayuda seleccionada",
                            ], timeout=0.5, poll=0.2)
                            if mensaje_no_info:
                                logger.warning(f"[{fila_numero}] Mensaje detectado: {mensaje_no_info}")
                                logger.warning(f"[{fila_numero}] Se vuelve a intentar 010.png para reintentar la ayuda...")
                                if not controlador.click_image('010.png', timeout=30.0, poll=0.3):
                                    logger.warning(f"[{fila_numero}] No fue posible reintentar 010.png")
                                time.sleep(0.5)
                                continue

                            mensaje_grabar = buscar_texto_en_controles([
                                "desea ud grabar la resolución",
                                "desea grabar la resolución",
                                "desea usted grabar la resolución",
                                "grabar la resolución",
                            ], timeout=0.5, poll=0.2)
                            if mensaje_grabar:
                                logger.warning(f"[{fila_numero}] Mensaje detectado: {mensaje_grabar}")
                                logger.info(f"[{fila_numero}] Presionando Alt+S para aceptar grabación...")
                                pyautogui.hotkey('alt', 's')
                                time.sleep(1.0)
                                continue

                            mensaje_continuar = buscar_texto_en_controles([
                                "desea continuar",
                                "desea ud continuar",
                                "desea usted continuar",
                            ], timeout=0.5, poll=0.2)
                            if mensaje_continuar:
                                logger.warning(f"[{fila_numero}] Mensaje detectado: {mensaje_continuar}")
                                logger.info(f"[{fila_numero}] Presionando Alt+S para continuar...")
                                pyautogui.hotkey('alt', 's')
                                time.sleep(1.0)
                                continue

                            mensaje_resolucion = buscar_texto_en_controles([
                                "se grabo la resolución coactiva",
                                "se grabó la resolución coactiva",
                                "resolución coactiva",
                                "resolucion coactiva",
                            ], timeout=0.5, poll=0.2)
                            if mensaje_resolucion:
                                logger.warning(f"[{fila_numero}] RESOLUCIÓN COACTIVA DETECTADA: {mensaje_resolucion}")
                                rc_num = extraer_numero_del_mensaje(mensaje_resolucion)

                                fecha_hora = datetime.now().strftime("%Y%m%d_%H%M%S")
                                ruta_captura = RESOLUCIONES_DIR / f"resolucion_coactiva_{fila_numero}_{fecha_hora}.png"
                                captura = pyautogui.screenshot()
                                captura.save(ruta_captura)
                                logger.info(f"[{fila_numero}] Captura guardada: {ruta_captura}")

                                if rc_num:
                                    logger.info(f"[{fila_numero}] Número de RC extraído: {rc_num}")
                                    guardado = guardar_resultado_excel(df, idx, rc_num)
                                    if guardado:
                                        logger.info(f"[{fila_numero}] Resultado guardado en Excel: {rc_num}")
                                    else:
                                        logger.warning(f"[{fila_numero}] No se pudo guardar el resultado en Excel.")
                                else:
                                    logger.warning(f"[{fila_numero}] No se pudo extraer un número de resolución coactiva.")
                                    guardado = guardar_resultado_excel(df, idx, str(mensaje_resolucion)[:200])
                                    if guardado:
                                        logger.info(f"[{fila_numero}] Texto de resolución guardado en Excel como fallback.")

                                logger.info(f"[{fila_numero}] Clic final en 010.png para continuar...")
                                if not controlador.click_image('010.png', timeout=30.0, poll=0.3):
                                    logger.warning(f"[{fila_numero}] No fue posible hacer clic en 010.png después de detectar la resolución coactiva.")
                                resolucion_detectada = True
                                break

                            time.sleep(0.5)

                        if not resolucion_detectada:
                            logger.warning(f"[{fila_numero}] No se detectó mensaje de resolución coactiva ni mensaje de error dentro de 2 minutos.")

                        break
                    else:
                        logger.error(f"[{fila_numero}] Fallo al clickear 008.png")

                    time.sleep(0.5)
                else:
                    logger.info(f"[{fila_numero}] No coincide ({similitud:.4f}), bajando a siguiente selección azul...")
                    intento += 1

                    if intento < max_intentos:
                        pyautogui.press('down')
                        time.sleep(0.5)

            if not encontrado_coincidencia:
                if sin_mas_selecciones:
                    logger.warning(f"[{fila_numero}] No se encontró coincidencia: se recorrieron todas las selecciones disponibles ({intento} comparadas)")
                else:
                    logger.warning(f"[{fila_numero}] No se encontró coincidencia tras {max_intentos} intentos")

            time.sleep(0.5)

        logger.info('=' * 80)
        logger.info("Proceso finalizado")
        logger.info('=' * 80)
        pausar_si_es_terminal("\nProceso finalizado. Presione Enter para salir...")
        return 0
    except Exception:
        logger.exception("Error no controlado en la ejecución")
        pausar_si_es_terminal("\nSe produjo un error. Presione Enter para salir...")
        return 1


if __name__ == '__main__':
    sys.exit(main())
