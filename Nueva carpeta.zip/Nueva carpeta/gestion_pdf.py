from PyPDF2 import PdfReader
import re

def extraer_nueva_placa(directorio_documento):
    
    documento = PdfReader(directorio_documento)

    pagina_princpial = documento.pages[0].extract_text()

    # Convertir el texto a mayúsculas y eliminar espacios
    texto_mayusculas = pagina_princpial.upper().replace(" ", "")

    # Expresión regular para encontrar la nueva placa
    regex = r'NUEVAPLACA:([A-Z0-9]+)'
    match = re.search(regex, texto_mayusculas)

    if match:
        # Si se encuentra una coincidencia, devolver la nueva placa
        nueva_placa = match.group(1)
        return nueva_placa
    else:
        print("No se encontró la nueva placa.")