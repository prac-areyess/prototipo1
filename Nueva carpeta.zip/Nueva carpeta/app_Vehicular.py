from selenium_service import ServiceSelenium
from easy_ocr import obtener_valor_captcha
from excel_service import ExcelService
from monitoreo_descarga import descarga_completa_boleta
from gestion_directorio import crear_carpeta, mover_y_renombrar_archivo, leer_contenido_archivo
from gestionar_fechas import formato_carpeta_descarga
from gestion_pdf import extraer_nueva_placa

import os
import time

xpath = 'xpath'
css_selector = 'css_selector'

URL_SUNARP = "https://sprl.sunarp.gob.pe/sprl/ingreso"

directorio_base = os.getcwd()
nombre_carpeta_descarga = formato_carpeta_descarga('RESULTADO_VEHICULAR_')
directorio_descarga = crear_carpeta(directorio_base, nombre_carpeta_descarga)
excel_data_vehicular_base = os.path.join(directorio_base + 'DATA_VEHICULAR.xlsx')

#directorio_descarga = os.path.join(os.getcwd(), 'Descargas')

encabezado = ["PLACA","ESTADO","FECHA_INSCRIPCION","FECHA_PROPIEDAD","CONDICION","PARTIDA_REGISTRAL","CLASE","MARCA",
    "AÑO_FABRICACION","MODELO","COMBUSTIBLE","CARROCERIA","Nº_EJES","COLORES","Nº_MOTOR","Nº_CILINDROS","Nº_SERIE",
    "Nº_RUEDAS","Nº_PASAJEROS","Nº_ASIENTOS","PESO_SECO","PESO_BRUTO","LONGITUD","ALTURA","ANCHO","CARGA_UTIL","PROPIETARIOS",
    "DIRECCION","TITULO","ESTADO_1","AFECTACION","FECHA_AFECTACION","Nº_DOC","TITULO_1","JUZGADO",	
    "CAUSA_AFECTACION","JUEZ","SECRETARIO","MODIFICACION","JUEZ_DESCARGO","SECRETARIO_DESCARGO","FECHA_DESCARGO",
    "Nº_EXP_DESCARGO","PARTICIPANTE_GRAVAMEN_1","TIPO_PARTICIPACION_1","PARTICIPANTE_GRAVAMEN_2","TIPO_PARTICIPACION_2",
    "PARTICIPANTE_GRAVAMEN_3","TIPO_PARTICIPACION_3","NUEVA_PLACA","TIENE_GRAVAMEN","OFICINA_REGISTRAL"]

excel_resultado_vehicular = ExcelService()
excel_resultado_vehicular.crear_documento_excel()
excel_resultado_vehicular.seleccionar_hoja('Sheet')
excel_resultado_vehicular.agregar_fila_excel(encabezado)

estado_consulta = True

while estado_consulta:

    try:

        driver = ServiceSelenium('.\\chromedriver.exe', directorio_descarga)

        print('Navegando a Sunarp ....')
        driver.navegar_a_sunarp(URL_SUNARP)

        driver.clickear_elemento(xpath,"//nz-form-item/nz-form-control/div/div/div/button")

        time.sleep(2)
        print('Digitando Usuario ....')
        driver.escribir_texto(css_selector, 'input[name="username"]', leer_contenido_archivo(directorio_base, 'usuario.txt'))

        time.sleep(2)
        print('Digitando Contraseña ...')
        driver.escribir_texto(css_selector, 'input[name="password"]', leer_contenido_archivo(directorio_base, 'contraseña.txt'))
        
        time.sleep(2)
        print('Iniciando Sesión ...')
        
        driver.clickear_elemento_JavaScript(xpath, '//*[@id="l-login"]/div[4]/button')

        excel_data_vehicular = ExcelService()
        
        hojas_placas_vehiculares = "Placas_Vehiculares"

        excel_data_vehicular.abrir_documento_excel(directorio_base, 'DATA_VEHICULAR')
        excel_data_vehicular.seleccionar_hoja(hojas_placas_vehiculares)

        numero_filas = excel_data_vehicular.obtener_numero_filas() + 1
        numero_columas = excel_data_vehicular.obtener_numero_columnas() + 1 

        for fila in range(2, numero_filas):

            numero_placa = excel_data_vehicular.obtener_contenido_de_celda(fila, 1)
            oficina_registral = excel_data_vehicular.obtener_contenido_de_celda(fila, 2)
            resultado = excel_data_vehicular.obtener_contenido_de_celda(fila, 3) if excel_data_vehicular.obtener_contenido_de_celda(fila, 3) else None  


            if resultado == None:
                
                print(f'-----> Número de consulta {fila-1} de {numero_filas - 2} <-----')

                time.sleep(5)
            
                driver.escribir_texto(xpath, '//nz-select/nz-select-top-control/nz-select-search/input', oficina_registral)
                driver.presionar_tecla(xpath, '//nz-select/nz-select-top-control/nz-select-search/input', 'enter')

                driver.clickear_elemento_JavaScript(css_selector,'nz-select-item[title="Propiedad Inmueble Predial"]')
                driver.clickear_elemento_JavaScript(css_selector, 'nz-option-item[title="Propiedad Vehicular"]')
                driver.clickear_elemento(css_selector, 'input[id="numero"]')

                driver.escribir_texto(css_selector,'input[id="numero"]', numero_placa)

                captcha_resuelto = False

                while captcha_resuelto == False:
                    #Tomamos una captura al captcha
                    driver.capturar_elemento(css_selector, 'img[class="img-captcha"]', 'image_captcha.png')
                    texto_captcha = obtener_valor_captcha(".\\image_captcha.png")
                    driver.escribir_texto(css_selector,'input[id="codigoCaptcha"]', texto_captcha)
                    driver.clickear_elemento(css_selector,'button[class="ant-btn ant-btn-primary"]')

                    tiempo_espera = 15 

                    texto_captcha_incorrecto = driver.capturar_texto(xpath,'//nz-modal-confirm-container/div/div/div/div/div[1]/span', tiempo_espera)

                    if texto_captcha_incorrecto:
                            if 'valor' in texto_captcha_incorrecto.lower():
                                driver.clickear_elemento(xpath,'//nz-modal-confirm-container/div/div/div/div/div[2]/button')
                                driver.clickear_elemento(css_selector,'svg[data-icon="sync"]')
                                driver.limpiar_campo_texto(css_selector,'input[id="codigoCaptcha"]')
                                time.sleep(4)
                    
                    if texto_captcha_incorrecto:
                            if 'placa' in texto_captcha_incorrecto.lower():
                                driver.refrescar_pagina()
                                excel_data_vehicular.escribir_contenido_en_celda(fila, 3, 'NO ENCONTRADO')
                                excel_data_vehicular.guardar_documento_excel(directorio_base, 'DATA_VEHICULAR')
                                excel_data_vehicular.guardar_documento_excel(directorio_descarga, 'RESULTADO_DATA_VEHICULAR')

                    else:
                        print('-> Captcha resuelto')
                        captcha_resuelto = True
                        break
                
                if captcha_resuelto:

                    driver.clickear_elemento_JavaScript(xpath, '//td[8]/app-button/div/div/button')

                    driver.clickear_elemento_JavaScript(xpath, "//div/div[2]/button[2]/span[contains(text(), 'Aceptar')]")

                    directorio_documento = descarga_completa_boleta(directorio_descarga)

                    if directorio_documento:
                        print('--> Boleta Informativa descargada con éxito')
                        nombre_directorio = f'{fila-1}_{numero_placa}'
                        directorio_placa_vehicular = crear_carpeta(directorio_descarga, nombre_directorio)
                        directorio_boleta_final = mover_y_renombrar_archivo(directorio_documento, directorio_placa_vehicular, f'{numero_placa}.pdf')

                    driver.clickear_elemento_JavaScript(xpath,'//td[6]/app-button/div/div/button')

                    driver.clickear_elemento_JavaScript(xpath, "//div/div[2]/button[2]/span[contains(text(), 'Aceptar')]")

                    datos_vehiculo = {}

                    datos_vehiculo['PLACA'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[1]/td[2]')
                    datos_vehiculo['ESTADO'] = driver.capturar_texto(xpath, '//nz-table-inner-default/div/table/tbody/tr[2]/td[2]')
                    datos_vehiculo['FECHA_INSCRIPCION'] = driver.capturar_texto(xpath, '//nz-table-inner-default/div/table/tbody/tr[3]/td[2]')
                    datos_vehiculo['FECHA_PROPIEDAD'] = driver.capturar_texto(xpath, '//nz-table-inner-default/div/table/tbody/tr[4]/td[2]')
                    datos_vehiculo['CONDICION'] = driver.capturar_texto(xpath, '//nz-table-inner-default/div/table/tbody/tr[5]/td[2]')
                    datos_vehiculo['PARTIDA_REGISTRAL'] = driver.capturar_texto(xpath, '//nz-table-inner-default/div/table/tbody/tr[6]/td[2]')

                    datos_vehiculo['CLASE'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[1]/td[1]/div/p[2]')
                    datos_vehiculo['MARCA'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[1]/td[2]/div/p[2]')
                    datos_vehiculo['AÑO_FABRICACION'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[1]/td[3]/div/p[2]')

                    datos_vehiculo['MODELO'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[2]/td[1]/div/p[2]')
                    datos_vehiculo['COMBUSTIBLE'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[2]/td[2]/div/p[2]')

                    datos_vehiculo['CARROCERIA'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[3]/td[1]/div/p[2]')
                    datos_vehiculo['Nº_EJES'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[3]/td[2]/div/p[2]')

                    datos_vehiculo['COLORES'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[4]/td[1]/div/p[2]')

                    datos_vehiculo['Nº_MOTOR'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[5]/td[1]/div/p[2]')
                    datos_vehiculo['Nº_CILINDROS'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[5]/td[2]/div/p[2]')

                    datos_vehiculo['Nº_SERIE'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[6]/td[1]/div/p[2]')
                    datos_vehiculo['Nº_RUEDAS'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[6]/td[2]/div/p[2]')

                    datos_vehiculo['Nº_PASAJEROS'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[7]/td[1]/div/p[2]')
                    datos_vehiculo['Nº_ASIENTOS'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[7]/td[2]/div/p[2]')
                    datos_vehiculo['PESO_SECO'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[7]/td[3]/div/p[2]')
                    datos_vehiculo['PESO_BRUTO'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[7]/td[4]/div/p[2]')

                    datos_vehiculo['LONGITUD'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[8]/td[1]/div/p[2]')
                    datos_vehiculo['ALTURA'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[8]/td[2]/div/p[2]')
                    datos_vehiculo['ANCHO'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[8]/td[3]/div/p[2]')
                    datos_vehiculo['CARGA_UTIL'] = driver.capturar_texto(xpath,'//nz-table-inner-default/div/table/tbody/tr[8]/td[4]/div/p[2]')

                    propietarios = driver.obtener_elementos(xpath,'//busqueda-directa-partidas-detalle/nz-layout/div[1]/div[3]/div[1]/div/nz-card/div/nz-table/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr')

                    nombre_propietarios = ""
                    direccion_propietarios = ""
                    titulo_propietarios = "" 
                    
                    if propietarios:
                        for propietario in propietarios:
                            nombre_propietario = propietario.find_element(xpath, './td[1]')
                            direccion_propietario = propietario.find_element(xpath, './td[2]')
                            titulo_propietario = propietario.find_element(xpath, './td[3]')

                            nombre_propietarios += nombre_propietario.text + ";"
                            direccion_propietarios += direccion_propietario.text + ";"
                            titulo_propietarios += titulo_propietario.text + ";"

                        datos_vehiculo['PROPIETARIOS'] = nombre_propietarios
                        datos_vehiculo['DIRECCION']= direccion_propietarios
                        datos_vehiculo['TITULO'] = titulo_propietarios

                        gravamenes = driver.obtener_elementos(xpath,'//busqueda-directa-partidas-detalle/nz-layout/div[1]/div[3]/div[2]/div[2]/div/nz-card/div')

                        if gravamenes:

                            for gravamen in gravamenes:
                                datos_vehiculo['ESTADO_1'] = gravamen.find_element(xpath,'./nz-table[1]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[1]').text
                                datos_vehiculo['AFECTACION'] = gravamen.find_element(xpath,f'./nz-table[1]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[2]').text
                                datos_vehiculo['FECHA_AFECTACION'] = gravamen.find_element(xpath,f'./nz-table[1]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[3]').text
                                datos_vehiculo['Nº_DOC'] = gravamen.find_element(xpath,f'./nz-table[1]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[4]').text
                                datos_vehiculo['TITULO_1'] = gravamen.find_element(xpath,f'./nz-table[1]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[5]').text
                                datos_vehiculo['JUZGADO'] = gravamen.find_element(xpath,f'./nz-table[1]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[6]').text
                                datos_vehiculo['CAUSA_AFECTACION'] = gravamen.find_element(xpath,f'./nz-table[1]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[7]').text
                                datos_vehiculo['JUEZ'] = gravamen.find_element(xpath,f'./nz-table[2]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[1]').text
                                datos_vehiculo['SECRETARIO'] = gravamen.find_element(xpath,f'./nz-table[2]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[2]').text
                                datos_vehiculo['MODIFICACION'] = gravamen.find_element(xpath,f'./nz-table[2]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[3]').text
                                datos_vehiculo['JUEZ_DESCARGO'] = gravamen.find_element(xpath,f'./nz-table[2]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[4]').text
                                datos_vehiculo['SECRETARIO_DESCARGO'] = gravamen.find_element(xpath,f'./nz-table[2]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[5]').text
                                datos_vehiculo['FECHA_DESCARGO'] = gravamen.find_element(xpath,f'./nz-table[2]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[6]').text
                                datos_vehiculo['Nº_EXP_DESCARGO'] = gravamen.find_element(xpath,f'./nz-table[2]/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr/td[7]').text

                                participantes = gravamen.find_elements(xpath,'./nz-table[3]/nz-spin/div/div/nz-table-inner-default/div/table/tbody')

                                for indice, participante in enumerate(participantes):
                                    if indice < 3:
                                        datos_vehiculo[f'PARTICIPANTE_GRAVAMEN_{indice+1}'] = participante.find_element(xpath, './tr/td[1]').text
                                        datos_vehiculo[f'TIPO_PARTICIPACION_{indice+1}'] = participante.find_element(xpath, './tr/td[2]').text
                                    
                                datos_vehiculo["NUEVA_PLACA"] = "NO"
                                datos_vehiculo["TIENE_GRAVAMEN"] = "SÍ"
                                datos_vehiculo["OFICINA_REGISTRAL"] = oficina_registral

                                datos = [datos_vehiculo.get(titulo_columna, None) for titulo_columna in encabezado]

                                excel_resultado_vehicular.agregar_fila_excel(datos)

                                excel_resultado_vehicular.guardar_documento_excel(directorio_descarga, 'RESULTADO_CONSULTA_SUNARP_VEHICULAR')

                                excel_data_vehicular.escribir_contenido_en_celda(fila, 3, 'ENCONTRADO')

                                excel_data_vehicular.guardar_documento_excel(directorio_base, 'DATA_VEHICULAR')

                                excel_data_vehicular.guardar_documento_excel(directorio_descarga, 'RESULTADO_DATA_VEHICULAR')

                        else:

                            datos_vehiculo["NUEVA_PLACA"] = "NO"
                            datos_vehiculo["TIENE_GRAVAMEN"] = "NO"
                            datos_vehiculo["OFICINA_REGISTRAL"] = oficina_registral

                            datos = [datos_vehiculo.get(titulo_columna, None) for titulo_columna in encabezado]

                            excel_resultado_vehicular.agregar_fila_excel(datos)

                            excel_resultado_vehicular.guardar_documento_excel(directorio_descarga, 'RESULTADO_CONSULTA_SUNARP_VEHICULAR')

                            excel_data_vehicular.escribir_contenido_en_celda(fila, 3, 'ENCONTRADO')

                            excel_data_vehicular.guardar_documento_excel(directorio_base, 'DATA_VEHICULAR')

                            excel_data_vehicular.guardar_documento_excel(directorio_descarga, 'RESULTADO_DATA_VEHICULAR')

                    else:

                        datos_vehiculo["NUEVA_PLACA"] = extraer_nueva_placa(directorio_boleta_final)
                        datos_vehiculo["TIENE_GRAVAMEN"] = " - "
                        datos_vehiculo["OFICINA_REGISTRAL"] = oficina_registral

                        datos = [datos_vehiculo.get(titulo_columna, None) for titulo_columna in encabezado]

                        excel_resultado_vehicular.agregar_fila_excel(datos)

                        excel_resultado_vehicular.guardar_documento_excel(directorio_descarga, 'RESULTADO_CONSULTA_SUNARP_VEHICULAR')

                        excel_data_vehicular.escribir_contenido_en_celda(fila, 3, 'ENCONTRADO')

                        excel_data_vehicular.guardar_documento_excel(directorio_base, 'DATA_VEHICULAR')

                        excel_data_vehicular.guardar_documento_excel(directorio_descarga, 'RESULTADO_DATA_VEHICULAR')

                    driver.clickear_elemento_JavaScript(xpath,'//nz-layout/nz-layout/nz-sider/div/app-sidenav-menu2/ul/li[1]/div[2]/ul/li[7]')

                    if fila == numero_filas - 1 :
                        estado_consulta = False
                        print('Las consultas han finalizado con éxito')
                        driver.cerrar_navegador()
                        break

            elif (resultado is not None) and (resultado.lower() == "encontrado" or resultado.lower() == "no encontrado"):
                
                if fila == numero_filas - 1 :
                        estado_consulta = False
                        print('Las consultas han finalizado con éxito')
                        driver.cerrar_navegador()
                        break
                else:
                    print('Siguiente consulta')
                    os.system('cls')

    
    except Exception as e:
        print(f'Se ha producido un error en la consulta: {e}')
        print('Reiniciando navegador...')
    time.sleep(15)
