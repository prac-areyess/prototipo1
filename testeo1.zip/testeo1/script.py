from pywinauto.application import Application
from pywinauto.keyboard import send_keys
import time
import os

# Ruta al acceso directo
shortcut_path = r'D:\Usuarios\prac-areyess\Documents\Proyectos\Testeo\Actualiza RSIRAT.lnk'

# Ejecutar el acceso directo
os.startfile(shortcut_path)
print("🟢 RSIRAT iniciado.")
time.sleep(10)  # Esperar a que cargue

# Conectar con la aplicación
app = Application(backend="uia").connect(title_re=".*SIRAT.*")
windows = app.windows()

# Tomar la última ventana emergente
if not windows:
    print("❌ No se encontró ninguna ventana de SIRAT.")
    exit()

target_window = app.window(handle=windows[-1].handle)

# Paso 1: Seleccionar la dependencia
try:
    combo = target_window.child_window(control_type="ComboBox")
    combo.select("0021 I.R. Lima - PRICO")
    print("✅ Dependencia seleccionada.")
except Exception as e:
    print("❌ No se pudo seleccionar la dependencia:", e)

# Paso 2: Buscar el campo de contraseña entre los Edit
try:
    edits = target_window.descendants(control_type="Edit")
    print(f"🔍 Se encontraron {len(edits)} campos Edit.")
    
    # Mostrar los handles para depurar
    for i, edit in enumerate(edits):
        print(f"Edit[{i}] - hwnd: {edit.handle}")

    # Usar el último campo Edit como contraseña (ajustable)
    password_field = edits[-1]
    password_field.set_focus()
    password_field.type_keys("12345678abc@", with_spaces=True)
    print("✅ Contraseña ingresada.")
except Exception as e:
    print("❌ No se pudo ingresar la contraseña:", e)

# Paso 3: Activar "Aceptar" usando Alt + A
try:
    send_keys('%a')  # Alt + A
    print("✅ Se hizo clic en 'Aceptar' usando Alt+A.")
except Exception as e:
    print("❌ No se pudo activar 'Aceptar' con Alt+A:", e)
