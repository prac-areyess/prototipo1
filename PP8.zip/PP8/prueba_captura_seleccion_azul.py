import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import ImageGrab


def _obtener_ruta_base():
    """Devuelve la ruta base tanto para script como para ejecutable .exe."""
    try:
        if getattr(sys, 'frozen', False):
            return Path(sys.executable).resolve().parent
    except Exception:
        pass

    try:
        ruta = Path(sys.argv[0]).resolve().parent
        if ruta.exists():
            return ruta
    except Exception:
        pass

    return Path(__file__).resolve().parent


def pausar_si_es_terminal(mensaje: str = "\nPresione Enter para cerrar..."):
    """Pausa solo si se ejecuta en una terminal interactiva."""
    try:
        if sys.stdin is not None and hasattr(sys.stdin, "isatty") and sys.stdin.isatty():
            input(mensaje)
    except EOFError:
        pass


BASE_DIR = _obtener_ruta_base()
CONFIG_PATH = BASE_DIR / "configuracion_corte.txt"
DEBUG_DIR = BASE_DIR / "debug_automatizador" / "prueba_captura_azul"
DEBUG_DIR.mkdir(parents=True, exist_ok=True)


def leer_configuracion_roi():
    porcentaje = 20
    min_px = 300
    margen_superior = 5
    margen_inferior = 10
    margen_izquierdo = 0
    ancho_base = 1920
    escala = 1.0
    threshold = 75

    if not CONFIG_PATH.exists():
        return porcentaje, min_px, margen_superior, margen_inferior, margen_izquierdo, ancho_base, escala, threshold

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        for linea in f:
            linea = linea.strip()
            if not linea or linea.startswith("#") or "=" not in linea:
                continue
            clave, valor = [p.strip() for p in linea.split("=", 1)]

            if clave == "1p_primera_parte_porcentaje":
                try:
                    porcentaje = int(float(valor))
                except ValueError:
                    pass
            elif clave == "1p_primera_parte_min_px":
                try:
                    min_px = int(float(valor))
                except ValueError:
                    pass
            elif clave == "1p_margen_superior":
                try:
                    margen_superior = int(float(valor))
                except ValueError:
                    pass
            elif clave == "1p_margen_inferior":
                try:
                    margen_inferior = int(float(valor))
                except ValueError:
                    pass
            elif clave == "1p_margen_izquierdo":
                try:
                    margen_izquierdo = int(float(valor))
                except ValueError:
                    pass
            elif clave == "1p_ancho_pantalla_base":
                try:
                    ancho_base = int(float(valor))
                    if ancho_base <= 0:
                        ancho_base = 1920
                except ValueError:
                    pass
            elif clave in {"1p_escala", "1p_escala_azul"}:
                try:
                    escala = float(valor)
                    if escala <= 0:
                        escala = 1.0
                except ValueError:
                    pass
            elif clave in {"1p_threshold"}:
                try:
                    threshold = float(valor)
                    if threshold <= 0:
                        threshold = 75
                except ValueError:
                    pass
    return porcentaje, min_px, margen_superior, margen_inferior, margen_izquierdo, ancho_base, escala, threshold


def detectar_region_azul(img_bgr):
    if img_bgr is None or img_bgr.size == 0:
        return None

    h, w = img_bgr.shape[:2]
    b = img_bgr[:, :, 0].astype(np.int16)
    g = img_bgr[:, :, 1].astype(np.int16)
    r = img_bgr[:, :, 2].astype(np.int16)

    mascara_azul = (b > 110) & (b > g + 25) & (b > r + 25)
    num_componentes, _, stats, _ = cv2.connectedComponentsWithStats(mascara_azul.astype(np.uint8), 8)

    candidatos = []
    for i in range(1, num_componentes):
        x, y, ancho, alto, area = stats[i]
        if ancho > 80 and alto > 8 and area > 300:
            candidatos.append((area, x, y, ancho, alto))

    if not candidatos:
        return None

    porcentaje, min_px, _, _, _, ancho_base, _, _ = leer_configuracion_roi()
    ancho_base_uso = ancho_base if ancho_base > 0 else max(1, w)
    ancho_esperado = max(min_px, int(ancho_base_uso * porcentaje / 100))
    ancho_esperado = min(ancho_esperado, max(1, w))

    mejor = None
    mejor_score = None
    for area, x, y, ancho, alto in candidatos:
        x_prioridad = 0 if x <= w * 0.75 else 1
        ancho_diff = abs(ancho - ancho_esperado)
        distancia_borde = abs((x + ancho) - w)
        score = (x_prioridad, ancho_diff / max(1, ancho_esperado), distancia_borde / max(1, w), x)
        if mejor_score is None or score < mejor_score:
            mejor_score = score
            mejor = (area, x, y, ancho, alto)

    if mejor is None:
        return None

    _, x, y, ancho, alto = mejor
    x0 = max(0, x - 10)
    y0 = max(0, y - 5)
    x1 = min(w, x + ancho + 10)
    y1 = min(h, y + alto + 10)
    return (x0, y0, x1, y1)


def recortar_region_azul(img_bgr):
    coords = detectar_region_azul(img_bgr)
    if coords is None:
        return None

    x0, y0, x1, y1 = coords
    porcentaje, min_px, margen_superior, margen_inferior, margen_izquierdo, ancho_base, escala, threshold = leer_configuracion_roi()

    ancho_total = max(1, img_bgr.shape[1])
    ancho_esperado = max(min_px, int(ancho_total * porcentaje / 100))
    x_recorte_izq = max(0, x0 + margen_izquierdo)
    x_recorte_der = min(img_bgr.shape[1], x_recorte_izq + ancho_esperado)

    y0_ajustado = max(0, y0 + margen_superior)
    y1_ajustado = max(y0_ajustado + 1, y1 - margen_inferior)

    roi = img_bgr[y0_ajustado:y1_ajustado, x_recorte_izq:x_recorte_der]
    if roi.size == 0:
        return None
    return roi


def guardar_debug(img_bgr, roi, nombre):
    out_dir = DEBUG_DIR / "resultado"
    out_dir.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_dir / f"{nombre}_full.png"), img_bgr)
    if roi is not None:
        cv2.imwrite(str(out_dir / f"{nombre}_roi.png"), roi)


def esperar_region_azul(timeout_segundos: float = 8.0, poll_segundos: float = 0.2):
    """Espera a que aparezca la región azul activa tras presionar TAB.

    No usa una espera fija, sino que revisa la pantalla periódicamente hasta que
    la selección azul quede visible o se agote el timeout.
    """
    fin = time.time() + timeout_segundos
    ultima_lectura = None
    while time.time() < fin:
        try:
            screenshot = np.array(ImageGrab.grab())
            img_bgr = cv2.cvtColor(screenshot, cv2.COLOR_RGB2BGR)
            roi = recortar_region_azul(img_bgr)
            if roi is not None:
                return img_bgr, roi
            ultima_lectura = img_bgr
        except Exception:
            pass
        time.sleep(poll_segundos)

    return ultima_lectura, None


def main():
    print("=== PRUEBA DE CAPTURA DE SELECCIÓN AZUL ===")
    print("Instrucciones:")
    print("1) Focaliza la ventana de SIRAT.")
    print("2) Presiona TAB en la aplicación para activar la selección azul.")
    print("3) La prueba buscará la selección azul automáticamente durante unos segundos después del TAB.")
    print("4) Cuando la detecte, tomará la captura desde la parte izquierda del bloque azul y aplicará margen_izquierdo.")
    print()
    print("Esperando 2 segundos para enfocar la pantalla...")
    time.sleep(2)

    print("Presiona TAB en la aplicación ahora.")
    print("La prueba va a buscar la selección azul automáticamente tras el TAB...")
    img_bgr, roi = esperar_region_azul(timeout_segundos=8.0, poll_segundos=0.2)

    porcentaje, min_px, margen_superior, margen_inferior, margen_izquierdo, ancho_base, escala, threshold = leer_configuracion_roi()
    print(f"Configuración leída: porcentaje={porcentaje}, min_px={min_px}, margen_superior={margen_superior}, margen_inferior={margen_inferior}, margen_izquierdo={margen_izquierdo}, ancho_base={ancho_base}, escala={escala}, threshold={threshold}")
    print(f"Tamaño full: {0 if img_bgr is None else img_bgr.shape[1]}x{0 if img_bgr is None else img_bgr.shape[0]}")
    print(f"Tamaño ROI: {None if roi is None else roi.shape[1]}x{None if roi is None else roi.shape[0]}")

    if roi is not None:
        guardar_debug(img_bgr, roi, "prueba_azul")
        print(f"ROI guardada en: {DEBUG_DIR / 'resultado'}")
        print("La captura fue válida y quedó recortada con el margen izquierdo configurado.")
    else:
        guardar_debug(img_bgr, None, "prueba_azul")
        print("No se detectó una región azul válida con el recorte esperado.")
        print("Esto indica que la captura se tomó demasiado pronto o que la selección azul aún no está activa.")

    pausar_si_es_terminal()


if __name__ == "__main__":
    try:
        main()
    finally:
        pausar_si_es_terminal()
