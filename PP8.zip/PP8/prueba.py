import cv2
import numpy as np
import pyautogui
import time
import os
import sys
from contextlib import redirect_stdout

IMG_FOLDER = "IMG"
RESULT_FOLDER = os.path.join("resultado")
SECUENCIA_IMAGENES = [f"{numero:03d}.png" for numero in range(2, 9)]
ESCALAS = [0.80, 0.85, 0.90, 0.95, 1.00, 1.05, 1.10]
THRESHOLDS = [0.60, 0.65, 0.70, 0.71, 0.72, 0.75, 0.80, 0.85]


class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for stream in self.streams:
            if stream is not None:
                stream.write(data)

    def flush(self):
        for stream in self.streams:
            if stream is not None and hasattr(stream, "flush"):
                stream.flush()

    def isatty(self):
        return False


def crear_carpeta_resultados():
    os.makedirs(RESULT_FOLDER, exist_ok=True)


def esperar_enfoque(segundos=2):
    print(f"Esperando {segundos} segundos para enfocar la aplicación...")
    time.sleep(segundos)


def ejecutar_prueba(img_name):
    img_path = os.path.join(IMG_FOLDER, img_name)
    template_original = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

    if template_original is None:
        print(f"ERROR: No se pudo cargar {os.path.abspath(img_path)}")
        return False

    alto_original, ancho_original = template_original.shape

    print("=" * 62)
    print(f"PRUEBA MULTIESCALA - {img_name}")
    print("=" * 62)
    print(f"Imagen: {os.path.abspath(img_path)}")
    print(f"Tamaño original: {ancho_original} x {alto_original}")
    print(f"Escalas: {', '.join(f'{x:.2f}' for x in ESCALAS)}")

    inicio = time.perf_counter()
    screenshot = pyautogui.screenshot()
    screen = np.array(screenshot)
    screen_gray = cv2.cvtColor(screen, cv2.COLOR_RGB2GRAY)
    tiempo_captura = time.perf_counter() - inicio

    resultados = []

    for escala in ESCALAS:
        nuevo_ancho = int(ancho_original * escala)
        nuevo_alto = int(alto_original * escala)

        template = cv2.resize(
            template_original,
            (nuevo_ancho, nuevo_alto),
            interpolation=cv2.INTER_AREA
        )

        inicio_match = time.perf_counter()
        resultado = cv2.matchTemplate(screen_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(resultado)
        tiempo_match = time.perf_counter() - inicio_match

        x, y = max_loc
        resultados.append({
            "escala": escala,
            "match": max_val,
            "x": x,
            "y": y,
            "centro_x": x + nuevo_ancho // 2,
            "centro_y": y + nuevo_alto // 2,
            "ancho": nuevo_ancho,
            "alto": nuevo_alto,
            "tiempo": tiempo_match,
        })

    print(f"Captura: {tiempo_captura:.3f} s")
    print()
    print(f"{'Escala':<10}{'Match':<12}{'Posición':<16}{'Tamaño'}")
    print("-" * 55)

    for r in resultados:
        print(
            f"{r['escala']:<10.2f}"
            f"{r['match'] * 100:<12.2f}"
            f"X={r['x']:<5} Y={r['y']:<5}"
            f"{r['ancho']}x{r['alto']}"
        )

    mejor = max(resultados, key=lambda r: r["match"])

    print()
    print("-" * 55)
    print(f"MEJOR ESCALA: {mejor['escala']:.2f}  |  MATCH: {mejor['match'] * 100:.2f}%")
    print(f"Centro: X={mejor['centro_x']}, Y={mejor['centro_y']}  |  Tamaño: {mejor['ancho']}x{mejor['alto']}")

    print()
    print("THRESHOLDS SOBRE LA MEJOR ESCALA")
    print("-" * 55)
    print(f"{'Threshold':<15}{'Resultado'}")

    for threshold in THRESHOLDS:
        estado = "ENCONTRADO" if mejor["match"] >= threshold else "NO ENCONTRADO"
        print(f"{threshold * 100:<15.0f}%{estado}")

    pyautogui.moveTo(mejor["centro_x"], mejor["centro_y"], duration=0.3)

    diagnostico = cv2.cvtColor(screen_gray, cv2.COLOR_GRAY2BGR)
    x, y = mejor["x"], mejor["y"]
    w, h = mejor["ancho"], mejor["alto"]

    cv2.rectangle(diagnostico, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv2.circle(diagnostico, (mejor["centro_x"], mejor["centro_y"]), 5, (0, 0, 255), -1)

    nombre_base = os.path.splitext(img_name)[0]
    ruta_diagnostico = os.path.join(RESULT_FOLDER, f"resultado_multiescala_{nombre_base}.png")
    cv2.imwrite(ruta_diagnostico, diagnostico)

    print()
    print(f"Diagnóstico: {ruta_diagnostico}")
    print("No se realizó ningún clic.")

    return mejor


def solicitar_siguiente():
    while True:
        try:
            opcion = input("\n¿Desea pasar a la siguiente prueba? (1 = Siguiente / 0 = Terminar): ").strip()
        except EOFError:
            return 0

        if opcion in ("1", "0"):
            return int(opcion)

        print("Entrada inválida. Solo se acepta 1 o 0.")


def main():
    crear_carpeta_resultados()
    log_path = os.path.join(RESULT_FOLDER, "registro_pruebas.txt")

    with open(log_path, "w", encoding="utf-8") as log_file:
        original_stdout = sys.stdout
        sys.stdout = Tee(sys.stdout, log_file)

        try:
            print("INICIO DEL PROCESO DE PRUEBAS MULTIESCALA")
            print(f"Se ejecutarán {len(SECUENCIA_IMAGENES)} pruebas: {', '.join(SECUENCIA_IMAGENES)}")

            for img_name in SECUENCIA_IMAGENES:
                print(f"\n=== PRUEBA ACTUAL: {img_name} ===")
                esperar_enfoque(2)

                resultado = ejecutar_prueba(img_name)
                if not resultado:
                    print(f"Se omitió la prueba {img_name} por falta de imagen.")
                    break

                continuar = solicitar_siguiente()
                if continuar == 0:
                    print("Programa finalizado por el usuario.")
                    break

                print("Continuando con la siguiente prueba...")

            print("\nFIN DEL PROCESO.")
        finally:
            sys.stdout = original_stdout


if __name__ == "__main__":
    main()
    input("\nPresiona ENTER para salir...")