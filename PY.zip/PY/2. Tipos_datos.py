# Strings

first_name = "Felipe"
last_name = "Casemiro"
print(first_name)
print(last_name)
print(type(first_name))
print(type(last_name))

"------------------"
# Integers

age = -13
number = 100_000_000
print(number)
print(type(number))

"------------------"
# Floats

pi = -3.14
print(pi)
print(type(pi))

number = 10
result = number / 10 
"// división con resultado entero, mientras que / da un resultado float"
print("El resultado es: ", result)

"------------------"
# Booleans (Verdadero:True / Falso: False)

is_active = True
print(is_active)
print(type(is_active))