# 3x3
# [0, 0]
matrix = [
    [1, 2, 3], # 0
    [4, 5, 6], # 1
    [7, 8, 9]  # 2
]

print(matrix)

print(
    matrix[0][1]
)

"--------------- TUPLAS ------------------"
"""
Def: Obejtos inmutables, se rigen por la regla de indice
"""
#                0         1     2
#               -3        -2    -1
settings = ("localhost", 3360, True)

print(settings)
print(type(settings))

print("---------------")

# settings[0] = "127.0.0.1"

print(settings[0])
print(settings[1])
print(settings[-3])


numbers = 1, 2, 3, 4, 5 # tuple
# numbers = 1, (tambien es una tuple, separado por una ',')

print(numbers)
print(type(numbers))
