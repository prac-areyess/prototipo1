first_name = input("Ingresa tu nombre: ")
age = int(input("Ingresa tu edad: "))
height = float(input("Ingresa tu altura: "))
status = input("¿Tu usuario se encuentra activo? (yes/no) ") == "yes"

print(first_name)
print(age)
print(height)
print(status)

print(type(first_name))
print(type(age))
print(type(height))
print(type(status))

print(
    str("10")
)

