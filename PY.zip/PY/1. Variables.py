full_name = "CodigoFuente"
age = 10
print(full_name)
print(type(full_name))
#--------------------------
first_name, age, is_active = "Primera", 13, True
print(first_name)
print(age)
print( is_active)