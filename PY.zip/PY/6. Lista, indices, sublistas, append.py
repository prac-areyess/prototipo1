"""
<variable> = []
"""
my_list = ["String", 20, 10, 3.14, True, [1,2,3]]

print(my_list)
print(type(my_list))

"--------------------------------------"
"""
Las listas  alcemana elementos, que se encuentran en un indice
que comienzan desde el 0
"""
#             0         1        2         3         4
#             -5        -4       -3        -2        -1
courses = ["Python", "Django", "Ruby", "MongoDB", "Flask"]

courses[0] = "Ruby on Mails"
courses[1] = "MySQL"

value = courses[len(courses)-1]
value = courses[-3]
print(value)
print(courses)

"--------------------------------------"
#             0         1        2         3         4
#            -5        -4       -3        -2        -1
courses = ["Python", "Django", "Ruby", "MongoDB", "Flask"]
#Slicing: [1:2] start:end
#Slicing: [start:end:skips]
#Slicing: [:] #Shallow copy
courses_copy = courses[::-3]
print(courses_copy)

"--------------------------------------"
#             0         1        2         3         4
#            -5        -4       -3        -2        -1
courses = ["Python", "Django", "Ruby", "MongoDB", "Flask"]
new_courses = ["React", "Next"]
#append agrega un valor en la ultima fila
courses.append("Java")
#insert inserta un valor en el orden dado (#indice:"valor")
courses.insert(0, "Rust")
courses.insert(2, "C#")
#extend inserta-extiend una lista dentro de otra
courses.extend(new_courses)

courses.remove("C#")
last_element = courses.pop(0)

print(last_element)
print(
    "Python" in courses
)
#index ayuda a encontrar el n° indice del valor
print(
    courses.index("Python")
)
print(courses)

"---------------------------------------------"
#Metodos de lista
# copy
# reverse
# sort

#             0         1        2         3         4
#            -5        -4       -3        -2        -1
courses = ["Python", "Django", "Ruby", "MongoDB", "Flask"]

copy_list = courses.copy() #courses[:] # Shallow copy
print(copy_list)

# reverse_list = courses[::-5]
# print(reverse_list)

courses.reverse()
print(courses)

# sort por default ordena de forma ascendente, mientras que con el reverse true, descendente.
courses.sort(reverse = True)
print(courses)