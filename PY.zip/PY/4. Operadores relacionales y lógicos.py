# ==, >, >=, <, <=, != (Bool (True/False))
number_one = 20
number_two = 20

result = number_one == number_two
print(result)
print(type(result))

# and, or, not
number_one = 10
number_two = 20

result = (False 
          or False 
          or number_one == number_two
          or number_one > 100) 
print(result)