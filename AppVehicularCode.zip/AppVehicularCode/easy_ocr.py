import sys
import os
import easyocr
import re

# Redirigir la salida estándar a /dev/null para suprimir los mensajes
#sys.stdout = open(os.devnull, 'w')

def obtener_valor_captcha(image_path):
    try:
        reader = easyocr.Reader(['es'], gpu=False, verbose=False)
        result = reader.readtext(image_path)
        Codigo_catpcha = str(result[0][1])

        codigo = re.sub('\s','',Codigo_catpcha)
        codigo = codigo.upper()
        return codigo
    except IndexError:
        return 'AAAAAAAA'
    #finally:
        # Restaurar la salida estándar
        # sys.stdout = sys.__stdout__