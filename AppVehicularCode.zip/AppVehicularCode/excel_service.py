from openpyxl import Workbook, load_workbook
import os

class ExcelService:

    def __init__(self):
        self.workbook = None
        self.worksheet = None

    def crear_documento_excel(self):
        try:
            #ruta_documento = os.path.join(ruta_directorio, f'{nombre_documento}.xlsx')
            self.workbook = Workbook()
        except NameError as e:
            print(e)

    def abrir_documento_excel(self, ruta_directorio, nombre_documento):
        try:
            ruta_documento = os.path.join(ruta_directorio, f'{nombre_documento}.xlsx')
            self.workbook = load_workbook(ruta_documento)
        except NameError as e:
            print(e)
        except FileNotFoundError as e:
            print(f'No se ha encontrado el archivo {nombre_documento}.xslx')
    
    def seleccionar_hoja(self, nombre_hoja):
        try:
            self.worksheet = self.workbook[nombre_hoja]
        except NameError as e:
            print(e)
        except KeyError as e:
            print(f'No existe una hoja con el nombre {nombre_hoja} en el documento')
    
    def obtener_contenido_de_celda(self, numero_fila, numero_columna):
        try:
            valor = self.worksheet.cell(numero_fila, numero_columna)
            return valor.value
        except NameError as e:
            print(e)
    
    def escribir_contenido_en_celda(self, numero_fila, numero_columna, valor):
        try:
            self.worksheet.cell(numero_fila, numero_columna, valor)
        except NameError as e:
            print(e)

    def obtener_numero_filas(self):
        try:
            numero_indice = self.worksheet.max_row
            return numero_indice
        except NameError as e:
            print(e)
    
    def obtener_numero_columnas(self):
        try:
            numero_columnas = self.worksheet.max_column
            return numero_columnas
        except NameError as e:
            print(e)
    
    def guardar_documento_excel(self, ruta_directorio, nombre_documento):
        try:
            ruta_documento = os.path.join(ruta_directorio, f'{nombre_documento}.xlsx')
            self.workbook.save(ruta_documento)
        except NameError as e:
            print(e)
        except FileNotFoundError as e:
            print(f'No se ha encontrado el archivo {nombre_documento}.xslx')
    
    def agregar_fila_excel(self, datos):
        try:
            self.worksheet.append(datos)
        except NameError as e:
            print(e)


    
if __name__ == "__main__":

    directorio_base = os.getcwd()

    excel = ExcelService()

    #excel.abrir_documento_excel(directorio_base, 'DATA_VEHICULAR') 

    #excel.seleccionar_hoja('Placas_Vehiculares')

    #numero_filas = excel.obtener_numero_filas()

    #numero_columnas = excel.obtener_numero_columnas()

    excel.crear_documento_excel()

    excel.seleccionar_hoja('Sheet')

    encabezados = [
        "Nombres", "Titulos"
    ]

    personas = [
        { "Nombres":"Leonardo", "Titulos": "UNMSM"},
        { "Nombres":"Kevin", "Titulos": "UNFV"}
    ]


    #excel.escribir_contenido_en_celda(2,3,'Hola')

    excel.agregar_fila_excel(encabezados)

    for persona in personas:
        print(persona)
        datos = [persona[encabezado] for encabezado in encabezados]
        excel.agregar_fila_excel(datos)

    #excel.agregar_fila_excel(datos)
    
    excel.guardar_documento_excel(directorio_base, 'Test')

    """ for i in range(2,numero_filas + 1):
        for j in range(1, numero_columnas + 1):
            print(excel.obtener_contenido_de_celda(i,j)) """

    #numero_placa = excel.obtener_contenido_de_celda(3,1)
    #print(numero_placa)

    #workbook = load_workbook('DATA_VEHICULAR.xlsx')

    #hoja_placas_vehiculares = "Placas_Vehiculares"

    #worksheet = workbook[hoja_placas_vehiculares]

    #print(worksheet.max_row)
