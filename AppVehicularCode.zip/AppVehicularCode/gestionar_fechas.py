from datetime import datetime
import os
import platform

def formato_carpeta_descarga(frase_base):
    now = datetime.now()#Brinda la fecha actual
    username = os.getenv("USERNAME")
    Dia= str(now.day)
    #print("El mes actual es {}".format(now.month))
    if len(str(Dia)) == 1:
        Dia = '0'+ Dia
    Mes = str(now.month)
    #print("El año actual es {}".format(now.year))
    if len(str(Mes)) == 1:
        Mes = '0' + Mes
    Anio = str(now.year)
    #print("La hora actual es {}".format(now.hour))
    Hora = str(now.hour)
    if len(str(Hora)) == 1:
        Hora = '0' + Hora
    #print("El minuto actual es {}".format(now.minute))
    Minuto = str(now.minute)
    if len(str(Minuto)) == 1:
        Minuto = '0' + Minuto
    #print("El segundo actual es {}".format(now.second))
    Segundo = str(now.second)
    if len(str(Segundo)) == 1:
        Segundo = '0' + Segundo
    
    Tiempo = username.upper()+"_"+platform.node()+"_"+Dia+"D_"+Mes+"M_"+Anio+"_"+Hora+"H_"+Minuto+"M_"+Segundo+"S"

    return frase_base+Tiempo