
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $("#mostrarModalSel").on("click", function(){
        
        limpiarModalCrud();
                
        $('#tituloModalCrud').text('Seleccionar');
        $("#btnAceptModalCrud").attr('accion','sel');
        $("#btnAceptModalCrud").text('Buscar');
        $("#btnCancelModalCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $("#formCrud div.form-group").hide();
        $("#idCompromisoDiv").show();
        $("#idCompromiso").prop('disabled', false);
        $("#rcDiv").show();
        $("#recDiv").show();
        $("#rec").prop('disabled', false);
        $("#rucDiv").show();
        $("#ruc").prop('disabled', false);
        $("#rucTerceroDiv").show();

        $("#codTerceroDiv").hide(); 
        $("#fecPrimerPagoDiv").hide();      
        $("#formaPagoPropuestoDiv").hide();
        $("#nroCuotasDiv").hide(); 
        $("#mtoCuotaDiv").hide();
        $("#mtoCuota").prop('disabled', true);
        $("#tipoFrecuenciaDiv").hide(); 
        $("#diaSemanaDiv").hide(); 
        $("#diaSemana").prop('disabled', true);
        $("#diaMesDiv").hide(); 
        $("#diaMes").prop('disabled', true);
        $("#tipoFrecuenciaDiv").hide(); 
        $("#montoTotalInformadoDiv").hide(); 
        $("#dniEncargadoTerceroDiv").show(); 
        $("#nombreEncargadoTerceroDiv").hide(); 
        $("#observacionDiv").hide(); 



        $("#fecRegRangoDiv").show();
        $("#fecRegDiv").hide();
        $("#usuRegDiv").hide();
        $("#estadoDiv").hide();
        
        
        $("#idCompromiso").focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }
        
        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $("#btnAceptModalCrud").attr('accion','ins');
        $("#btnAceptModalCrud").text('Registrar');
        $("#btnCancelModalCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $("#formCrud div.form-group").show();
        $("#idCompromisoDiv").hide();
        $("#idCompromiso").prop('disabled', false);
        $("#rcDiv").show();        
        $("#recDiv").show();
        $("#rec").prop('disabled', true);
        $("#rucDiv").show();
        $("#ruc").prop('disabled', true);
        $("#rucTerceroDiv").hide();

        $("#codTerceroDiv").show(); 
        $("#fecPrimerPagoDiv").show();  
        $("#formaPagoPropuestoDiv").show();
        $("#nroCuotasDiv").show();  
        $("#mtoCuotaDiv").show();
        $("#mtoCuota").prop('disabled', true);
        $("#tipoFrecuenciaDiv").show(); 
        $("#diaSemanaDiv").hide(); 
        $("#diaSemana").prop('disabled', true);
        $("#diaMesDiv").hide();     
        $("#diaMes").prop('disabled', true);
        $("#montoTotalInformadoDiv").show();        
        $("#dniEncargadoTerceroDiv").show(); 
        $("#nombreEncargadoTerceroDiv").show(); 
        $("#observacionDiv").show(); 


        $("#fecRegRangoDiv").hide();
        $("#fecRegDiv").hide();
        $("#usuRegDiv").hide();
        $("#estadoDiv").hide();



        $("#idCompromiso").focus();
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $("#btnAceptModalCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptModalCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getCompromisos",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    

                    "columns":
                    [
                        {"data":"id"},
                        {"data":"rucDesc"},
                        // {"data": "rucDesc", "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                        //     $(nTd).html("<a target='_blank' href='../fichaRuc/consulta?ruc="+oData.ruc+"'>"+oData.rucDesc+"</a>");
                        // }},     
                        {"data":"rc"},
                        {"data":"rucTerceroDesc"},
                        // {"data": "rucTerceroDesc", "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                        //     $(nTd).html("<a target='_blank' href='../fichaRuc/consulta?ruc="+oData.rucTercero+"'>"+oData.rucTerceroDesc+"</a>");
                        // }},                             
                        {"data":"montoTotalInformado"},
                        {"data":"mtoCuota"},
                        {"data":"nroCuotas"},
                        {"data":"fecPrimerPago"},
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if (true){
                                $(nTd).html("<form target='_blank' method='post' action='./cuota'>\
                                <input type='hidden' name='idCompromiso' value='"+oData.id+"'>\
                                <input type='hidden' name='shape' value='2'>\
                                <input type='hidden' name='title' value='Cuotas del Compromiso N° "+oData.id+"''>\
                                <left><input class='btn btn-primary' type='submit' value='Cronograma'></left>\
                                </form>");
                            }else{
                                $(nTd).html("");
                            }
                            
                        }},
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if ($('#shape').val()=='1'){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' idCompromiso='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        <button type='button' idCompromiso='"+oData.id+"' class='mostrarModalUpd btn btn-primary'data-toggle='tooltip' title='Modificar'><i class='far fa-edit'></i></button>\
                                        <button type='button' idCompromiso='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                    </div>\
                                </div>");
                            }
                            else if ($('#shape').val()=='2'){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' idCompromiso='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                    </div>\
                                </div>"); 
                            }else{                                
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });

                if ($('#shape').val()=='1' || $('#shape').val()=='2'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                        buttons: [
                           { 
                                extend: 'excel', 
                                text: 'Descargar Excel', 
                                className:'buttonDataTable', 
                                type:'button'
                            }
                        ]
                    }).container().appendTo($('#buttonModule'));
                }

                $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");


                

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                    
                   
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $("#btnAceptModalCrud").attr('accion','get');
                    $("#btnAceptModalCrud").text('Aceptar');
                    $("#btnCancelModalCrud").hide();

                  

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);



                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rec").prop('disabled', true);
                    $("#rucDiv").show();
                    $("#ruc").prop('disabled', true);
                    $("#rucTerceroDiv").hide();

                    $("#codTerceroDiv").show(); 
                    $("#fecPrimerPagoDiv").show();        
                    $("#formaPagoPropuestoDiv").show();
                    $("#diaSemanaDiv").hide(); 
                    $("#diaSemana").prop('disabled', true);
                    $("#diaMesDiv").hide(); 
                    $("#diaMes").prop('disabled', true);
                    $("#nroCuotasDiv").show();
                    $("#mtoCuotaDiv").show();
                    $("#mtoCuota").prop('disabled', true);
                    $("#tipoFrecuenciaDiv").show();     
                    $("#montoTotalInformadoDiv").show();                    
                    $("#dniEncargadoTerceroDiv").show(); 
                    $("#nombreEncargadoTerceroDiv").show(); 
                    $("#observacionDiv").show(); 


                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").show();
                    $("#usuRegDiv").show();
                    $("#estadoDiv").hide();




                    $("#idCompromiso").focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr("idCompromiso"));     

                    $('#modalCrud').modal('show');

                    // $("#idUsuario").change();
                    // $("#horasOcupadas").keyup();
                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Modificar');
                    $("#btnAceptModalCrud").attr('accion','upd');
                    $("#btnAceptModalCrud").text('Guardar');
                    $("#btnCancelModalCrud").show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rec").prop('disabled', true);
                    $("#rucDiv").show();
                    $("#ruc").prop('disabled', true);
                    $("#rucTerceroDiv").hide();

                    $("#codTerceroDiv").show(); 
                    $("#fecPrimerPagoDiv").show();        
                    $("#formaPagoPropuestoDiv").show();
                    $("#nroCuotasDiv").show();
                    $("#mtoCuotaDiv").show();
                    $("#mtoCuota").prop('disabled', true);
                    $("#tipoFrecuenciaDiv").show();     
                    $("#diaSemanaDiv").hide(); 
                    $("#diaSemana").prop('disabled', true);
                    $("#diaMesDiv").hide(); 
                    $("#diaMes").prop('disabled', true);
                    $("#montoTotalInformadoDiv").show();
                    $("#dniEncargadoTerceroDiv").show(); 
                    $("#nombreEncargadoTerceroDiv").show(); 
                    $("#observacionDiv").show(); 

                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").hide();
                    $("#usuRegDiv").hide();
                    $("#estadoDiv").hide();

                    $("#rcDiv").focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr("idCompromiso"));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $("#btnAceptModalCrud").attr('accion','del');
                    $("#btnAceptModalCrud").text('Eliminar');
                    $("#btnCancelModalCrud").show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rec").prop('disabled', true);
                    $("#rucDiv").show();
                    $("#ruc").prop('disabled', true);
                    $("#rucTerceroDiv").hide();

                    $("#codTerceroDiv").hide(); 
                    $("#fecPrimerPagoDiv").hide();       
                    $("#formaPagoPropuestoDiv").hide();
                    $("#nroCuotasDiv").hide();
                    $("#mtoCuotaDiv").hide();
                    $("#mtoCuota").prop('disabled', true);
                    $("#tipoFrecuenciaDiv").show();     
                    $("#diaSemanaDiv").hide(); 
                    $("#diaSemana").prop('disabled', true);
                    $("#diaMesDiv").hide(); 
                    $("#diaMes").prop('disabled', true);
                    $("#montoTotalInformadoDiv").hide();
                    $("#dniEncargadoTerceroDiv").hide(); 
                    $("#nombreEncargadoTerceroDiv").hide(); 
                    $("#observacionDiv").hide(); 

                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").hide();
                    $("#usuRegDiv").hide();
                    $("#estadoDiv").hide();

                    $("#rcDiv").focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr("idCompromiso"));

                    $('#modalCrud').modal('show');
                })


                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($("#idCompromiso").val() != "" && $("#idCompromiso").val() != null) &&
                ($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#rec").val() != "" && $("#rec").val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);



                $.ajax({
                    method:"POST",
                    url: "./updCompromiso",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                messageBox(1,"Exito","Se modificaron los datos del registro con Id: "+row.id);
                            }
                        }
                        catch(e) {
                           messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', true);
            }
        }


        

        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();            
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delCompromiso",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();

                    try {
                        var jsonData = JSON.parse(data);
                        
                        if ( jsonData.data.length == 0){
                            messageBox(1,"Exito","Se eliminó el registro "+$('#idCompromiso').val());
                        }else{
                            messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                        }
                    }
                    catch(e) {
                       messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                    }   
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#rec").val() != "" && $("#rec").val() != null) ){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insCompromiso",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                messageBox(1,"Exito","Se registraron los datos con el Id: "+row.id);
                            }
                        }
                        catch(e) {
                           messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                        }   

                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', false);
            }

        }
    });   
        
    //Consulta
    $("#btnAceptModalCrud").attr('accion','sel');
    $('#btnAceptModalCrud').trigger('click');    
        
});

function get(id){

    $.ajax({
        method:"POST",
        url : './getCompromisos',
        data: {
            "idCompromiso":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $("#idCompromiso").val(row.id);
                
                /*if (row.idArea !== null && row.idArea.trim() !== "" ){
                    $("#idArea").append($("<option selected='selected'></option>").val(row.idArea).text(row.idArea)).trigger('change');
                }*/

                /*if (row.idUsuario !== null && row.idUsuario.trim() !== "" ){
                    $("#idUsuario").append($("<option selected='selected'></option>").val(row.idUsuario).text(row.idUsuario)).trigger('change');
                }*/

                

                $("#rc").val(row.rc);
                $("#rec").val(row.rec);
                $("#ruc").val(row.ruc);

               
                
                
                //$("#codTercero").val(row.codTercero);

                getListaTerceros(row.rc);               
                $("#codTercero").append($("<option selected='selected'></option>").val(row.codTercero).text(row.num_ruc_ter + ' - ' + row.nom_ter)).trigger('change');
                
                //$("#fecPrimerPago").val(row.fecPrimerPago);
                //$('#fecPrimerPagoDiv').datepicker('setDate', moment(row.fecPrimerPago, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                //alert(row.fecPrimerPago);
                //alert();

                $("#fecPrimerPago").val(moment(row.fecPrimerPago, 'YYYY-MM-DD').format('DD/MM/YYYY'));

                

                $("#formaPagoPropuesto").val(row.formaPagoPropuesto);
                $("#nroCuotas").val(row.nroCuotas);
                $("#mtoCuota").val(row.mtoCuota);
                $("#tipoFrecuencia").val(row.tipoFrecuencia);
                
                if(row.tipoFrecuencia == '01'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").hide(); 
                }
                if(row.tipoFrecuencia == '03'){
                    $("#diaSemanaDiv").show(); 
                    $("#diaMesDiv").hide(); 
                }
                if(row.tipoFrecuencia == '05'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '07'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '09'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '11'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '13'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '15'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '17'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }

                $("#diaSemana").val(row.diaSemana);     
                $("#diaMes").val(row.diaMes);     

                $("#montoTotalInformado").val(row.montoTotalInformado);
                $("#dniEncargadoTercero").val(row.dniEncargadoTercero);
                $("#nombreEncargadoTercero").val(row.nombreEncargadoTercero);
                $("#observacion").val(row.observacion);
                $("#fecReg").val(moment(row.fecReg, 'YYYY-MM-DD').format('DD/MM/YYYY'));

                $("#usuReg").val(row.usuReg);
                $("#estado").val(row.estado);


                /*if (row.numOrdFis !== null && row.numOrdFis.trim() !== "" ){
                    $("#numOrdFis").append($("<option selected='selected'></option>").val(row.numOrdFis).text(row.numOrdFis)).trigger('change');
                }*/

                
            }

        }
    });
}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });

        //$('#idCompromiso').val(dataObj['idCompromiso']);
        $("#idCompromiso").val(row.idCompromiso);
        $("#rc").val(row.rc);
        $("#rec").val(row.rec);
        $("#ruc").val(row.ruc);
        $("#rucTercero").val(row.rucTercero);
        $("#dniEncargadoTercero").val(row.dniEncargadoTercero);
        $("#fecRegIni").val(row.fecRegIni);
        $("#fecRegFin").val(row.fecRegFin);
        
    }
}

function limpiarModalCrud(){

    $("#formCrud")[0].reset();


    //$("#idUsuario").val("");
    //$("#idUsuario").text("");



    $('#codTercero').empty();
    $("#codTercero").val("");
    $("#codTercero").text("");



    $("#tipoFrecuencia").val("");
    
    $("#diaSemana").val("");
    
    $("#diaMes").val("");
    

    /*$("#numOrdFis").val("");
    $("#numOrdFis").text("");*/


    

    //$('[name^="nro_rtf_array"]').remove();
}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').show();
        
        
    }
    if($('#shape').val()=='2'){
        //Consulta por Ruc Tecero
        $('#dropMenu').hide();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').hide();
        
    }

   
    var feriadosArray = new Array();
    
    /*$.ajax({
        'url' : '../aplicacion/getFeriados',
        'type' : 'POST',
        'success' : function(data) {
            var a=JSON.parse(data);
            for(i=0; i<=a.data.length-1; i++){
                feriadosArray.push(a.data[i].fecha);
            }
        }
    });*/
    

  

    $('#estado').append($('<option></option>').val("").html("Seleccionar"));
    $('#estado').append($('<option></option>').val("01").html("01 - ACTIVO"));
    


    $('#formaPagoPropuesto').append($('<option></option>').val("").html("Seleccionar"));
    $('#formaPagoPropuesto').append($('<option></option>').val("01").html("01 - BOLETA PAGO 1662"));
    $('#formaPagoPropuesto').append($('<option></option>').val("02").html("02 - CHEQUE"));
    $('#formaPagoPropuesto').append($('<option></option>').val("03").html("03 - NPS"));
    $('#formaPagoPropuesto').append($('<option></option>').val("09").html("09 - OTROS"));
    $('#formaPagoPropuesto').append($('<option></option>').val("99").html("99 - NO ESPECIFICO"));

    //var dt = moment(myDate.date, "YYYY-MM-DD HH:mm:ss")


    


    //$('#tipoFrecuencia').append($('<option></option>').val("01").html("01 - DIARIO"));    
    $('#tipoFrecuencia').append($('<option></option>').val("03").html("03 - SEMANAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("05").html("05 - BIMENSUAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("07").html("07 - MENSUAL"));    
    $('#tipoFrecuencia').append($('<option></option>').val("09").html("09 - BIMESTRAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("11").html("11 - TRIMESTRAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("13").html("13 - CUATRIMESTRAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("15").html("15 - SEMESTRAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("17").html("17 - ANUAL"));


    $('#diaSemana').append($('<option></option>').val("LU").html("LUNES"));
    $('#diaSemana').append($('<option></option>').val("MA").html("MARTES"));
    $('#diaSemana').append($('<option></option>').val("MI").html("MIERCOLES"));
    $('#diaSemana').append($('<option></option>').val("JU").html("JUEVES"));
    $('#diaSemana').append($('<option></option>').val("VI").html("VIERNES"));
    $('#diaSemana').append($('<option></option>').val("SA").html("SABADO"));
    $('#diaSemana').append($('<option></option>').val("DO").html("DOMINGO"));
    
    for (var i = 1; i <= 28; i++) {
        $('#diaMes').append($('<option></option>').val(i).html(i));   
    }

  
    
    $('#montoTotalInformado').keyup(function(){

        if($(this).val() != ""){
            //$(this).val(Number($(this).val()));

            //if(Number.isInteger(parseInt($(this).val())) == false ) {
            if(isNumeric($(this).val())==false){
                alert("Sólo números válidos");  
                $(this).val("");     
            }
        }

        $('#nroCuotas').val('')
        $('#mtoCuota').val('')
    }); 



    


    $('#nroCuotas').keyup(function(){

        $("#tipoFrecuenciaDiv").show();

        if($(this).val() != ""){
            //$(this).val(Number($(this).val()));

            //if(Number.isInteger(parseInt($(this).val())) == false ) {
            if(isNumeric($(this).val())==false){
                alert("Sólo números válidos");  
                $(this).val("");     
            }else{
                
                $('#mtoCuota').val(parseInt($('#montoTotalInformado').val() / $(this).val()));

                if($(this).val() == "1"){
                    $("#tipoFrecuenciaDiv").hide(); 
                }
            }
        }
    });  

    
    


    

    setInterval(timer, 10000);


    $('#fecPrimerPago').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        startDate: '0d',  
        endDate: '+180d', //startDate: '-1d',  
        language: 'es',
        daysOfWeekDisabled: [0],
        container:'#fecPrimerPagoContainer'
    });
    

    $('#fecPrimerPago').change(function(){
        getDiaSemanaDiaMes();

    });  



    $('#fecRegIni').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegIniContainer'
    });

    $('#fecRegFin').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegFinContainer'
    });



    

    /*$("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });
    */

    $('#rc').change(function(){
        
        

        if($(this).val().length == 13){
            $.ajax({
                'url' : './getDatosRC',                
                data: {
                    "rc":$(this).val()
                },
                'type' : 'POST',
                'success' : function(data) {
                    
                    var jsonData = JSON.parse(data);
                    //var regUsuario;
                    //$('#codTercero').empty();
                    for (var i = 0; i < jsonData.data.length; i++) {
                        var row = jsonData.data[i];

                        $('#rec').val(row.rec);
                        $('#ruc').val(row.ruc);
                        
                        
                    }
                }
            });


            
            getListaTerceros($(this).val());
            



        }
    });   



    $('#tipoFrecuencia').change(function(){

        getDiaSemanaDiaMes();
        
        
        if($(this).val() == '01'){
            $("#diaSemanaDiv").hide(); 
            $("#diaMesDiv").hide(); 
        }
        if($(this).val() == '03'){
            $("#diaSemanaDiv").show(); 
            $("#diaMesDiv").hide(); 
        }
        if($(this).val() == '05'){
            $("#diaSemanaDiv").hide(); 
            $("#diaMesDiv").show(); 
        }
        if($(this).val() == '07'){
            $("#diaSemanaDiv").hide(); 
            $("#diaMesDiv").show(); 
        }
        if($(this).val() == '09'){
            $("#diaSemanaDiv").hide(); 
            $("#diaMesDiv").show(); 
        }
        if($(this).val() == '11'){
            $("#diaSemanaDiv").hide(); 
            $("#diaMesDiv").show(); 
        }
        if($(this).val() == '13'){
            $("#diaSemanaDiv").hide(); 
            $("#diaMesDiv").show(); 
        }
        if($(this).val() == '15'){
            $("#diaSemanaDiv").hide(); 
            $("#diaMesDiv").show(); 
        }
        if($(this).val() == '17'){
            $("#diaSemanaDiv").hide(); 
            $("#diaMesDiv").show(); 
        }


    });

    /*$("#numOrdFis").select2({ 

        placeholder: "Seleccionar OF", 
        minimumInputLength: 3, 
        language: {
            inputTooShort: function() {
                return 'Agregar carateres para buscar...'
            }
        },
        multiple: false, 
        width: 400, 
        ajax: { 
            
            url: "./getOfCombo",
            type: "POST", 
            data: function(term) { 
                return term;
            }, 
            processResults: function(data, page) { 
                var jsonData = JSON.parse(data);
                return { 

                    results: $.map(jsonData.data, function (item) {
            
                        return {
                            id: item.id,
                            text: item.descripcion
                            
                        }
                    })                    
                }; 
            }, 
        } 
    });*/


    
    
}









function getListaTerceros(rc){

    $('#codTercero').empty();
    $("#codTercero").val('');
    $("#codTercero").text('');

    $.ajax({
        'url' : './getListaTerceros',
        data: {
            "rc":rc
        },
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                $('#codTercero').append($('<option></option>').val(row.codTercero).html(row.rucTercero+' - '+row.nombreTercero));    
                
            }
        }
    });
}

function getDiaSemanaDiaMes(){
    if($('#fecPrimerPago').val() != ""){
        var mydate = new Date(moment($('#fecPrimerPago').val(), 'DD/MM/YYYY').format('YYYY-MM-DD'));
        var diaMes  = mydate.getDate() + 1;        
        $('#diaMes').val(diaMes);


        var dias = ['LU','MA','MI','JU','VI','SA','DO'];
        var dia = mydate.getDay();
        var diaSemana = dias[dia];
        $('#diaSemana').val(diaSemana);
    }
}

