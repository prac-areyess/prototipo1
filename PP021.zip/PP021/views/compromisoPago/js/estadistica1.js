
$(document).ready(function () {

    inicializarModulo();
    

    //Modal Sel
    /*$("#mostrarModalSel").on("click", function(){

        limpiarModalCrud();
        
        $('#tituloCrud').text('Seleccionar');
        $("#btnAceptCrud").attr('accion','sel');
        $("#btnAceptCrud").text('Buscar');
        $("#btnCancelCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formCrud div.form-group").hide();
        $("#idCompromisoDiv").show();
        $("#idCompromiso").prop('disabled', false);
        $("#rcDiv").show();
        $("#recDiv").show();
        $("#rec").prop('disabled', false);
        $("#rucDiv").show();
        $("#ruc").prop('disabled', false);


        $("#codTerceroDiv").hide(); 
        $("#fecPrimerPagoDiv").hide();      
        $("#formaPagoPropuestoDiv").hide();
        $("#nroCuotasDiv").hide(); 
        $("#mtoCuotaDiv").hide();
        $("#mtoCuota").prop('disabled', true);
        $("#tipoFrecuenciaDiv").hide(); 
        $("#diaSemanaDiv").hide(); 
        $("#diaSemana").prop('disabled', true);
        $("#diaMesDiv").hide(); 
        $("#diaMes").prop('disabled', true);
        $("#tipoFrecuenciaDiv").hide(); 
        $("#montoTotalInformadoDiv").hide(); 
        $("#dniEncargadoTerceroDiv").show(); 
        $("#nombreEncargadoTerceroDiv").hide(); 
        $("#observacionDiv").hide(); 



        $("#fecRegRangoDiv").show();
        $("#fecRegDiv").hide();
        $("#usuRegDiv").hide();
        $("#estadoDiv").show();
        
        
        $("#idCompromiso").focus();

        $('#btnAceptCrud').attr('class','btn btn-primary');

        $('#modalCrud').modal('show');
    });  */
    
    //Modal Ins
    /*$("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloCrud').text('Nuevo Registro');
        $("#btnAceptCrud").attr('accion','ins');
        $("#btnAceptCrud").text('Registrar');
        $("#btnCancelCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formCrud div.form-group").show();
        $("#idCompromisoDiv").hide();
        $("#idCompromiso").prop('disabled', false);
        $("#rcDiv").show();        
        $("#recDiv").show();
        $("#rec").prop('disabled', true);
        $("#rucDiv").show();
        $("#ruc").prop('disabled', true);
       
        $("#codTerceroDiv").show(); 
        $("#fecPrimerPagoDiv").show();  
        $("#formaPagoPropuestoDiv").show();
        $("#nroCuotasDiv").show();  
        $("#mtoCuotaDiv").show();
        $("#mtoCuota").prop('disabled', true);
        $("#tipoFrecuenciaDiv").show(); 
        $("#diaSemanaDiv").hide(); 
        $("#diaSemana").prop('disabled', true);
        $("#diaMesDiv").hide();     
        $("#diaMes").prop('disabled', true);
        $("#montoTotalInformadoDiv").show();        
        $("#dniEncargadoTerceroDiv").show(); 
        $("#nombreEncargadoTerceroDiv").show(); 
        $("#observacionDiv").show(); 


        $("#fecRegRangoDiv").hide();
        $("#fecRegDiv").hide();
        $("#usuRegDiv").hide();
        $("#estadoDiv").show();



        $("#idCompromiso").focus();
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        $('#btnAceptCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });  */     

    //btnAceptCrud
    /*$("#btnAceptCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getMisCompromisosPago",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            //$('#dataTable').dataTable({"destroy": true});
                            messageBox(3,"Error","Comuníquese con el administrador.");
                            $("#btnAceptCrud").prop("disabled", false);
                        } 
                    },

                    

                    "columns":
                    [
                        {"data":"id"},
                        {"data": "rucDesc", "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            $(nTd).html("<a target='_blank' href='../fichaRuc/consulta?ruc="+oData.ruc+"'>"+oData.rucDesc+"</a>");
                        }},     
                        {"data":"rc"},
                        {"data": "rucTerceroDesc", "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            $(nTd).html("<a target='_blank' href='../fichaRuc/consulta?ruc="+oData.rucTercero+"'>"+oData.rucTerceroDesc+"</a>");
                        }},                             
                        {"data":"montoTotalInformado"},
                        {"data":"mtoCuota"},
                        {"data":"nroCuotas"},
                        {"data":"fecPrimerPago"},
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if (true){
                                $(nTd).html("<form target='_blank' method='post' action='./cronograma'>\
                                <input type='hidden' name='idCompromiso' value='"+oData.id+"'>\
                                <left><input class='btn btn-primary' type='submit' value='Cronograma'></left>\
                                </form>");
                            }else{
                                $(nTd).html("");
                            }
                            
                        }},
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if (true){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' idCompromiso='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        <button type='button' idCompromiso='"+oData.id+"' class='mostrarModalUpd btn btn-primary'data-toggle='tooltip' title='Modificar'><i class='far fa-edit'></i></button>\
                                        <button type='button' idCompromiso='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                    </div>\
                                </div>");
                            }else{                                
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });


                //var buttons = new $.fn.dataTable.Buttons(table, {
                //    buttons: [
                //       { extend: 'excel', text: 'Descargar Excel', className: 'btn btn-primary float-left', type:'button', align:'rigth'}
                //    ]
                //}).container().appendTo($('#descargaDataDiv'));

                

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                    
                   
                    limpiarModalCrud();

                    $('#tituloCrud').text('Información');
                    $("#btnAceptCrud").attr('accion','get');
                    $("#btnAceptCrud").text('Aceptar');
                    $("#btnCancelCrud").hide();

                  

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptCrud').prop('disabled', false);



                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rec").prop('disabled', true);
                    $("#rucDiv").show();
                    $("#ruc").prop('disabled', true);
                    
                    $("#codTerceroDiv").show(); 
                    $("#fecPrimerPagoDiv").show();        
                    $("#formaPagoPropuestoDiv").show();
                    $("#diaSemanaDiv").hide(); 
                    $("#diaSemana").prop('disabled', true);
                    $("#diaMesDiv").hide(); 
                    $("#diaMes").prop('disabled', true);
                    $("#nroCuotasDiv").show();
                    $("#mtoCuotaDiv").show();
                    $("#mtoCuota").prop('disabled', true);
                    $("#tipoFrecuenciaDiv").show();     
                    $("#montoTotalInformadoDiv").show();                    
                    $("#dniEncargadoTerceroDiv").show(); 
                    $("#nombreEncargadoTerceroDiv").show(); 
                    $("#observacionDiv").show(); 


                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").show();
                    $("#usuRegDiv").show();
                    $("#estadoDiv").show();




                    $("#idCompromiso").focus();

                    $('#btnAceptCrud').attr('class','btn btn-primary');

                    get($(this).attr("idCompromiso"));     

                    $('#modalCrud').modal('show');

                    // $("#idUsuario").change();
                    // $("#horasOcupadas").keyup();

                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloCrud').text('Modificar');
                    $("#btnAceptCrud").attr('accion','upd');
                    $("#btnAceptCrud").text('Guardar');
                    $("#btnCancelCrud").show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptCrud').prop('disabled', false);

                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rec").prop('disabled', true);
                    $("#rucDiv").show();
                    $("#ruc").prop('disabled', true);
                    

                    $("#codTerceroDiv").show(); 
                    $("#fecPrimerPagoDiv").show();        
                    $("#formaPagoPropuestoDiv").show();
                    $("#nroCuotasDiv").show();
                    $("#mtoCuotaDiv").show();
                    $("#mtoCuota").prop('disabled', true);
                    $("#tipoFrecuenciaDiv").show();     
                    $("#diaSemanaDiv").hide(); 
                    $("#diaSemana").prop('disabled', true);
                    $("#diaMesDiv").hide(); 
                    $("#diaMes").prop('disabled', true);
                    $("#montoTotalInformadoDiv").show();
                    $("#dniEncargadoTerceroDiv").show(); 
                    $("#nombreEncargadoTerceroDiv").show(); 
                    $("#observacionDiv").show(); 

                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").hide();
                    $("#usuRegDiv").hide();
                    $("#estadoDiv").show();

                    $("#rcDiv").focus();

                    $('#btnAceptCrud').attr('class','btn btn-primary');

                    get($(this).attr("idCompromiso"));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloCrud').text('Eliminar');       
                    $("#btnAceptCrud").attr('accion','del');
                    $("#btnAceptCrud").text('Eliminar');
                    $("#btnCancelCrud").show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptCrud').prop('disabled', false);
                    
                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rec").prop('disabled', true);
                    $("#rucDiv").show();
                    $("#ruc").prop('disabled', true);

                    $("#codTerceroDiv").hide(); 
                    $("#fecPrimerPagoDiv").hide();       
                    $("#formaPagoPropuestoDiv").hide();
                    $("#nroCuotasDiv").hide();
                    $("#mtoCuotaDiv").hide();
                    $("#mtoCuota").prop('disabled', true);
                    $("#tipoFrecuenciaDiv").show();     
                    $("#diaSemanaDiv").hide(); 
                    $("#diaSemana").prop('disabled', true);
                    $("#diaMesDiv").hide(); 
                    $("#diaMes").prop('disabled', true);
                    $("#montoTotalInformadoDiv").hide();
                    $("#dniEncargadoTerceroDiv").hide(); 
                    $("#nombreEncargadoTerceroDiv").hide(); 
                    $("#observacionDiv").hide(); 

                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").hide();
                    $("#usuRegDiv").hide();
                    $("#estadoDiv").hide();

                    $("#rcDiv").focus();

                    $('#btnAceptCrud').attr('class','btn btn-danger');

                    get($(this).attr("idCompromiso"));

                    $('#modalCrud').modal('show');
                })


                //$('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($("#idCompromiso").val() != "" && $("#idCompromiso").val() != null) &&
                ($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#rec").val() != "" && $("#rec").val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);



                $.ajax({
                    method:"POST",
                    url: "./updCompromiso",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');
                        messageBox(1,"Exito","Se modificaron los datos.");
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
                });
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', true);
            }
        }
      
        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delCompromiso",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,"Error","Comunicarse con el administrador.");
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#rec").val() != "" && $("#rec").val() != null) ){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insCompromiso",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');
                        messageBox(1,"Exito","Se registraron los datos.");
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
                });
            
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', false);
            }

        }
    });   */
        
    //Consulta
    /*$("#btnAceptCrud").attr('accion','sel');
    $('#btnAceptCrud').trigger('click');    */
        
});

/*function get(id){

    $.ajax({
        method:"POST",
        url : './getCompromisoPago',
        data: {
            "idCompromiso":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $("#idCompromiso").val(row.id);
                
                if (row.idArea !== null && row.idArea.trim() !== "" ){
                    $("#idArea").append($("<option selected='selected'></option>").val(row.idArea).text(row.idArea)).trigger('change');
                }

                if (row.idUsuario !== null && row.idUsuario.trim() !== "" ){
                    $("#idUsuario").append($("<option selected='selected'></option>").val(row.idUsuario).text(row.idUsuario)).trigger('change');
                }

                

                $("#rc").val(row.rc);
                $("#rec").val(row.rec);
                $("#ruc").val(row.ruc);

               
                
                
                //$("#codTercero").val(row.codTercero);

                getListaTerceros(row.rc);               
                $("#codTercero").append($("<option selected='selected'></option>").val(row.codTercero).text(row.num_ruc_ter + ' - ' + row.nom_ter)).trigger('change');
                
                //$("#fecPrimerPago").val(row.fecPrimerPago);
                //$('#fecPrimerPagoDiv').datepicker('setDate', moment(row.fecPrimerPago, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                //alert(row.fecPrimerPago);
                //alert();

                $("#fecPrimerPago").val(moment(row.fecPrimerPago, 'YYYY-MM-DD').format('DD/MM/YYYY'));

                

                $("#formaPagoPropuesto").val(row.formaPagoPropuesto);
                $("#nroCuotas").val(row.nroCuotas);
                $("#mtoCuota").val(row.mtoCuota);
                $("#tipoFrecuencia").val(row.tipoFrecuencia);
                
                if(row.tipoFrecuencia == '01'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").hide(); 
                }
                if(row.tipoFrecuencia == '03'){
                    $("#diaSemanaDiv").show(); 
                    $("#diaMesDiv").hide(); 
                }
                if(row.tipoFrecuencia == '05'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '07'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '09'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '11'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '13'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '15'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }
                if(row.tipoFrecuencia == '17'){
                    $("#diaSemanaDiv").hide(); 
                    $("#diaMesDiv").show(); 
                }

                $("#diaSemana").val(row.diaSemana);     
                $("#diaMes").val(row.diaMes);     

                $("#montoTotalInformado").val(row.montoTotalInformado);
                $("#dniEncargadoTercero").val(row.dniEncargadoTercero);
                $("#nombreEncargadoTercero").val(row.nombreEncargadoTercero);
                $("#observacion").val(row.observacion);
                $("#fecReg").val(moment(row.fecReg, 'YYYY-MM-DD').format('DD/MM/YYYY'));

                $("#usuReg").val(row.usuReg);
                $("#estado").val(row.estado);


                if (row.numOrdFis !== null && row.numOrdFis.trim() !== "" ){
                    $("#numOrdFis").append($("<option selected='selected'></option>").val(row.numOrdFis).text(row.numOrdFis)).trigger('change');
                }

                
            
                
                
                


                
                
            }

        }
    });
}*/

/*function limpiarModalCrud(){

    $("#formCrud")[0].reset();


    //$("#idUsuario").val("");
    //$("#idUsuario").text("");

    

    $('#codTercero').empty();
    $("#codTercero").val("");
    $("#codTercero").text("");



    $("#tipoFrecuencia").val("");
    
    $("#diaSemana").val("");
    
    $("#diaMes").val("");
    



    

    //$('[name^="nro_rtf_array"]').remove();
}*/
   
function inicializarModulo(){

    

    document.title = 'Estadisticas de Compromisos';
    $('#titleModule').text('Estadisticas de Compromisos');
    $('#dropMenu').show();
    

    var feriadosArray = new Array();
    
    setInterval(timer, 10000);

    $('#dataTable1').dataTable().fnClearTable();

    var table = $('#dataTable1').DataTable({
        "destroy": true,            
        "pageLength": 10,
        
        "scrollX": true,
        "language":{
            "sProcessing":     "Procesando...",
            "sLengthMenu":     "Mostrar _MENU_ registros",
            "sZeroRecords":    "No se encontraron resultados",
            "sEmptyTable":     "Ningún dato disponible en esta tabla",
            "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix":    "",
            "sSearch":         "Filtrar:",
            "sUrl":            "",
            "sInfoThousands":  ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst":    "Primero",
                "sLast":     "Último",
                "sNext":     "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            }
        },
        "bSort": true,
        //"order": [],
        "order":[[2,"desc"]],                 
        
        "ajax":
        {
            "method":"POST",
            "url": "./getCantCompromisosPorTercero",            
            error: function (jqXHR, textStatus, errorThrown) {
                messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                $('#btnAceptModalCrud').prop('disabled', false);
            } 
        },

        

        "columns":
        [
            {"data": "rucTerceroDesc", "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                $(nTd).html("<a target='_blank' href='../fichaRuc/consulta?ruc="+oData.rucTercero+"'>"+oData.rucTerceroDesc+"</a>");
            }},     

            //{"data":"cantCompromisos"},
            {"data":"cantCompromisos","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                //$(nTd).html("");
                if (true){
                    $(nTd).html("<form target='_blank' method='post' action='./consulta'>\
                    <input type='hidden' name='rucTercero' value='"+oData.rucTercero+"'>\
                    <input type='hidden' name='shape' value='2'>\
                    <input type='hidden' name='title' value='Consulta de Compromisos (Tercero: "+oData.rucTerceroDesc+")'>\
                    <left><input class='btn btn-primary' type='submit' value='"+oData.cantCompromisos+"'></left>\
                    </form>");
                }else{
                    $(nTd).html("");
                }
                
            }},
            {"data":"cantCuotas","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                //$(nTd).html("");
                if (true){
                    $(nTd).html("<form target='_blank' method='post' action='./cuota'>\
                    <input type='hidden' name='rucTercero' value='"+oData.rucTercero+"'>\
                    <input type='hidden' name='shape' value='3'>\
                    <input type='hidden' name='title' value='Consulta de Cuotas (Tercero: "+oData.rucTerceroDesc+")'>\
                    <left><input class='btn btn-primary' type='submit' value='"+oData.cantCuotas+"'></left>\
                    </form>");
                }else{
                    $(nTd).html("");
                }
                
            }},
            {"data":"mtoTotalInformado"}            
        ],
    });
    
    /*$.ajax({
        'url' : '../aplicacion/getFeriados',
        'type' : 'POST',
        'success' : function(data) {
            var a=JSON.parse(data);
            for(i=0; i<=a.data.length-1; i++){
                feriadosArray.push(a.data[i].fecha);
            }
        }
    });*/




    



    
    
}



function getListaTerceros(rc){

    $.ajax({
        'url' : './getListaTerceros',
        data: {
            "rc":rc
        },
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                $('#codTercero').append($('<option></option>').val(row.codTercero).html(row.rucTercero+' - '+row.nombreTercero));    
                
            }
        }
    });
}


