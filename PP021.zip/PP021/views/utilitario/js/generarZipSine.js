
$(document).ready(function () {

    inicializarModulo();
       
});

function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
    }
    
    $('#tipoGeneracion').val('01');
    
    mostrarContador3();
     
    setInterval(timer, 10000);
    setInterval(mostrarContador3, 5000);
    

    $("#formPdf").on("submit", function(){

        var files = document.getElementById("archivos[]").files;

        if (files.length>0){
            return true;
        }else{

            messageBox(2,'Error','Existen campos vacíos');
            return false;
            
        }
          
        
    });
  
    
    
}


function limpiarFromPdf(){

    $("#formPdf")[0].reset();
    

}

function mostrarContador3(){
    $.ajax({
        'url' : './getContador3',
        data: {},
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                $('#contador3').text('Contador total de archivos zip generados : '+row.contador);
                //$('#contador1').val(row.contador);    
                //alert(row.contador);
            }
        }
    });
}


