
$(document).ready(function () {

    inicializarModulo();
    

    //Modal Sel
    $("#mostrarModalSel").on("click", function(){

        limpiarModalCrud();

        $('#tituloCrud').text('Seleccionar');
        $("#btnAceptCrud").attr('accion','sel');
        $("#btnAceptCrud").text('Buscar');
        $("#btnCancelCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formCrud div.form-group").hide();
        $("#idActividadDiv").show();
        $("#idActividad").prop('disabled', false);
        $("#idAreaDiv").show();
        $("#fechaRangoDiv").show();
        $("#idUsuarioDiv").hide();
        $("#actividadDiv").show();
        $("#productoDiv").show();
        $("#estadoDiv").show();
               
        $("#idActividad").focus();

        $('#btnAceptCrud').attr('class','btn btn-primary');

        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloCrud').text('Nuevo Registro');
        $("#btnAceptCrud").attr('accion','ins');
        $("#btnAceptCrud").text('Enviar');
        $("#btnCancelCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formCrud div.form-group").show();
        $("#idActividadDiv").hide();
        $("#idActividad").prop('disabled', false);
        $("#idAreaDiv").hide();
        $("#fechaRangoDiv").hide();
        $("#idUsuarioDiv").hide();
        $("#actividadDiv").show();
        $("#productoDiv").show();        
        $("#estadoDiv").hide();

        $("#idActividad").focus();

        $('#btnAceptCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });       

    //btnAceptCrud
    $("#btnAceptCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    "order": [],
                    //"order":[[3,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getActividadesPersonalPendientes",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            //$('#dataTable').dataTable({"destroy": true});
                            messageBox(3,"Error","Comuníquese con el administrador.");
                        } 
                    },

                    "columns":
                    [
                        {"data":"id"},
                        {"data":"idAreaDesc"},
                        {"data":"fecha"},
                        {"data":"idUsuarioDesc"},
                        {"data":"actividad"},
                        {"data":"producto"},
                        {"data":"fechaEstimadaEntrega"},
                        {"data":"productoEntregado"},
                        {"data":"fechaEntrega"},
                        {"data":"horasOcupadas"},
                        {"data":"comentario"},
                        {"data":"estadoDesc"},
                        {"data":"idJefeDesc"},
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            
                            if (oData.checkidJefe == '1' && oData.estado=='02'){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' idActividad='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fa fa-info'></i></button>\
                                        <button type='button' idActividad='"+oData.id+"' class='Aut btn btn-success' data-toggle='tooltip' title='Autorizar'><i class='fa fa-check'></i></button>\
                                        <button type='button' idActividad='"+oData.id+"' class='Rec btn btn-danger' data-toggle='tooltip' title='Rechazar'><i class='fa fa-times'></i></button>\
                                    </div>\
                                </div>");
                            }else if(oData.checkidJefe == '1' && oData.estado=='04'){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' idActividad='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fa fa-info'></i></button>\
                                    </div>\
                                </div>");
                            }

                            
                            
                        }}
                    ],
                });


                var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { extend: 'excel', text: 'Descargar Excel', className: 'btn btn-primary float-left', type:'button', align:'rigth'}
                    ]
                }).container().appendTo($('#descargaDataDiv'));

                

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                    
                    limpiarModalCrud();

                    $('#tituloCrud').text('Información');
                    $("#btnAceptCrud").attr('accion','get');
                    $("#btnAceptCrud").text('Aceptar');
                    $("#btnCancelCrud").hide();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptCrud').prop('disabled', false);

                    $("#formCrud div.form-group").show();
                    $("#idActividadDiv").show();
                    $("#idActividad").prop('disabled', true);
                    $("#idAreaDiv").show();
                    $("#fechaRangoDiv").hide();
                    $("#idUsuarioDiv").show();
                    $("#actividadDiv").show();
                    $("#productoDiv").show();        
                    $("#estadoDiv").show();

                    $("#idActividad").focus();

                    $('#btnAceptCrud').attr('class','btn btn-primary');     

                    get($(this).attr("idActividad"));
                    
                    $('#modalCrud').modal('show');
                });

                //(autorizar)
                $('#dataTable tbody').on('click','button.Aut',function(){
                    
                    $.ajax({
                        method:"POST",
                        url: "./autActividadPersonal",
                        data: {              
                            "idActividad":$(this).attr("idActividad")
                        },
                        success : function(data) {
                            
                            $('#dataTable').DataTable().ajax.reload();
                            $('#modalCrud').modal('hide');
                            messageBox(1,"Exito","Se autorizó la actividad");
                            
                        },
                        error: function( req, status, err ) {
                            messageBox(3,"Error","Comunicarse con el administrador.");
                        }
                    });
                    
                })

                //(rechazar)
                $('#dataTable tbody').on('click','button.Rec',function(){
                     
                    $.ajax({
                        method:"POST",
                        url: "./recActividadPersonal",
                        data: {              
                            "idActividad":$(this).attr("idActividad")
                        },
                        success : function(data) {
                            
                            $('#dataTable').DataTable().ajax.reload();
                            $('#modalCrud').modal('hide');
                            messageBox(1,"Bien","Se rechazó la actividad");
                            
                        },
                        error: function( req, status, err ) {
                            messageBox(3,"Error","Comunicarse con el administrador.");
                        }
                    });

                })

                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        /*if ($(this).attr('accion')=='upd'){
           

            if (($("#idActividad").val() != "" && $("#idActividad").val() != null) &&
                ($("#fecha").val() != "" && $("#fecha").val() != null) &&
                ($("#actividad").val() != "" && $("#actividad").val() != null) &&
                ($("#producto").val() != "" && $("#producto").val() != null) &&
                ($("#fechaEstimadaEntrega").val() != "" && $("#fechaEstimadaEntrega").val() != null) &&
                ($("#productoEntregado").val() != "" && $("#productoEntregado").val() != null) &&
                ($("#fechaEntrega").val() != "" && $("#fechaEntrega").val() != null) &&
                ($("#horasOcupadas").val() != "" && $("#horasOcupadas").val() != null) &&
                ($("#idJefe").val() != "" && $("#idJefe").val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);



                $.ajax({
                    method:"POST",
                    url: "./updActividadPersonal",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');
                        messageBox(1,"Exito","Se modificaron los datos.");
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
                });
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', true);
            }
        }*/

        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delActividadPersonal",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,"Error","Comunicarse con el administrador.");
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($("#fecha").val() != "" && $("#fecha").val() != null) &&
                ($("#actividad").val() != "" && $("#actividad").val() != null) &&
                ($("#producto").val() != "" && $("#producto").val() != null) &&
                ($("#fechaEstimadaEntrega").val() != "" && $("#fechaEstimadaEntrega").val() != null) &&
                ($("#productoEntregado").val() != "" && $("#productoEntregado").val() != null) &&
                ($("#fechaEntrega").val() != "" && $("#fechaEntrega").val() != null) &&
                ($("#horasOcupadas").val() != "" && $("#horasOcupadas").val() != null) &&
                ($("#idJefe").val() != "" && $("#idJefe").val() != null)){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insActividadPersonal",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');
                        messageBox(1,"Exito","Se registraron los datos.");
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
                });
            
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', false);
            }

        }
    });   
        
    //Consulta
    $("#btnAceptCrud").attr('accion','sel');
    $('#btnAceptCrud').trigger('click');    
        
});

function get(id){
    $.ajax({
        method:"POST",
        url : './getActividadPersonal',
        data: {
            "idActividad":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $("#idActividad").val(row.id);
                
                if (row.idArea !== null && row.idArea.trim() !== "" ){
                    $("#idArea").append($("<option selected='selected'></option>").val(row.idArea).text(row.idArea)).trigger('change');
                }

                if (row.idUsuario !== null && row.idUsuario.trim() !== "" ){
                    $("#idUsuario").append($("<option selected='selected'></option>").val(row.idUsuario).text(row.idUsuario)).trigger('change');
                }

                $("#idUsuario").val(row.idUsuario);
                $("#actividad").val(row.actividad);
                $("#producto").val(row.producto);
                //$("#fechaEstimadaEntrega").val(row.fechaEstimadaEntrega);
                $("#productoEntregado").val(row.productoEntregado);
                //$("#fechaEntrega").val(row.fechaEntrega);
                $("#horasOcupadas").val(row.horasOcupadas);
                $("#comentario").val(row.comentario);
                $("#sumilla").val(row.sumilla);
                $("#estado").val(row.estado);
                $("#idJefe").val(row.idJefe);                
            
                
                $('#fechaDiv .input-group.date').datepicker('setDate', row.fecha);
                $('#fechaEstimadaEntregaDiv .input-group.date').datepicker('setDate', row.fechaEstimadaEntrega);
                $('#fechaEntregaDiv .input-group.date').datepicker('setDate', row.fechaEntrega);

                
            }

        }
    });
}

function limpiarModalCrud(){

    $("#formCrud")[0].reset();

    $("#idUsuario").val("");
    $("#idUsuario").text("");

    $("#idArea").val("");
    $("#idArea").text("");



    //$('[name^="nro_rtf_array"]').remove();
}
   
function inicializarModulo(){

    document.title = "Mis Actividades";
        
    $('#estado').append($('<option></option>').val("").html("Seleccionar"));
    $('#estado').append($('<option></option>').val("00").html("00 - RECHAZADO"));
    $('#estado').append($('<option></option>').val("02").html("02 - PEND. AUTORIZACIÓN"));
    $('#estado').append($('<option></option>').val("04").html("04 - AUTORIZADO"));
   
    $("#idArea").select2({ 

        placeholder: "Seleccionar Área", 
        minimumInputLength: 3, 
        language: {
            inputTooShort: function() {
                return 'Agregar carateres para buscar...'
            }
        },
        multiple: false, 
        width: 400, 
        ajax: { 
            
            url: "../aplicacion/getAreaCombo",
            type: "POST", 
            data: function(term) { 
                return term;
            }, 
            processResults: function(data, page) { 
                var jsonData = JSON.parse(data);
                return { 

                    results: $.map(jsonData.data, function (item) {
            
                        return {
                            id: item.id_area,
                            text: item.id_area + ' - ' + item.descripcion 
                            
                        }
                    })                    
                }; 
            }, 
        } 
    });

    $("#idUsuario").select2({ 

        placeholder: "Seleccionar Solicitante", 
        minimumInputLength: 3, 
        language: {
            inputTooShort: function() {
                return 'Agregar carateres para buscar...'
            }
        },
        multiple: false, 
        width: 400, 
        ajax: { 
            
            url: "../aplicacion/getUsuarioCombo",
            type: "POST", 
            data: function(term) { 
                return term;                
            }, 
            processResults: function(data, page) {         
                var jsonData = JSON.parse(data);
                return { 
                    results: $.map(jsonData.data, function (item) {
                        return {
                            id: item.id,
                            text: item.id + ' - ' + item.nombres 
                        }
                    })                    
                }; 
            }, 
        } 
    }); 
    
    $('#idJefe').append($('<option></option>').val("").html("Seleccionar"));

    $.ajax({
        'url' : '../aplicacion/getJefeUsuarioSession',
        'type' : 'POST',
        'success' : function(data) {
           
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                $('#idJefe').append($('<option></option>').val(row.id).html(row.apellido_paterno+' '+row.apellido_materno+' '+row.nombres));
            }
            
        }
    });


    $('#fechaDiv .input-group.date').datepicker({
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'yyyy-mm-dd',
        endDate: '0d', //startDate: '-1d',  
        language: 'es'
    });
    
    $("#fecha").mask("9999-99-99");

    $('#fechaEstimadaEntregaDiv .input-group.date').datepicker({
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'yyyy-mm-dd',
        endDate: '0d', //startDate: '-1d',  
        language: 'es'
    });
    
    $("#fechaEstimadaEntrega").mask("9999-99-99");

    $('#fechaEntregaDiv .input-group.date').datepicker({
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'yyyy-mm-dd',
        endDate: '0d', //startDate: '-1d',  
        language: 'es'
    });
    
    $("#fechaEntrega").mask("9999-99-99");

    $('#fechaRangoDiv .input-group.date').datepicker({
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'yyyy-mm-dd',
        endDate: '0d', //startDate: '-1d',  
        language: 'es'
    });
    
    $("#fechaIni").mask("9999-99-99");
    $("#fechaFin").mask("9999-99-99");

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });

    $('#horasOcupadas').keyup(function(){

        if($(this).val() != ""){
            $(this).val(parseInt($(this).val()));

            if(Number.isInteger(parseInt($(this).val())) == false ) {
                alert("Sólo números válidos");  
                $(this).val("");     
            }
        }
    });
}

function messageBox(icono,titulo,mensaje){
    //document.getElementById("iconoModalMensaje").innerHTML = '<img src="'+g_img_check+'" >';

    
    document.getElementById("modalMensaje").innerHTML = "<div class='modal-dialog'>\
        <div class='modal-content'>\
            <div class='modal-header'>\
                <h4 id='tituloModalMensaje' class='modal-title'>Titulo</h4>\
                <button type='button' class='close' data-dismiss='modal'>&times;</button>\
            </div>\
            <div class='modal-body'>\
                <table>\
                    <tr>\
                        <th width='32' align='center'><p id='iconoModalMensaje'></p></th>\
                        <th><p id='textoModalMensaje'>Mensaje</p></th>\
                    </tr>\
                </table>\
            </div>\
            <div class='modal-footer'>\
                <div class='form-group row'>\
                    <div class='col-sm-12'>\
                        <div align='center'>\
                            <button id='btnModalMensaje' type='button' class='btn btn-primary' type='button'>Aceptar</button>\
                        </div>\
                    </div>\
                </div>\
            </div>\
        </div>\
    </div>";


    if(icono==1){ 
        document.getElementById("iconoModalMensaje").innerHTML = '<img src="../public/flat/sign-check.png" >'; 
    } 
    if(icono==2){ 
        document.getElementById("iconoModalMensaje").innerHTML = '<img src="../public/flat/sign-warning.png" >'; 
    } 
    if(icono==3){ 
        document.getElementById("iconoModalMensaje").innerHTML = '<img src="../public/flat/sign-error.png" >'; 
    } 

    
    document.getElementById("tituloModalMensaje").innerHTML = titulo;
    document.getElementById("textoModalMensaje").innerHTML = mensaje;

    //Aceptar Mensaje
    $("#btnModalMensaje").on("click", function(){
        $('#modalMensaje').modal('hide');
    });


    $('#modalMensaje').modal('show');
}