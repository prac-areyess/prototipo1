
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $('#mostrarModalSel').on('click', function(){
        
        limpiarModalCrud();
                
        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        $('#IDDiv').show();
        $('#ID').prop('disabled', false);
        $('#RLADUANADiv').show();
        $('#RLADUANA').prop('disabled', false);
        $('#RLANODiv').show();
        $('#RLANO').prop('disabled', false);
        $('#RLNROLIQDiv').show();
        $('#RLNROLIQ').prop('disabled', false);
        
               
        $('#RLADUANA').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }

        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $("#mostrarModalIns").on("click", function(){
        
        // limpiarModalCrud();

        // $('#tituloModalCrud').text('Nuevo Registro');
        // $('#btnAceptModalCrud').attr('accion','ins');
        // $('#btnAceptModalCrud').text('Registrar');
        // $('#btnCancelModalCrud').show();

        // $('#formCrud *').prop('disabled', false);
        // $('#btnAceptModalCrud').prop('disabled', false);

        // $('#formCrud div.form-group').show();
        // $('#IDDiv').show();
        // $('#ID').prop('disabled', false);
        // $('#RLADUANADiv').show();
        // $('#RLADUANA').prop('disabled', false);
        // $('#RLANODiv').show();
        // $('#RLANO').prop('disabled', false);
        // $('#RLNROLIQDiv').show();
        // $('#RLNROLIQ').prop('disabled', false);
        

        // $('#RLADUANA').focus();
        
        // $('#btnAceptModalCrud').attr('class','btn btn-primary');

        // $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $("#btnAceptModalCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();               
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptModalCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();
                //$('#dataTable').DataTable().destroy();

                var table;
                table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    //"bSort": true,
                    //"order":[[0,"asc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getLiquidaciones",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    'columnDefs': [
                    {
                        'targets': 0,
                        'createdCell':  function (td, cellData, rowData, row, col) {
                           $(td).attr('idFila', rowData.ID); 
                        }
                    }],

                    "columns":
                    [
                        {
                            "class":          'details-control',
                            "orderable":      false,
                            "data":           null,
                            "defaultContent": '',
                            "idFila": "ID",
                        },
                        {"data":"ID"},
                        {"data":"NUMERO_LIQUIDACION"},

                        {"data":"TIPO_LIQUIDACION","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                        //fechaDate = moment(oData.fecFin);
                        //fechaHoy = moment((new Date()).getDate());
                        //console.log(fechaDate);
                        // console.log((new Date()));
                        //console.log(fechaDate.diff(fechaHoy, 'days'));
                        
                            if(oData.TIPO_LIQUIDACION == 'LC_MATRIZ_TRANSF' || (oData.RLADUANA == $('#RLADUANA').val() && oData.RLANO == $('#RLANO').val() && oData.RLNROLIQ == $('#RLNROLIQ').val())){ 
                                $(nTd).css('background-color', '#e7b7c5' );
                            }else if(oData.TIPO_LIQUIDACION == 'LC_PAGO') { 
                                $(nTd).css('background-color', '#fbe9cb' );                                         
                            }else{
                                //$(nTd).css('background-color', '#ebf5fc' );
                            };
                    
                        }},

                        {"data":"RLLIBTRI"},
                        {"data":"RLCOMITE"},
                        {"data":"FEC_LIQUIDACION"},
                        {"data":"FEC_CANCELADO"},
                        {"data":"MONEDA"},
                        {"data":"MONTO_DOLARES"},
                        {"data":"MONTO_SOLES"},
                        {"data":"PAGOS_SOLES"},
                        {"data":"PAGOS_DOLARES"},
                        {"data":"SALDO_SIN_INT_SOLES"},
                        {"data":"SALDO_SIN_INT_DOLARES"},
                        {"data":"RLCODORIDESC"}

                        

                        
                    ],

                    // "createdRow": function( row, data, dataIndex ) {
                    //     $(row).attr('idFila', data.ID);
                    // },

                    



                });


                if($('#shape').val()=='1' || $('#shape').val()=='2'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }



                $('#dataTable tbody').on('click', 'td.details-control', function () {
                    var tr = $(this).parents('tr');
                    var row = table.row( tr );

                    var idFila = $(this).attr('idFila');
             
                    if ( row.child.isShown() ) {
                        // This row is already open - close it
                        row.child.hide();
                        tr.removeClass('shown');
                    }
                    else {
                        // Open this row
                        //row.child( format(row.data()) ).show();
                        row.child( format(idFila) ).show();
                        tr.addClass('shown');

                        //llenar datatablehijo
                        var datos = row.data();
                        //alert(datos.ID);
                        //alert(idFila);
                        getTablaHijo(idFila);

                        $(row.child()).css("background-color", "#eff2f7");


                    }
                } );


                //$(table.table().footer()).html('Your html content here ....');




                

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                                       
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#IDDiv').show();
                    $('#ID').prop('disabled', true);
                    $('#RLADUANADiv').show();
                    $('#RLADUANA').prop('disabled', true);
                    $('#RLANODiv').show();
                    $('#RLANO').prop('disabled', true);
                    $('#RLNROLIQDiv').show();
                    $('#RLNROLIQ').prop('disabled', true);
                    


                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('RLADUANA'));     

                    $('#modalCrud').modal('show');

                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    // limpiarModalCrud();
                     
                    // $('#tituloModalCrud').text('Modificar');
                    // $("#btnAceptModalCrud").attr('accion','upd');
                    // $("#btnAceptModalCrud").text('Guardar');
                    // $("#btnCancelModalCrud").show();

                    // $('#formCrud *').prop('disabled', false);
                    // $('#btnAceptModalCrud').prop('disabled', false);

                    // $('#formCrud div.form-group').show();
                    // $('#RLADUANADiv').show();
                    // $('#RLADUANA').prop('disabled', true);
                    // $('#RLANODiv').show();
                    // $('#RLANO').prop('disabled', true);
                    // $('#RLNROLIQDiv').show();
                    // $('#RLNROLIQ').prop('disabled', true);
                    

                    // $('#idDiv').focus();

                    // $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    // get($(this).attr('RLADUANA'));

                    // $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    // limpiarModalCrud();

                    // $('#tituloModalCrud').text('Eliminar');       
                    // $('#btnAceptModalCrud').attr('accion','del');
                    // $('#btnAceptModalCrud').text('Eliminar');
                    // $('#btnCancelModalCrud').show();

                    // $('#formCrud *').prop('disabled', true);
                    // $('#btnAceptModalCrud').prop('disabled', false);
                    
                    // $('#formCrud div.form-group').show();
                    // $('#RLADUANADiv').show();
                    // $('#RLADUANA').prop('disabled', true);
                    // $('#RLANODiv').show();
                    // $('#RLANO').prop('disabled', true);
                    // $('#RLNROLIQDiv').show();
                    // $('#RLNROLIQ').prop('disabled', true);
                    

                    // $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    // get($(this).attr('RLADUANA'));

                    // $('#modalCrud').modal('show');
                })

                getDatosGenerales($('#RLLIBTRI').val());


                $('#modalCrud').modal('hide');






            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            // if (($('#id').val() != '' && $('#id').val() != null) &&
            //     ($('#id').val() != '' && $('#id').val() != null)){
                
            //     $('#formCrud *').prop('disabled', false);
            //     var frm = $("#formCrud").serialize();
            //     $('#formCrud *').prop('disabled', true);

            //     $.ajax({
            //         method:"POST",
            //         url: "./updUsuario",
            //         data: frm,
            //         success : function(data) {
                        
            //             $('#dataTable').DataTable().ajax.reload();
            //             $('#modalCrud').modal('hide');

            //             try {
            //                 var jsonData = JSON.parse(data);
            //                 var msjDatos = '';
            //                 for (var i = 0; i < jsonData.data.length; i++) {
            //                     var row = jsonData.data[i];
            //                     msjDatos += row.id + ' ';
            //                 }   
            //                 messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
            //             }
            //             catch(e) {
            //                messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //             }   
            //         },
            //         error: function( req, status, err ) {
            //             messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //         }
            //     });
            // }else{
            //     messageBox(2,'Error','Existen campos vacíos');
            // }
        }

        if ($(this).attr('accion')=='del'){
           
            // $('#formCrud *').prop('disabled', false);
            // var frm = $("#formCrud").serialize();
            // $('#formCrud *').prop('disabled', true);

            // $.ajax({
            //     method:"POST",
            //     url: "./delUsuario",
            //     data: frm,
            //     success : function(data) {
                
            //         $('#modalCrud').modal('hide');
            //         $('#dataTable').DataTable().ajax.reload();

            //         try {
            //             var jsonData = JSON.parse(data);
            //             var msjDatos = '';
            //             for (var i = 0; i < jsonData.data.length; i++) {
            //                 var row = jsonData.data[i];
            //                 msjDatos += row.id + ' ';
            //             }   
            //             messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
            //         }
            //         catch(e) {
            //            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //         }   
                   
            //     },
            //     error: function( req, status, err ) {
            //         messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //     }
            // });
        }

        if ($(this).attr('accion')=='ins'){
            
            // if (($("#id").val() != "" && $("#id").val() != null) &&
            //     ($("#id").val() != "" && $("#id").val() != null) ){


            //     $('#formCrud *').prop('disabled', false);
            //     var frm = $("#formCrud").serialize();
            //     $('#formCrud *').prop('disabled', true);

            //     $.ajax({
            //         method:"POST",
            //         url: "./insUsuario",
            //         data: frm,
            //         success : function(data) {
                        
            //             $('#dataTable').DataTable().ajax.reload();
            //             $('#modalCrud').modal('hide');

            //             try {
            //                 var jsonData = JSON.parse(data);
            //                 var msjDatos = '';
            //                 for (var i = 0; i < jsonData.data.length; i++) {
            //                     var row = jsonData.data[i];
            //                     msjDatos += row.id + ' ';
            //                 }   
            //                 messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
            //             }
            //             catch(e) {
            //                messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //             }   
                        
            //         },
            //         error: function( req, status, err ) {
            //             messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //         }
            //     });
            
            // }else{
            //     messageBox(2,'Error','Existen campos vacíos');
            // }

        }
    });   
        
    //Consulta
    //$("#btnAceptModalCrud").attr('accion','sel');
    //$('#btnAceptModalCrud').trigger('click');   


    if($('#shape').val()=='1'){
        // var myDateIni = new Date();
        // $('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        // $('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        // $('#btnAceptModalCrud').attr('accion','sel');
        // $('#btnAceptModalCrud').trigger('click'); 

        $('#mostrarModalSel').trigger('click'); 

        frmSelBkp = null;

        // $('#alertaDataTable').show();  
        // $('#alertaDataTableMensaje').text('Se muestran los registros de los últimos 30 días. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');

    }

    if($('#shape').val()=='2'){
        //var myDateIni = new Date();
        //$('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        //$('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 

        frmSelBkp = null;

        //$('#alertaDataTable').show();  
        //$('#alertaDataTableMensaje').text('Se muestran los registros de los últimos 30 días. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');

    }  
        
});

function get(ID,RLADUANA,RLANO,RLNROLIQ){

    $.ajax({
        method:"POST",
        url : './getLiquidaciones',
        data: {
            "ID":ID,
            "RLADUANA":RLADUANA,
            "RLANO":RLANO,
            "RLNROLIQ":RLNROLIQ
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $('#ID').val(row.ID);
                $('#RLADUANA').val(row.RLADUANA);
                $('#RLANO').val(row.RLANO);
                $('#RLNROLIQ').val(row.RLNROLIQ);
                $('#RLCODDES').val(row.RLCODDES);
                $('#RLCODUSU').val(row.RLCODUSU);
                // if(row.fecha_nacimiento != null){
                //     $('#fecha_nacimiento').val(moment(row.fecha_nacimiento, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                // }
                //$('#id_area').val(row.id_area);

                // if (row.id_area !== null && row.id_area.trim() !== '' ){
                //     $('#id_area').append($("<option selected='selected'></option>").val(row.id_area).text(row.id_area)).trigger('change');
                // }
                $('#RLTIPLIQ').val(row.RLTIPLIQ);
                $('#RLTIPDOC').val(row.RLTIPDOC);
                $('#RLLIBTRI').val(row.RLLIBTRI);
                $('#RLCOMITE').val(row.RLCOMITE);
                $('#RLCODORI').val(row.RLCODORI);
                $('#RLDIRECC').val(row.RLDIRECC);
                
            }

        }
    });
}

function format ( d ) {
    // `d` is the original data object for the row
    return "<table id='"+d+"' class='table cell-border compact'>\
            <thead>\
            <tr bgcolor='#d7d9de'>\
                <th>RDCODRUB</th>\
                <th>DESCRI</th>\
                <th>RDMONDET</th>\
                <th>MONEDA</th>\
                <th>CONVERSION_SOLES</th>\
                <th>CONVERSION_DOLARES</th>\
                <th>PAGOS_SOLES</th>\
                <th>PAGOS_DOLARES</th>\
                <th>SALDO_SIN_INT_SOLES</th>\
                <th>SALDO_SIN_INT_DOLARES</th>\
            </tr>\
            </thead>\
        </table>\
        <br>\
        PAGOS_SOLES y PAGOS_DOLARES -> Misma cantidad pagada expresada en soles y en dolares.\
        <br>\
        CONVERSION_SOLES y CONVERSION_DOLARES -> RDMONDET con aplicación del tipo de cambio\
        ";
}

function getTablaHijo(ID){


    var tableDetalle = $('#'+ID).DataTable({
        "destroy": true,            
        "pageLength": 10,
        "scrollX": true,
        "paging": false,
        "searching": false,
        "info": false,
        "language":{
            "sProcessing":     "Procesando...",
            "sLengthMenu":     "Mostrar _MENU_ registros",
            "sZeroRecords":    "No se encontraron resultados",
            "sEmptyTable":     "Ningún dato disponible en esta tabla",
            "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix":    "",
            "sSearch":         "Filtrar:",
            "sUrl":            "",
            "sInfoThousands":  ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst":    "Primero",
                "sLast":     "Último",
                "sNext":     "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            }
        },
        //"bSort": true,
        //"order":[[0,"asc"]],                 
        
        "ajax":
        {
            "method":"POST",
            "url": "./getLiquidacionesDetalle",
            "data": {
                "ID": ID
            },     
            error: function (jqXHR, textStatus, errorThrown) {
                messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                //$('#btnAceptModalCrud').prop('disabled', false);
            } 
        },

        


        "columns":
        [          
            {"data":"RDCODRUB"},
            {"data":"DESCRI"},
            {"data":"RDMONDET"},
            {"data":"MONEDA"},
            {"data":"CONVERSION_SOLES"},
            {"data":"CONVERSION_DOLARES"},
            {"data":"PAGOS_SOLES"},
            {"data":"PAGOS_DOLARES"},
            {"data":"SALDO_SIN_INT_SOLES"},
            {"data":"SALDO_SIN_INT_DOLARES"}
            
        ],




    });

}

function getDatosGenerales(RLLIBTRI){

    
    $.ajax({
        method:"POST",
        url : './getDatosDeudor',
        data: {
            "RLLIBTRI":RLLIBTRI
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                

                $('#titleModule').text('REPORTE DEUDOR ' + row.RLLIBTRI + '-' + row.RLCOMITE);

                
            }

            if(jsonData.data.length == 0 ){
                $('#titleModule').text('REPORTE DEUDOR (No hay resultado) ');
            }


        }
    });
}

function deserializar(dataArray){

    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });
        //$('#ID').val(row.ID);
        $('#RLADUANA').val(row.RLADUANA);
        $('#RLANO').val(row.RLANO);
        $('#RLNROLIQ').val(row.RLNROLIQ);
        $('#RLCODDES').val(row.RLCODDES);
        $('#RLCODUSU').val(row.RLCODUSU);
        // if(row.fecha_nacimiento != null){
        //     $('#fecha_nacimiento').val(moment(row.fecha_nacimiento, 'YYYY-MM-DD').format('DD/MM/YYYY'));
        // }
        //$('#id_area').val(row.id_area);

        // if (row.id_area !== null && row.id_area.trim() !== '' ){
        //     $('#id_area').append($("<option selected='selected'></option>").val(row.id_area).text(row.id_area)).trigger('change');
        // }
        $('#RLTIPLIQ').val(row.RLTIPLIQ);
        $('#RLTIPDOC').val(row.RLTIPDOC);
        $('#RLLIBTRI').val(row.RLLIBTRI);
        $('#RLCOMITE').val(row.RLCOMITE);
        $('#RLCODORI').val(row.RLCODORI);
        $('#RLDIRECC').val(row.RLDIRECC);
        
    }
}

function limpiarModalCrud(){

    $('#formCrud')[0].reset();

    $('#id_area').val('');
    $('#id_area').text('');

    $("input[name^='idArray']").remove();

}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').hide();
    }

    if($('#shape').val()=='2'){
        //Consulta por Numero Liquidacion
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').hide();
    }

    
    // $('#estado').append($('<option></option>').val('').html('Seleccionar'));
    // $('#estado').append($('<option></option>').val('00').html('00 - INACTIVO'));
    // $('#estado').append($('<option></option>').val('01').html('01 - ACTIVO'));
    
    setInterval(timer, 10000);
        
    // $.ajax({
    //     'url' : '../aplicacion/getDependencias',
    //     data: {},
    //     'type' : 'POST',
    //     'success' : function(data) {

    //         var jsonData = JSON.parse(data);

    //         for (var i = 0; i < jsonData.data.length; i++) {
    //             var row = jsonData.data[i];
    //             $('#id_dependencia').append($('<option></option>').val(row.id).html(row.id+' - '+row.desc_dependencia));    
    //         }
    //     }
    // });


    


    // $('#fecha_nacimiento').datepicker({
    //     todayBtn: "linked",
    //     //keyboardNavigation: false,
    //     //forceParse: false,
    //     calendarWeeks: false,
    //     autoclose: true,
    //     format: 'dd/mm/yyyy',
    //     //startDate: '0d',  
    //     //endDate: '+90d', //startDate: '-1d',  
    //     language: 'es',
    //     //daysOfWeekDisabled: [0],
    //     container:'#fecha_nacimientoContainer'
    // });
    
    

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });



    
    
}


