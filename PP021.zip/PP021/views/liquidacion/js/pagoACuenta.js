
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $('#mostrarModalSel').on('click', function(){
        
        limpiarModalCrud();
                
        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        $('#RLADUANADiv').hide();
        $('#RLADUANA').prop('disabled', false);
        $('#RLANODiv').hide();
        $('#RLANO').prop('disabled', false);
        $('#RLNROLIQDiv').hide();
        $('#RLNROLIQ').prop('disabled', false);
        $('#RLCODDESDiv').hide();
        $('#RLCODUSUDiv').hide();
        $('#RLTIPLIQDiv').hide();
        $('#RLTIPDOCDiv').hide();
        $('#RLLIBTRIDiv').show();
        $('#RLCOMITEDiv').hide();
        $('#RLCODORIDiv').hide();
        $('#RLDIRECCDiv').hide();
               
        $('#RLADUANA').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }

        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $('#btnAceptModalCrud').attr('accion','ins');
        $('#btnAceptModalCrud').text('Registrar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').show();
        $('#RLADUANADiv').show();
        $('#RLADUANA').prop('disabled', false);
        $('#RLANODiv').show();
        $('#RLANO').prop('disabled', false);
        $('#RLNROLIQDiv').show();
        $('#RLNROLIQ').prop('disabled', false);
        $('#RLCODDESDiv').show();
        $('#RLCODUSUDiv').show();
        $('#RLTIPLIQDiv').show();
        $('#RLTIPDOCDiv').show();
        $('#RLLIBTRIDiv').show();
        $('#RLCOMITEDiv').show();
        $('#RLCODORIDiv').show();
        $('#RLDIRECCDiv').show();

        $('#RLADUANA').focus();
        
        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $("#btnAceptModalCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();               
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptModalCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"asc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getPagosACuenta",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    
                    "columns":
                    [
                        {"data":"ID"},                           
                        {"data":"RLLIBTRI"},
                        {"data":"RLCOMITE"},
                        {"data":"FEC_LIQUIDACION"},
                        {"data":"FEC_CANCELADO"},
                        {"data":"MONTO_DOLARES"},
                        {"data":"MONTO_SOLES"},
                        {"data":"RLCODORIDESC"}, 
                        {"data":"RLADUANA"},
                        {"data":"RLANO"},
                        {"data":"RLNROLIQ"},
                        {"data":"RLADUASO"},
                        {"data":"RLANOASO"},
                        {"data":"RLNUMASO"},                                           
                        {"data":"ID","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {

                            if ($('#shape').val()=='1'){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' RLADUANA='"+oData.RLADUANA+"' RLANO='"+oData.RLANO+"' RLNROLIQ='"+oData.RLNROLIQ+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                    </div>\
                                </div>");
                            }
                            else if ($('#shape').val()=='2'){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' RLADUANA='"+oData.RLADUANA+"' RLANO='"+oData.RLANO+"' RLNROLIQ='"+oData.RLNROLIQ+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        <button type='button' RLADUANA='"+oData.RLADUANA+"' RLANO='"+oData.RLANO+"' RLNROLIQ='"+oData.RLNROLIQ+"' class='mostrarModalUpd btn btn-primary'data-toggle='tooltip' title='Modificar'><i class='far fa-edit'></i></button>\
                                        <button type='button' RLADUANA='"+oData.RLADUANA+"' RLANO='"+oData.RLANO+"' RLNROLIQ='"+oData.RLNROLIQ+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                    </div>\
                                </div>"); 
                            }else{                                
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });


                if($('#shape').val()=='1' || $('#shape').val()=='2'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }

                

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                                       
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#RLADUANADiv').show();
                    $('#RLADUANA').prop('disabled', true);
                    $('#RLANODiv').show();
                    $('#RLANO').prop('disabled', true);
                    $('#RLNROLIQDiv').show();
                    $('#RLNROLIQ').prop('disabled', true);
                    $('#RLCODDESDiv').show();
                    $('#RLCODUSUDiv').show();
                    $('#RLTIPLIQDiv').show();
                    $('#RLTIPDOCDiv').show();
                    $('#RLLIBTRIDiv').show();
                    $('#RLCOMITEDiv').show();
                    $('#RLCODORIDiv').show();
                    $('#RLDIRECCDiv').show();


                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('RLADUANA'),$(this).attr('RLANO'),$(this).attr('RLNROLIQ'));     

                    $('#modalCrud').modal('show');

                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Modificar');
                    $("#btnAceptModalCrud").attr('accion','upd');
                    $("#btnAceptModalCrud").text('Guardar');
                    $("#btnCancelModalCrud").show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#RLADUANADiv').show();
                    $('#RLADUANA').prop('disabled', true);
                    $('#RLANODiv').show();
                    $('#RLANO').prop('disabled', true);
                    $('#RLNROLIQDiv').show();
                    $('#RLNROLIQ').prop('disabled', true);
                    $('#RLCODDESDiv').show();
                    $('#RLCODUSUDiv').show();
                    $('#RLTIPLIQDiv').show();
                    $('#RLTIPDOCDiv').show();
                    $('#RLLIBTRIDiv').show();
                    $('#RLCOMITEDiv').show();
                    $('#RLCODORIDiv').show();
                    $('#RLDIRECCDiv').show();

                    $('#idDiv').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('RLADUANA'));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $('#btnAceptModalCrud').attr('accion','del');
                    $('#btnAceptModalCrud').text('Eliminar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#RLADUANADiv').show();
                    $('#RLADUANA').prop('disabled', true);
                    $('#RLANODiv').show();
                    $('#RLANO').prop('disabled', true);
                    $('#RLNROLIQDiv').show();
                    $('#RLNROLIQ').prop('disabled', true);
                    $('#RLCODDESDiv').show();
                    $('#RLCODUSUDiv').show();
                    $('#RLTIPLIQDiv').show();
                    $('#RLTIPDOCDiv').show();
                    $('#RLLIBTRIDiv').show();
                    $('#RLCOMITEDiv').show();
                    $('#RLCODORIDiv').show();
                    $('#RLDIRECCDiv').show();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr('RLADUANA'));

                    $('#modalCrud').modal('show');
                })


                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($('#id').val() != '' && $('#id').val() != null) &&
                ($('#id').val() != '' && $('#id').val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./updUsuario",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }


        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delUsuario",
                data: frm,
                success : function(data) {
                
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();

                    try {
                        var jsonData = JSON.parse(data);
                        var msjDatos = '';
                        for (var i = 0; i < jsonData.data.length; i++) {
                            var row = jsonData.data[i];
                            msjDatos += row.id + ' ';
                        }   
                        messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
                    }
                    catch(e) {
                       messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }   
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($("#id").val() != "" && $("#id").val() != null) &&
                ($("#id").val() != "" && $("#id").val() != null) ){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insUsuario",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }

        }
    });   
        
    //Consulta
    //$("#btnAceptModalCrud").attr('accion','sel');
    //$('#btnAceptModalCrud').trigger('click');   

     
    $('#mostrarModalSel').trigger('click');
        
});

function get(RLADUANA,RLANO,RLNROLIQ){

    $.ajax({
        method:"POST",
        url : './getLiquidaciones',
        data: {
            "RLADUANA":RLADUANA,
            "RLANO":RLANO,
            "RLNROLIQ":RLNROLIQ
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $('#RLADUANA').val(row.RLADUANA);
                $('#RLANO').val(row.RLANO);
                $('#RLNROLIQ').val(row.RLNROLIQ);
                $('#RLCODDES').val(row.RLCODDES);
                $('#RLCODUSU').val(row.RLCODUSU);
                // if(row.fecha_nacimiento != null){
                //     $('#fecha_nacimiento').val(moment(row.fecha_nacimiento, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                // }
                //$('#id_area').val(row.id_area);

                // if (row.id_area !== null && row.id_area.trim() !== '' ){
                //     $('#id_area').append($("<option selected='selected'></option>").val(row.id_area).text(row.id_area)).trigger('change');
                // }
                $('#RLTIPLIQ').val(row.RLTIPLIQ);
                $('#RLTIPDOC').val(row.RLTIPDOC);
                $('#RLLIBTRI').val(row.RLLIBTRI);
                $('#RLCOMITE').val(row.RLCOMITE);
                $('#RLCODORI').val(row.RLCODORI);
                $('#RLDIRECC').val(row.RLDIRECC);
                
            }

        }
    });
}

function deserializar(dataArray){

    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });

        $('#RLADUANA').val(row.RLADUANA);
        $('#RLANO').val(row.RLANO);
        $('#RLNROLIQ').val(row.RLNROLIQ);
        $('#RLCODDES').val(row.RLCODDES);
        $('#RLCODUSU').val(row.RLCODUSU);
        // if(row.fecha_nacimiento != null){
        //     $('#fecha_nacimiento').val(moment(row.fecha_nacimiento, 'YYYY-MM-DD').format('DD/MM/YYYY'));
        // }
        //$('#id_area').val(row.id_area);

        // if (row.id_area !== null && row.id_area.trim() !== '' ){
        //     $('#id_area').append($("<option selected='selected'></option>").val(row.id_area).text(row.id_area)).trigger('change');
        // }
        $('#RLTIPLIQ').val(row.RLTIPLIQ);
        $('#RLTIPDOC').val(row.RLTIPDOC);
        $('#RLLIBTRI').val(row.RLLIBTRI);
        $('#RLCOMITE').val(row.RLCOMITE);
        $('#RLCODORI').val(row.RLCODORI);
        $('#RLDIRECC').val(row.RLDIRECC);
        
    }
}

function limpiarModalCrud(){

    $('#formCrud')[0].reset();

    $('#id_area').val('');
    $('#id_area').text('');

    $("input[name^='idArray']").remove();

}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').hide();
    }

    
    // $('#estado').append($('<option></option>').val('').html('Seleccionar'));
    // $('#estado').append($('<option></option>').val('00').html('00 - INACTIVO'));
    // $('#estado').append($('<option></option>').val('01').html('01 - ACTIVO'));
    
    setInterval(timer, 10000);
        
    // $.ajax({
    //     'url' : '../aplicacion/getDependencias',
    //     data: {},
    //     'type' : 'POST',
    //     'success' : function(data) {

    //         var jsonData = JSON.parse(data);

    //         for (var i = 0; i < jsonData.data.length; i++) {
    //             var row = jsonData.data[i];
    //             $('#id_dependencia').append($('<option></option>').val(row.id).html(row.id+' - '+row.desc_dependencia));    
    //         }
    //     }
    // });


    


    // $('#fecha_nacimiento').datepicker({
    //     todayBtn: "linked",
    //     //keyboardNavigation: false,
    //     //forceParse: false,
    //     calendarWeeks: false,
    //     autoclose: true,
    //     format: 'dd/mm/yyyy',
    //     //startDate: '0d',  
    //     //endDate: '+90d', //startDate: '-1d',  
    //     language: 'es',
    //     //daysOfWeekDisabled: [0],
    //     container:'#fecha_nacimientoContainer'
    // });
    
    

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });



    
    
}


