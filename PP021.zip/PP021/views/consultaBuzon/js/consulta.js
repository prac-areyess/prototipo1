
$(document).ready(function () {

    inicializarModulo();
   
    var frmSelBkp = null;

    $("#mostrarModalSel").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloModalSel').text('Ingrese RUC');
        $("#btnAceptCrud").attr('accion','sel');
        $("#btnAceptCrud").text('Buscar');
        $("#btnCancelCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formCrud div.form-group").hide();
        $("#rucDiv").show();
        $("#cod_usuario").prop('disabled', false);
        $('#idPlanoDiv').show();
               
        //cod_usuario = ruc
        $("#cod_usuario").focus();

        $('#btnAceptCrud').attr('class','btn btn-primary');
        /*if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }*/


        $('#modalSel').modal('show');
    }); 

    

  //btnAceptModalMas
    $("#btnAceptCrud").on("click", function(){



        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();  
                $('#formCrud *').prop('disabled', true);               
                $("#btnAceptCrud").prop("disabled", true);
                $('#modalSel').modal('hide');
                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getdatosBuzon", /////////////////////
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptCrud').prop('disabled', false);
                        } 
                    },

                    "columns":
                    [
                        {"data":"ruc"},
                        {"data":"razon_social"},
                        {"data":"estado"}
                    ],
                });



                var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                }).container().appendTo($('#buttonModule'));
            

                $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");




            }

                    
        }
    });


    //Consulta
    $('#mostrarModalSel').trigger('click');   



}); 

function get(cod_usuario){

    $.ajax({
        method:"POST",
        url : './getdatosBuzon',
        data: {
            "cod_usuario":cod_usuario,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $('#cod_usuario').val(row.cod_usuario);              
            }

        }
    });
}

function limpiarModalCrud(){

    $('#formCrud')[0].reset();
    $("input[name^='idArrayRuc']").remove();


}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
            row[field.name] = field.value;

            
            if (field.name.indexOf("idArrayRuc") >=0 && row.cod_usuario=='*'){
                $('#idArrayDiv').append('<input type="text" name="'+field.name+'" value="'+field.value+ '">');
            }
        });


        $('#cod_usuario').val(row.cod_usuario);

        if (row.cod_usuario=='*'){
            $('#cod_usuario').prop('disabled', true);
        }else{
            $('#cod_usuario').prop('disabled', false);
        }
 

        
    }
}
 


function inicializarModulo(){

 //$('#mostrarModalInsMas').show();
  document.title = $('#title').val();
    $('#titleModule').text($('#title').val());
    if($('#shape').val()=='1'){} 
    setInterval(timer, 10000);


 $('#idPlano').change(function() {

        document.getElementById('idArrayDiv').innerHTML = '';
        $('#cod_usuario').val('');
        $('#cod_usuario').prop('disabled', false);


        var file = this.files[0];
        var item = '';
        var reader = new FileReader();

        reader.onload = function(progressEvent){

         
            var arrayOneRow = new Array();
            var mensajeError = '';
            var linea = 0;
            var lines = this.result.split('\n');
            var htmlArray= '';

            for(var line = 0; line < lines.length; line++){
                item = lines[line];
                item = item.trim();
                if (item != ''){

                    arrayOneRow = item.split("\t");

                    var idUsuario = arrayOneRow[0];                                    
                    
                    linea=line+1

                    if (idUsuario.length != 11 ){
                        mensajeError += '<br><br>Fila '+linea+', columna idUsuario: '+idUsuario+' debe tener 11 dígitos';
                    }   
                   
                    if(mensajeError==''){
                        htmlArray += '<input type="hidden" name="idArrayRuc['+line+']" value="'+arrayOneRow[0]+ '">';
                        //htmlArray += '<input type="hidden" name="idArrayRuc['+line+']" value="'+arrayOneRow[1]+ '">';
                        //htmlArray += '<input type="hidden" name="idArrayRuc['+line+']" value="'+arrayOneRow[2]+ '">';
                    }
                    
                } 

            }


            if (linea == 0 || linea > 600 || mensajeError!='' ){
                if (lines.length == 1){
                    messageBox(2,'Error','El plano esta vacío.');
                }

                if (lines.length > 600){
                    messageBox(2,'Error','Se ha excedido el maximo de 600 registros.');
                }

                if(mensajeError!=''){
                    messageBox(2,'Error','Se detectaron errores en el plano, corregirlo por favor: '+mensajeError);
                }
                
                $('#idPlano').val('');

                document.getElementById('idArrayDiv').innerHTML = '';
                $('#cod_usuario').val('');
                $('#cod_usuario').prop('disabled', false);

            
            
            }

            else {
                document.getElementById('idArrayDiv').innerHTML = htmlArray;
                $('#cod_usuario').val('*');
                $('#cod_usuario').prop('disabled', true);
                
            }
            
        };
        reader.readAsText(file);
    });

}
        