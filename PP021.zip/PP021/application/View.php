<?php

/*
 * -------------------------------------

 * View.php
 * -------------------------------------
 */


class View
{
	private $_controlador;
	private $_js;

	public function __construct(Request $peticion) {
		$this->_controlador = $peticion->getControlador();
		$this->_js = array();
	}


	/*
	 *  Esta funci�n vuelve a cargar la pagina
	 *
	 *
	 */
	public function renderizar($vista, $partial = false)
	{


		$js = array();

		if(count($this->_js)){
			$js = $this->_js;
		}

		$_layoutParams = array(
           
            'js' => $js
		);

		$rutaView = ROOT . 'views' . DS . $this->_controlador . DS . $vista . '.phtml';
		 
		if(is_readable($rutaView)){
			if (!$partial) {
				include_once ROOT . 'views'. DS . 'layout' . DS . DEFAULT_LAYOUT . DS . 'header.phtml';
				include_once $rutaView;
				include_once ROOT . 'views'. DS . 'layout' . DS . DEFAULT_LAYOUT . DS . 'footer.phtml';
			}
			else
			include_once $rutaView;
		}
		else {
			throw new Exception('Error  no se encontro la vista  vista');
		}
	}

	/*
	 *  carga los js  especificos del controlador
	 *
	 */

	public function setJs(array $js)
	{
		if(is_array($js) && count($js)){
			for($i=0; $i < count($js); $i++){
				$this->_js[] = BASE_URL . 'views'.DS . $this->_controlador .DS. 'js'.DS . $js[$i] . '.js';
			}
		} else {
			throw new Exception('Error de js');
		}
	}

}

?>
