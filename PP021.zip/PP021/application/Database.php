<?php

/*
 * -------------------------------------
 * Database.php
 * -------------------------------------
 */

/*class Database extends mysqli
{
	public $_paginacion = array();


	public function __construct() {
		parent::__construct(DB_HOST,DB_USER,DB_PASS,DB_NAME);
		 
	}


}*/


class Database extends PDO
{
	public $_paginacion = array();


	/*public function __construct() {
        
    }*/

    public function __construct($opcion) {
    	
    	

        if($opcion=='db1'){
            parent::__construct('sqlsrv:Server=DBMIR02;Database=db_6E2000','app_ilima','ilima2018');
            parent::setAttribute(parent::ATTR_ERRMODE, parent::ERRMODE_EXCEPTION);  
        }

    	// if($opcion=='db2'){
    	// 	parent::__construct('sqlsrv:Server=DBMIR02;Database=DB_SUNAT','','');
     //    	parent::setAttribute(parent::ATTR_ERRMODE, parent::ERRMODE_EXCEPTION);	
    	// }

        

       


        
       	
      
    }

   

	
}

?>
