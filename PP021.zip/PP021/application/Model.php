<?php

/*
 * -------------------------------------

 * Model.php
 * -------------------------------------
 */


class Model
{
	protected $_db1;
	protected $_db2;
	protected $_db3;
	protected $_db4;
	protected $_db5;

	public function __construct() {
		$this->_db1 = new Database('db1');
		$this->_db2 = new Database('db2');
		//$this->_db3 = new Database('db3');
		//$this->_db4 = new Database('db4');
		$this->_db5 = new Database('db5');
	}

	

}

?>
