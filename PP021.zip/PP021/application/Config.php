<?php

/*
 * -------------------------------------
 *  Config.php
 * -------------------------------------
 */
 

//define('BASE_URL', 'http://'.$_SERVER['SERVER_NAME'].':8080/framephp/');
define('BASE_URL', 'http://pcu408:8080/Cobraly_1/');
//define('BASE_URL', 'http://alqpclimc6gk:8080/FiscaPRO/');
define('DEFAULT_CONTROLLER', 'index');
define('DEFAULT_METODO', 'index');
define('DEFAULT_LAYOUT', 'default');
 

//variables globales
define('CORREOTI', 'vsantiago@sunat.gob.pe');
define('NOMBREAPLICACION', 'Cobraly');
define('ALIASDESARROLLADOR', 'SUNAT');
define('USUARIOPRUEBA', 'vchacaliazad');
/*define('DB_HOST', 'localhost:3306');
define('DB_USER', 'root');
define('DB_PASS', 'admin');
define('DB_NAME', 'tienda');
define('DB_ENGINE', 'sqlsrv');
define('DB_CHAR', 'utf8');*/

//define('DB_HOST', 'PCR831');
//define('DB_USER', 'fiscapro');
//define('DB_PASS', 'Rosas2020');
//define('DB_NAME', 'DPO');
//define('DB_ENGINE', 'sqlsrv');
?>
