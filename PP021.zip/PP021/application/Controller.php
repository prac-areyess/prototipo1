<?php

/*
 * -------------------------------------

 * Controller.php
 * -------------------------------------
 */


abstract class Controller
{
	protected $_view;

	public function __construct() {
		$this->_view = new View(new Request);
	}

	abstract public function index();

	protected function loadModel($modelo)
	{
		$modelo = $modelo . 'Model';
		$rutaModelo = ROOT . 'models' . DS . $modelo . '.php';

		if(is_readable($rutaModelo)){
			require_once $rutaModelo;
			$modelo = new $modelo;
			return $modelo;
		}
		else {
			throw new Exception('Error no se encontro el modelo');
		}
	}

	protected function getLibrary($libreria)
	{
		$rutaLibreria = ROOT . 'libs' . DS . $libreria . '.php';

		if(is_readable($rutaLibreria)){
			require_once $rutaLibreria;
		}
		else{
			throw new Exception('Error no se encontro la libreria');
		}
	}



	protected function redireccionar($ruta = false)
	{
		if($ruta){
			header('location:' . BASE_URL . $ruta);
			exit;
		}
		else{
			header('location:' . BASE_URL);
			exit;
		}
	}




	

}

?>
