<!DOCTYPE html>
<html>
<head>
   <!-- HTML meta refresh URL redirection -->
   <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
   <meta http-equiv="refresh" 
   content="0; url=http://PCR831:8000/FiscaPRO/">

</head>
<body>
   <p>The page has moved to: 
   <a href="http://PCR831:8000/FiscaPRO/">http://PCR831:8000/FiscaPRO/</a></p>
</body>
</html>