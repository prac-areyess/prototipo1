<?php
class excelController extends Controller {
	
	public function __construct(){
	 parent::__construct();	
	}
	
	public function index(){}
	
	public function creaExcel() {
		date_default_timezone_set ( 'America/Lima' );
		ini_set ( 'memory_limit', '-1' );
		
		// $this->getLibrary('excel/PHPExcel');
		$this->getLibrary ( 'PHPExcel-1.8/Classes/PHPExcel' );
		
		// Se crea el objeto PHPExcel
		$objPHPExcel = new PHPExcel ();
		// Se asignan las propiedades del libro
		$objPHPExcel->getProperties ()->setCreator ( "" )-> // Nombre del autor
		setLastModifiedBy ( "fsanchez" )-> // Ultimo usuario que lo modific�
		setTitle ( "" )-> // Titulo
		setSubject ( "" )-> // Asunto
		setDescription ( "" )-> // Descripci�n
		setKeywords ( "" )-> // Etiquetas
		setCategory ( "" ); // Categorias
		
		$titulosColumnas = array (
				'A1' => 'code',
				'B1' => 'name',
				'C1' =>'price',
				'D1' => 'stock' 
		);
		
		// Se agregan los titulos del reporte
		foreach ( $titulosColumnas as $celda => $datocelda ) {
			$objPHPExcel->setActiveSheetIndex ( 0 )->setCellValue ( $celda, $datocelda ); // Titulo de las columnas
		}
		
				
		
		
		$objModel = $this->loadModel('products');
		$productos = $objModel->getProducts();
		
		$linea = 2;
		
		while($reg=$productos->fetch_object())
		{	
		
						
			$objPHPExcel->setActiveSheetIndex ( 0 )
			->setCellValue ( 'A'.$linea, $reg->productCode )
			->setCellValue ( 'B'.$linea, $reg->productName )
			->setCellValue ( 'C'.$linea, $reg->productLine )
			->setCellValue ( 'D'.$linea, $reg->productScale );
			
			$linea=$linea+1;
		}
			
			
		
		
		
		
		
		
		
		
		for($i = 'A'; $i <= 'Z'; $i ++) {
			$objPHPExcel->setActiveSheetIndex ( 0 )->getColumnDimension ( $i )->setAutoSize ( TRUE );
		}
		
		// Se asigna el nombre a la hoja
		$objPHPExcel->getActiveSheet ()->setTitle ( 'Servicios' );
		
		// Se activa la hoja para que sea la que se muestre cuando el archivo se abre
		$objPHPExcel->setActiveSheetIndex ( 0 );
		
		$objPHPExcel->getActiveSheet ( 0 )->freezePaneByColumnAndRow ( 0, 2 );
		
		// Se manda el archivo al navegador web, con el nombre que se indica, en formato 2007
		header ( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header ( 'Content-Disposition: attachment;filename="Reporte.xlsx"' );
		header ( 'Cache-Control: max-age=0' );
		
		$objWriter = PHPExcel_IOFactory::createWriter ( $objPHPExcel, 'Excel2007' );
		$objWriter->save ( 'php://output' );
		exit ();
	}
	
	public function leeExcel() {
		ini_set ( 'memory_limit', '-1' );
		
		$this->getLibrary ( 'PHPExcel-1.8/Classes/PHPExcel' );
		// lee el archivo cargado
		$objReader = PHPExcel_IOFactory::createReader ( 'Excel2007' );
		$objReader->setReadDataOnly ( true );
		$objPHPExcel = $objReader->load ( dirname ( __DIR__ ) . '/temp/Reporte.xlsx' );
		$objWorksheet = $objPHPExcel->setActiveSheetIndex ( 0 );
		
		$fila_inicio = 1;
		$fil = 0;
		foreach ( $objWorksheet->getRowIterator () as $row ) {
			if ($fil >= $fila_inicio) {
				$cellIterator = $row->getCellIterator ();
				$cellIterator->setIterateOnlyExistingCells ( false );
				$col = 0;
				$data_cell = array ();
				foreach ( $cellIterator as $cell ) {
					$data_cell [$col] = $cell->getCalculatedValue ();
					$col ++;
				}
				//print_r ( $data_cell );
				echo $data_cell[0]." ".$data_cell[1]." ".$data_cell[2]." ".$data_cell[3]."<br>";
			}
			$fil ++;
		}
		echo 'ok';
	}
}
?>