<?php 
class consultaBuzonController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	public function consulta(){

		if(isset($_SESSION['id'])){
					
			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;			
			
			if ($objLayout->validarAccesoOpcion('CONSULTABUZON/CONSULTA',true)){
				
				// cod_usuario = ruc
			    $cod_usuario = '';
			    $idArrayRuc = array();
				$shape = '1';
		    	$title = 'Consulta Buzon Sol';

			    if(isset($_GET['cod_usuario'])){
					$ruc = trim($_GET['cod_usuario']);
				}
				if(isset($_POST['idArrayRuc'])){
					$idArrayRuc = $_POST['idArrayRuc'];
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				$this->_view->cod_usuario = $cod_usuario;
				$this->_view->idArrayRuc = $idArrayRuc;
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('consulta')); 
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}




    //getDatosBuzonSol
	public function getdatosBuzon(){

		if(isset($_SESSION['id'])){
			
			// cod_usuario = ruc
			$cod_usuario = '';
			$idArrayRuc = array();

	        //cod_usuario=ruc
			if(isset($_POST['cod_usuario'])){
				$cod_usuario = trim($_POST['cod_usuario']);
			}
            
			if(isset($_POST['idArrayRuc'])){
				$idArrayRuc = $_POST['idArrayRuc'];
			}

			
			$objModel = $this->loadModel('consultaBuzon');
			$result = $objModel->getdatosBuzon($cod_usuario,$idArrayRuc);

			$arregloFinal = array();
			$arreglo['data'] = array();
			$encontrado =false;

			$resultArray = array(); 
			$resultArrayRow = array(); 

			/*while ($row = $result->fetch()){
				$arreglo['data'][] = $row;

			}*/


			
			foreach ($result as $row ) {	
				$resultArrayRow['ruc']=$row['ruc'];
				$resultArrayRow['razon_social']=$row['razon_social'];
				array_push($resultArray,$resultArrayRow);
			}


			//echo $resultArray[1]['ruc'] ;
			//echo 'FinConvert ';


			if ($cod_usuario=='*'){
				//iterar plano usuario
				if (count($idArrayRuc)>0){

		

					foreach($idArrayRuc as $rucPlano){
						//$rucPlano = '5664'
			 			//echo $rucPlano;
			 			$encontrado = false;
			 			//echo 'termino rucPlano'

			 			//echo 'CA';

			 			//echo count($idArrayRuc);


			 			//iterar resultados sql
						//$result->
						//ruc  |  razonscoail  | estado
						//1234  | abc          | 1       -> $row
						//9874  | xyz          | 1        -> $row

						
						//echo 'Cuenta base';

			 			//echo count($result);

			 			//echo 'FF';


						foreach ($resultArray as $row) {	
							



						    
							//$row -> 
								//ruc  |  razonscoail  | estado
								//1234  | abc          | 1

						    //$arreglo['data'][] = $row;

						    $rucBase = $row['ruc']; //1234
						    $razon_social = $row['razon_social']; 
						    //echo ' I ';


						    //echo $rucPlano;
						    //echo ' - ';

						    //echo $rucBase;





						    if ($rucPlano == $rucBase){

								//echo 'ESTAA  ';

								$arregloFinal['ruc'] = $rucPlano;							 
								$arregloFinal['razon_social'] = $razon_social;
								$arregloFinal['estado'] ='CON BUZON';


								$encontrado = true;


							}

							
						}


						//echo $rucPlano;


						if ($encontrado == false){

							//echo 'NOES  ';

								$arregloFinal['ruc'] = $rucPlano;
								$arregloFinal['razon_social'] = '';
								$arregloFinal['estado'] ='SIN BUZON';


						}

						


						//echo $rucPlano;

						//echo $arregloFinal[0][1];
						//	echo '  FINNNN';


						array_push($arreglo['data'],$arregloFinal);
						$arregloFinal = array();

			 		}

					
				}

			}else{
				if($cod_usuario<>''){

					$rucPlano = $cod_usuario;


					foreach ($resultArray as $row) {	
							
					    
						//$row -> 
							//ruc  |  razonscoail  | estado
							//1234  | abc          | 1

					    //$arreglo['data'][] = $row;

					    $rucBase = $row['ruc']; //1234
					    $razon_social = $row['razon_social']; 
					    //echo ' I ';


					    //echo $rucPlano;
					    //echo ' - ';

					    //echo $rucBase;





					    if ($rucPlano == $rucBase){

							//echo 'ESTAA  ';

							$arregloFinal['ruc'] = $rucPlano;							 
							$arregloFinal['razon_social'] = $razon_social;
							$arregloFinal['estado'] ='CON BUZON';


							$encontrado = true;


						}

						
					}

					if ($encontrado == false){

						//echo 'NOES  ';

						$arregloFinal['ruc'] = $rucPlano;
						$arregloFinal['razon_social'] = '';
						$arregloFinal['estado'] ='SIN BUZON';


					}

					


					//echo $rucPlano;

					//echo $arregloFinal[0][1];
					//	echo '  FINNNN';


					array_push($arreglo['data'],$arregloFinal);
					$arregloFinal = array();


				}
			}


			


		

			echo json_encode($arreglo);
			
			    





			//

			//echo json_encode($arreglo);
		}
	}



	
}

?>