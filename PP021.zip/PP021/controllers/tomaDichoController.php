<?php 

require_once('.\libs\TCPDF-master\tcpdf.php');

class tomaDichoController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	
	public function consulta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('TOMADICHO/CONSULTA',true)){

			    $idTomaDicho = '';
			    $idTomaDichoArray = array();
				$rc = '';
			    $rucContribuyente = '';
			    $codTercero = '';
			    $rucTercero = '';
			    $fecTomaDichoIni = '';
			    $fecTomaDichoFin = '';
			    $resultado = '';
			    $regResponsableDiligencia = '';
			    $codAuxRc = '';
			    $codEjeRc = '';
			    $fecRegIni = '';
				$fecRegFin = '';
			    $estado = '';
			    $estadoArray = array();
			    $title = 'Consulta General de Toma de Dichos';
			    $shape = '1';

			   	if(isset($_POST['idTomaDicho'])){
					$idTomaDicho = trim($_POST['idTomaDicho']);
				}
				if(isset($_POST['idTomaDichoArray'])){
					$idTomaDichoArray = $_POST['idTomaDichoArray'];
				}
				if(isset($_POST['rc'])){
					$rc = trim($_POST['rc']);
				}
				if(isset($_POST['rucContribuyente'])){
					$rucContribuyente = trim($_POST['rucContribuyente']);
				}
				if(isset($_POST['codTercero'])){
					$codTercero = trim($_POST['codTercero']);
				}
				if(isset($_POST['rucTercero'])){
					$rucTercero = trim($_POST['rucTercero']);
				}
				if(isset($_POST['fecTomaDichoIni'])){
					$fecTomaDichoIni = trim($_POST['fecTomaDichoIni']);
				}
				if(isset($_POST['fecTomaDichoFin'])){
					$fecTomaDichoFin = trim($_POST['fecTomaDichoFin']);
				}
				if(isset($_POST['resultado'])){
					$resultado = trim($_POST['resultado']);
				}
				if(isset($_POST['regResponsableDiligencia'])){
					$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
				}
				if(isset($_POST['codAuxRc'])){
					$codAuxRc = trim($_POST['codAuxRc']);
				}
				if(isset($_POST['codEjeRc'])){
					$codEjeRc = trim($_POST['codEjeRc']);
				}
				if(isset($_POST['fecRegIni'])){
					$fecRegIni = trim($_POST['fecRegIni']);
				}
				if(isset($_POST['fecRegFin'])){
					$fecRegFin = trim($_POST['fecRegFin']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}
				if(isset($_POST['estadoArray'])){
					$estadoArray = $_POST['estadoArray'];
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}


				$this->_view->idTomaDicho = $idTomaDicho;
				$this->_view->rc = $rc;
				$this->_view->rucContribuyente = $rucContribuyente;
				$this->_view->codTercero = $codTercero;
				$this->_view->rucTercero = $rucTercero;
				$this->_view->fecTomaDichoIni = $fecTomaDichoIni;
				$this->_view->fecTomaDichoFin = $fecTomaDichoFin;
				$this->_view->resultado = $resultado;
				$this->_view->regResponsableDiligencia = $regResponsableDiligencia;
				$this->_view->codAuxRc = $codAuxRc;
				$this->_view->codEjeRc = $codEjeRc;
				$this->_view->fecRegIni = $fecRegIni;
				$this->_view->fecRegFin = $fecRegFin;
				$this->_view->estado = $estado;
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('consultaV20220729')); 
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function registro(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('TOMADICHO/REGISTRO',true)){
					
				$_POST['shape']='2';
				$_POST['title']='Registro de Toma de Dichos';

				$this->consulta();

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function misAsignados(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('TOMADICHO/MISASIGNADOS',true)){
					
				$_POST['estado']='01';
				$_POST['regResponsableDiligencia']=$_SESSION['id'];
				$_POST['shape']='3';
				$_POST['title']='Mis Asignados Pendientes';

				$this->consulta();

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function diligencia(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('TOMADICHO/DILIGENCIA',true)){

			    $idDiligencia = '';
			    $idTomaDicho = '';
			    $fecDiligenciaIni = '';
				$fecDiligenciaFin = '';
				$resultado = '';
				$mtoInformado = '';
				$nombreEncargadoTer = '';
				$telefonoEncargadoTer = '';
				$correoEncargadoTer = '';
				$regResponsableDiligencia = '';
				$estado = '';
				$shape = '1';
			    $title = 'Consulta General de Diligencias';

			    if(isset($_POST['idDiligencia'])){
					$idDiligencia = trim($_POST['idDiligencia']);
				}
				if(isset($_POST['idTomaDicho'])){
					$idTomaDicho = trim($_POST['idTomaDicho']);
				}
				if(isset($_POST['fecDiligenciaIni'])){
					$fecDiligenciaIni = trim($_POST['fecDiligenciaIni']);
				}
				if(isset($_POST['fecDiligenciaFin'])){
					$fecDiligenciaFin = trim($_POST['fecDiligenciaFin']);
				}
				if(isset($_POST['resultado'])){
					$resultado = trim($_POST['resultado']);
				}
				if(isset($_POST['mtoInformado'])){
					$mtoInformado = trim($_POST['mtoInformado']);
				}
				if(isset($_POST['nombreEncargadoTer'])){
					$nombreEncargadoTer = trim($_POST['nombreEncargadoTer']);
				}
				if(isset($_POST['telefonoEncargadoTer'])){
					$telefonoEncargadoTer = trim($_POST['telefonoEncargadoTer']);
				}
				if(isset($_POST['correoEncargadoTer'])){
					$correoEncargadoTer = trim($_POST['correoEncargadoTer']);
				}
				if(isset($_POST['regResponsableDiligencia'])){
					$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}	


				$this->_view->idDiligencia = $idDiligencia;
				$this->_view->idTomaDicho = $idTomaDicho;
				$this->_view->fecDiligenciaIni = $fecDiligenciaIni;
				$this->_view->fecDiligenciaFin = $fecDiligenciaFin;
				$this->_view->resultado = $resultado;
				$this->_view->mtoInformado = $mtoInformado;
				$this->_view->nombreEncargadoTer = $nombreEncargadoTer;
				$this->_view->telefonoEncargadoTer = $telefonoEncargadoTer;
				$this->_view->correoEncargadoTer = $correoEncargadoTer;
				$this->_view->regResponsableDiligencia = $regResponsableDiligencia;
				$this->_view->estado = $estado;
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('diligenciaV20220729')); 
				$this->_view->renderizar('diligencia');
				
			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function estadistica1(){

		if(isset($_SESSION['id'])){
			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;
			
			$this->_view->setJs(array('estadistica1')); //carga un js en la vista
			$this->_view->renderizar('estadistica1');

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function generarId(){

		$idTomaDicho = '';

		$objModel = $this->loadModel('tomaDicho');
		$result = $objModel->generarId();

		$result->nextRowset();
		
		if ($result->rowCount()){
				foreach ($result as $row) {	
					$idTomaDicho=$row['idTomaDicho'];
				}
		}
		return $idTomaDicho;
	}

	public function generarIdDiligencia(){

		$idDiligencia = '';

		$objModel = $this->loadModel('tomaDicho');
		$result = $objModel->generarIdDiligencia();

		$result->nextRowset();
		
		if ($result->rowCount()){
				foreach ($result as $row) {	
					$idDiligencia=$row['idDiligencia'];
				}
		}
		return $idDiligencia;
	}

	public function getTomaDichos(){

		if(isset($_SESSION['id'])){
					
			$idTomaDicho = '';
			$idTomaDichoArray = array();
			$rc = '';
		    $rucContribuyente = '';
		    $codTercero = '';
		    $rucTercero = '';
		    $fecTomaDichoIni = '';
		    $fecTomaDichoFin = '';
		    $resultado = '';
		    $regResponsableDiligencia = '';
		    $codAuxRc = '';
		    $codEjeRc = '';
		    $fecRegIni = '';
			$fecRegFin = '';
		    $estado = '';
		    $estadoArray = array();

		   	if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['idTomaDichoArray'])){
				$idTomaDichoArray = $_POST['idTomaDichoArray'];
			}
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['rucContribuyente'])){
				$rucContribuyente = trim($_POST['rucContribuyente']);
			}
			if(isset($_POST['codTercero'])){
				$codTercero = trim($_POST['codTercero']);
			}
			if(isset($_POST['rucTercero'])){
				$rucTercero = trim($_POST['rucTercero']);
			}
			if(isset($_POST['fecTomaDichoIni'])){
				$fecTomaDichoIni = trim($_POST['fecTomaDichoIni']);
			}
			if(isset($_POST['fecTomaDichoFin'])){
				$fecTomaDichoFin = trim($_POST['fecTomaDichoFin']);
			}
			if(isset($_POST['resultado'])){
				$resultado = trim($_POST['resultado']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}
			if(isset($_POST['codEjeRc'])){
				$codEjeRc = trim($_POST['codEjeRc']);
			}
			if(isset($_POST['fecRegIni'])){
				$fecRegIni = trim($_POST['fecRegIni']);
			}
			if(isset($_POST['fecRegFin'])){
				$fecRegFin = trim($_POST['fecRegFin']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['estadoArray'])){
				$estadoArray = $_POST['estadoArray'];
			}
			
			if($estado==''){
				$estado = '*';
				array_push($estadoArray, '01');
				array_push($estadoArray, '02');
			}

			$objModel = $this->loadModel('tomaDicho');
			$result = $objModel->getTomaDichos($idTomaDicho,$idTomaDichoArray,$rc,$rucContribuyente,$codTercero,$rucTercero,$fecTomaDichoIni,$fecTomaDichoFin,$resultado,$regResponsableDiligencia,$codAuxRc,$codEjeRc,$fecRegIni,$fecRegFin,$estado,$estadoArray);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function getDiligencias(){

		if(isset($_SESSION['id'])){
			
			$idDiligencia = '';
			$idTomaDicho = '';
			$fecDiligenciaIni = '';
			$fecDiligenciaFin = '';
			$resultado = '';
			$regResponsableDiligencia = '';
			$fecRegIni = '';
			$fecRegFin = '';
			$estado = '';
			$estadoArray = array();

		    if(isset($_POST['idDiligencia'])){
				$idDiligencia = trim($_POST['idDiligencia']);
			}
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['fecDiligenciaIni'])){
				$fecDiligenciaIni = trim($_POST['fecDiligenciaIni']);
			}
			if(isset($_POST['fecDiligenciaFin'])){
				$fecDiligenciaFin = trim($_POST['fecDiligenciaFin']);
			}
			if(isset($_POST['resultado'])){
				$resultado = trim($_POST['resultado']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}
			if(isset($_POST['fecRegIni'])){
				$fecRegIni = trim($_POST['fecRegIni']);
			}
			if(isset($_POST['fecRegFin'])){
				$fecRegFin = trim($_POST['fecRegFin']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['estadoArray'])){
				$estadoArray = trim($_POST['estadoArray']);
			}

			if($estado==''){
				$estado = '*';
				array_push($estadoArray, '01');
			}
			
			$objModel = $this->loadModel('tomaDicho');
			$result = $objModel->getDiligencias($idDiligencia,$idTomaDicho,$fecDiligenciaIni,$fecDiligenciaFin,$resultado,$regResponsableDiligencia,$fecRegIni,$fecRegFin,$estado,$estadoArray);

			

			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);
		}	
	}

	public function insTomaDicho(){

		if(isset($_SESSION['id'])){
			
			$idTomaDicho=$this->generarId();			
			$rc = '';
			$rucContribuyente = '';
			$codTercero = '';		
			$regResponsableDiligencia = '';	
			$usuReg = $_SESSION['id'];
			$estado = '01';
			

			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['rucContribuyente'])){
				$rucContribuyente = trim($_POST['rucContribuyente']);
			}
			if(isset($_POST['codTercero'])){
				$codTercero = trim($_POST['codTercero']);
			}	
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}


			$objModel = $this->loadModel('tomaDicho');
			$objModel->insTomaDicho($idTomaDicho,$rc,$codTercero,$regResponsableDiligencia,$usuReg,$estado);


			
			$_POST = array();
			$_POST['idTomaDicho']=$idTomaDicho;
			$this->getTomaDichos();

		}
	}

	public function insMasTomaDicho(){

		if(isset($_SESSION['id'])){

			$datosArray = array();
			$idTomaDichoArray = array();

			if(isset($_POST['datosArray'])){
				$datosArray = $_POST['datosArray'];
			}	

			if (count($datosArray)>0){
				foreach($datosArray as $item)
		 		{
		 			$idTomaDicho=$this->generarId();
		 			$rc = $item[0];
		 			$codTercero = $item[1];	
		 			$regResponsableDiligencia = $item[2];	
		 			$usuReg = $_SESSION['id'];
					$estado = '01';

					$objModel = $this->loadModel('tomaDicho');
					$objModel->insTomaDicho($idTomaDicho,$rc,$codTercero,$regResponsableDiligencia,$usuReg,$estado);

					array_push($idTomaDichoArray, $idTomaDicho);
					
		 		}
			}
			

			$_POST = array();
			$_POST['idTomaDicho']='*';
			$_POST['idTomaDichoArray']=$idTomaDichoArray;
			$this->getTomaDichos();

		}
	}

	public function insDiligencia(){

		if(isset($_SESSION['id'])){
			
			$idDiligencia=$this->generarIdDiligencia();			
			$idTomaDicho = '';
			$fecDiligencia = '';
			$resultado = '';
			$subResultado = '';
			$observacion = '';
			$mtoInformado = '';
			$nombreEncargadoTer = '';
			$telefonoEncargadoTer = '';
			$correoEncargadoTer = '';
			$regResponsableDiligencia = '';
			$usuReg = $_SESSION['id'];
			$estado = '01';
			

			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['fecDiligencia'])){
				$fecDiligencia = trim($_POST['fecDiligencia']);
			}
			if(isset($_POST['resultado'])){
				$resultado = trim($_POST['resultado']);
			}	
			if(isset($_POST['subResultado'])){
				$subResultado = trim($_POST['subResultado']);
			}	
			if(isset($_POST['observacion'])){
				$observacion = trim($_POST['observacion']);
			}	
			if(isset($_POST['mtoInformado'])){
				$mtoInformado = trim($_POST['mtoInformado']);
			}	
			if(isset($_POST['nombreEncargadoTer'])){
				$nombreEncargadoTer = trim($_POST['nombreEncargadoTer']);
			}	
			if(isset($_POST['telefonoEncargadoTer'])){
				$telefonoEncargadoTer = trim($_POST['telefonoEncargadoTer']);
			}	
			if(isset($_POST['correoEncargadoTer'])){
				$correoEncargadoTer = trim($_POST['correoEncargadoTer']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}	
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}

			if ($resultado<>'4'){
				$mtoInformado='0';
			}

			$objModel = $this->loadModel('tomaDicho');
			$objModel->insDiligencia($idDiligencia,$idTomaDicho,$fecDiligencia,$resultado,$subResultado,$observacion,$mtoInformado,$nombreEncargadoTer,$telefonoEncargadoTer,$correoEncargadoTer,$regResponsableDiligencia,$usuReg,$estado);

			$objModel->conTomaDicho($idTomaDicho,$usuReg);

			$_POST = array();
			$_POST['idDiligencia']=$idDiligencia;
			$this->getDiligencias();			

		}		
	}

	public function updTomaDicho(){

		if(isset($_SESSION['id'])){

			$idTomaDicho = '';
			$rc = '';
			$codTercero = '';
			$regResponsableDiligencia = '';
			$usuMod = $_SESSION['id'];
			$estado = '';

		
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['codTercero'])){
				$codTercero = trim($_POST['codTercero']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}
			if(isset($_POST['usuMod'])){
			 	$usuMod = trim($_POST['usuMod']);
			}
			if(isset($_POST['estado'])){
			 	$estado = trim($_POST['estado']);
			}
			

			$objModel = $this->loadModel('tomaDicho');
			$objModel->updTomaDicho($idTomaDicho,$rc,$codTercero,$regResponsableDiligencia,$usuMod,$estado);

			
			$_POST = array();
			$_POST['idTomaDicho']=$idTomaDicho;
			$this->getTomaDichos();
			

		}
	}

	public function updDiligencia(){

		if(isset($_SESSION['id'])){

			$idDiligencia = '';		
			$idTomaDicho = '';
			$fecDiligencia = '';
			$resultado = '';
			$subResultado = '';
			$observacion = '';
			$mtoInformado = '';
			$nombreEncargadoTer = '';
			$telefonoEncargadoTer = '';
			$correoEncargadoTer = '';
			$regResponsableDiligencia = '';
			$usuMod = $_SESSION['id'];
			$estado = '01';

		
			if(isset($_POST['idDiligencia'])){
				$idDiligencia = trim($_POST['idDiligencia']);
			}
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['fecDiligencia'])){
				$fecDiligencia = trim($_POST['fecDiligencia']);
			}
			if(isset($_POST['resultado'])){
				$resultado = trim($_POST['resultado']);
			}	
			if(isset($_POST['subResultado'])){
				$subResultado = trim($_POST['subResultado']);
			}	
			if(isset($_POST['observacion'])){
				$observacion = trim($_POST['observacion']);
			}	
			if(isset($_POST['mtoInformado'])){
				$mtoInformado = trim($_POST['mtoInformado']);
			}	
			if(isset($_POST['nombreEncargadoTer'])){
				$nombreEncargadoTer = trim($_POST['nombreEncargadoTer']);
			}	
			if(isset($_POST['telefonoEncargadoTer'])){
				$telefonoEncargadoTer = trim($_POST['telefonoEncargadoTer']);
			}	
			if(isset($_POST['correoEncargadoTer'])){
				$correoEncargadoTer = trim($_POST['correoEncargadoTer']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}	

			$objModel = $this->loadModel('tomaDicho');
			$objModel->updDiligencia($idDiligencia,$idTomaDicho,$fecDiligencia,$resultado,$subResultado,$observacion,$mtoInformado,$nombreEncargadoTer,$telefonoEncargadoTer,$correoEncargadoTer,$regResponsableDiligencia,$usuMod,$estado);

			$objModel->conTomaDicho($idTomaDicho,$usuMod);

			$_POST = array();
			$_POST['idDiligencia']=$idDiligencia;
			$this->getDiligencias();

		}
	}

	public function delTomaDicho(){

		if(isset($_SESSION['id'])){

			$idTomaDicho = '';
		
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = $_POST['idTomaDicho'];
			}

			$objModel = $this->loadModel('tomaDicho');
			$objModel->delTomaDicho($idTomaDicho);


			$_POST = array();
			$_POST['idTomaDicho']=$idTomaDicho;
			$_POST['estado']='DE';
			$this->getTomaDichos();


		}
	}

	public function delDiligencia(){

		if(isset($_SESSION['id'])){

			$idDiligencia = '';
			$idTomaDicho = '';
			
			if(isset($_POST['idDiligencia'])){
				$idDiligencia = $_POST['idDiligencia'];
			}
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = $_POST['idTomaDicho'];
			}

			$objModel = $this->loadModel('tomaDicho');
			$objModel->delDiligencia($idDiligencia);

			$objModel->conTomaDicho($idTomaDicho,$_SESSION['id']);
			
			$_POST = array();
			$_POST['idDiligencia']=$idDiligencia;
			$_POST['estado']='DE';
			$this->getDiligencias();
		}
	}

	public function getDatosRC(){

		if(isset($_SESSION['id'])){

			$rc = '';
	    
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			
			$objModel = $this->loadModel('tomaDicho');
			$result = $objModel->getDatosRC($rc);


			$arreglo['data'] = array();
			

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);

		}
	}

	// public function getExisteRC(){

	// 	if(isset($_SESSION['id'])){

	// 		$rc = '';
	    
	// 		if(isset($_POST['rc'])){
	// 			$rc = trim($_POST['rc']);
	// 		}
			
	// 		$objModel = $this->loadModel('tomaDicho');
	// 		$result = $objModel->getTomaDichos('','',$rc,'','','','','','','','','','','','',array());

	// 		$arreglo['data'] = array();
			

	// 		while ($row = $result->fetch())  {
	// 		    $arreglo['data'][] = $row;
	// 		}

	// 		echo json_encode($arreglo);

	// 	}
	// }

	public function getListaTerceros(){

		if(isset($_SESSION['id'])){

			$rc = '';
	    
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			
			$objModel = $this->loadModel('tomaDicho');
			$result = $objModel->getListaTerceros($rc);


			$arreglo["data"] = array();
			
			
			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		
		}
	}
	
	public function genPdfInd() {
	
		if(isset($_SESSION['id'])){

			$idTomaDicho='';
			if(isset($_GET['idTomaDicho'])){
				$idTomaDicho = trim($_GET['idTomaDicho']);
			}
			

			
			$objModel= $this->loadModel('tomaDicho');			
			$result = $objModel->getTomaDichos($idTomaDicho,array(),'','','','','','','','','','','','','',array());

			
			while ($row = $result->fetch())  {

				$rc = trim($row['rc']);
				$rec = trim($row['rec']);
				$deudor = trim($row['razonSocial']);
				$identificacion = trim($row['numRuc']);
				$domicilio = trim($row['direccion']);
				$descUbigeo = trim($row['descUbigeo'] ?? '');
				if ($descUbigeo !== '') {
					$partesUbigeo = array_map('trim', explode('-', $descUbigeo));
					$partesUbigeo = array_values(array_filter($partesUbigeo, function($item) { return $item !== ''; }));
					$partesUbigeo = array_reverse($partesUbigeo);
					$descUbigeoInvertido = implode(' - ', $partesUbigeo);
					$domicilio = $domicilio !== '' ? $domicilio . ', ' . $descUbigeoInvertido : $descUbigeoInvertido;
				}
				$rucTercero = trim($row['numRucTercero']);
				$terceroRetenedor = trim($row['nomTercero']);
				$rucTerceroDesc = trim($row['rucTerceroDesc']);
				$direccionTercero = trim($row['direccionTercero']);				
				$rucDesc = trim($row['rucDesc']);
				$direccionContribuyente = trim($row['direccionContribuyente']);
				$codAuxRcDesc = trim($row['codAuxRcDesc']);
				$ejeCoactivo = trim($row['ejeCoactivo'] ?? '');
				$regResponsableDiligenciaDesc = trim($row['regResponsableDiligenciaDesc']);

			}

			$deudor = htmlspecialchars($deudor ?? '', ENT_QUOTES, 'UTF-8');
			$identificacion = htmlspecialchars($identificacion ?? '', ENT_QUOTES, 'UTF-8');
			$domicilio = htmlspecialchars($domicilio ?? '', ENT_QUOTES, 'UTF-8');
			$rec = htmlspecialchars($rec ?? '', ENT_QUOTES, 'UTF-8');
			$rucTercero = htmlspecialchars($rucTercero ?? '', ENT_QUOTES, 'UTF-8');
			$terceroRetenedor = htmlspecialchars($terceroRetenedor ?? '', ENT_QUOTES, 'UTF-8');

			$fechaImpresion = date('d-m-Y');  
			//echo "The current date and time are $DateAndTime.";

			//$direccion = mb_strtolower($direccion, 'UTF-8');

			//$direccion = ucwords($direccion);
			

			

			//Obteniendo ruta servidor
			/*$result = $objCarta->getRutaRepositorio();
			$ruta_repositorio="";

			while ($row = $result->fetch()){
			     $ruta_repositorio=$row[0]; 
			}*/

			
			$pdf = new MYPDF('P', PDF_UNIT, 'A4', true, 'UTF-8', false, true);
							
			//$ruta_visto = $ruta_visto."V.jpg";
			//$ruta_visto = str_replace('\\\\', '\\', $ruta_visto);
			//$ruta_visto = '\\PO-7\POD\FIRMAS\19181530V.jpg';

			//$pdf->setRutaVisto1($ruta_visto);
			//$pdf->setEstado($estado);
			//$pdf->setNombreAnual($nombre_anual);
			//$pdf->setNombreDecenio($nombre_decenio);
		
			// set document information
			$pdf->SetCreator(PDF_CREATOR);
			$pdf->SetAuthor('Cobraly');
			$pdf->SetTitle('Acta de Toma de Dicho');
			$pdf->SetSubject('Acta de Toma de Dicho');
			$pdf->SetKeywords('Cobraly');
	
			// remove default header/footer 
			$pdf->setPrintHeader(true); 
			//$pdf->setPrintFooter(true);

			// set auto page breaks
			$pdf->SetAutoPageBreak(TRUE, 10);
		
			// ---------------------------------------------------------

			// set default font subsetting mode
			$pdf->setFontSubsetting(true);

			// Set font
		$pdf->SetFont('helvetica', '', 9, '', true);

		//SetMargins($left,$top,$right = -1,$keepmargins = false)
		$pdf->SetMargins(25, 20, 25, true);
			// Add a page
			$pdf->AddPage('P', 'A4');

			// image path (absoluta, con separadores '/')
			$img = ROOT . 'reportes' . DS . 'carta' . DS . 'Logout5.jpg';
			$img = str_replace('\\', '/', $img);

			// Set some content to print
			$checkbox = "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"display:inline-table; vertical-align:middle; margin-right:0px;\"><tr><td style=\"border:1px solid black; width:12px; height:12px;\">&nbsp;</td></tr></table>";

			// ENCABEZADO DEL ACTA
			$html = "<span style=\"text-align:center;\">\n<b>ACTA DE TOMA DE DICHO</b><br>\n<span style=\"font-size:9px; line-height:1.0;\"><b>MEDIDA DE EMBARGO EN FORMA DE RETENCIÓN</b></span><br>\n</span>\n<br>\n"
				
				// DATOS DEL DEUDOR
				. "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"width:100%;\">\n\t
					<tr><td width=\"24%\"><b>DEUDOR</b></td><td width=\"74%\">:  $deudor
					</td></tr>\n\t<tr><td width=\"24%\"><b>IDENTIFICACIÓN</b></td><td width=\"74%\">:  $identificacion
					</td></tr>\n\t<tr><td width=\"24%\"><b>DOMICILIO</b></td><td width=\"74%\">:  $domicilio
					</td></tr>\n\t<tr><td width=\"24%\"><b>EXPEDIENTE NÚMERO</b></td><td width=\"74%\">:  $rec
					</td></tr>\n\t<tr><td width=\"24%\"><b>EJECUTOR COACTIVO</b></td><td width=\"74%\">:  $ejeCoactivo
					</td></tr>\n\t<tr><td colspan=\"2\" style=\"height:2px;\"></td></tr>\n</table>\n"
				
				// DATOS DEL TERCERO RETENEDOR
				. "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"width:100%; margin-top:0;\">\n\t
				<tr><td width=\"24%\"><b>RUC DEL TERCERO</b></td><td width=\"74%\">:  $rucTercero
				</td></tr>\n\t<tr><td width=\"24%\"><b>TERCERO RETENEDOR</b></td><td width=\"74%\">:  $terceroRetenedor
				</td></tr>\n\t<tr><td colspan=\"2\" style=\"height:2px;\"></td></tr>\n</table>\n<br>\n"
				
				// FECHA Y HORA DEL ACTA
				. "________, _____ de ________ de ______<br><br>\n"
				
				// DESCRIPCIÓN DE LA DILIGENCIA
				. "<span style=\"text-align:justify;\">En la fecha, siendo horas _______, se procede a la toma de dicho del tercero retenedor $terceroRetenedor, en mérito a lo establecido en el artículo 118 del Código Tributario, TUO aprobado por Decreto Supremo N°. 133-2013-EF, y artículo 20 del Reglamento del Procedimiento de Cobranza Coactiva, aprobado por Resolución de Superintendencia N°. 216-2004/SUNAT, bajo apercibimiento de incurrir en la infracción tipificada en el numeral 23) del artículo 177 del Código Tributario, para lo cual el auxiliar coactivo designado procede a ejecutar la diligencia en la ubicación  $direccionTercero, ubicación identificada como __________________________, según el detalle que se señala a continuación:\n</span><br><br>\n"
				
				// DETALLES DE LA DILIGENCIA
				. "<div style=\"margin-left:40px; text-align:justify;\">\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;Número de RC de embargo: ________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fecha de notificación: ___/___/___<br><br>\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;Persona que atiende: ___________________________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DNI: _________________<br><br>\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;Cargo: _______________________________________________________<br><br>\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;Dicho: _______________________________________________________________________________<br><br>\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_____________________________________________________________________________________<br><br>\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_____________________________________________________________________________________<br>\n"
				. "<br><br>\n"
				
				// CHECKBOX DE NEGATIVA
				. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"margin-left:40px; width:98%;\"><tr><td style=\"vertical-align:top; width:16px; padding-right:8px;\">" . $checkbox . "</td><td style=\"text-align:justify; font-size:9px; width:100%;\"><b>SE DEJA CONSTANCIA DE LA NEGATIVA</b> a realizar la diligencia, de acuerdo con lo establecido en </td></tr></table><br>\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;el literal c) del numeral 1) del artículo 20 del Reglamento del Procedimiento de Cobranza Coactiva.<br><br>\n"
				
				// OBSERVACIONES
				. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Observaciones:</b> _______________________________________________________________________<br><br>\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_____________________________________________________________________________________<br><br>\n"
				
				// CIERRE DE LA DILIGENCIA
				. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Terminando la diligencia a las ______ horas del mismo día, suscribiéndose la presente acta en señal de<br>\n"
				. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;conformidad, en dos (2) juegos.<br><br>\n"
				. "<br><br>\n"
				
				// FIRMAS
				. "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"width:100%; margin-top:10px;\">\n"
				. "\t<tr>\n\t\t<td width=\"45%\"><span style=\"display:block; border-bottom:1px solid black;\">&nbsp;</span></td>\n\t\t<td width=\"10%\">&nbsp;</td>\n\t\t<td width=\"45%\"><span style=\"display:block; border-bottom:1px solid black;\">&nbsp;</span></td>\n\t</tr>\n"
				. "\t<tr>\n\t\t<td align=\"center\" width=\"45%\">_______________________________</td>\n\t\t<td width=\"10%\"></td>\n\t\t<td align=\"center\" width=\"45%\">_______________________________</td>\n\t</tr>\n"
				. "\t<tr>\n\t\t<td align=\"center\" width=\"45%\">SUNAT</td>\n\t\t<td width=\"10%\"></td>\n\t\t<td align=\"center\" width=\"45%\">ENTIDAD RETENEDORA</td>\n\t</tr>\n"
				. "\t<tr>\n\t\t<td width=\"45%\" style=\"padding-top: 10px;\">Nombre: ..................................................<br>Registro: ..................................................</td>\n"
				. "\t\t<td width=\"10%\"></td>\n"
				. "\t\t<td width=\"45%\" style=\"padding-top: 10px;\">Nombre: ......................................................<br>DNI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ........................................................<br>Telefono: .....................................................<br>Correo electrónico: ......................................</td>\n"
				. "\t</tr>\n</table>";
			
			// Print text using writeHTMLCell()
			$pdf->writeHTMLCell(160, 0, 25, 32, $html, 0, 1, 0, true, '', true);

			if (ob_get_length()) {
				@ob_end_clean();
			}

			// Emitir PDF
			$pdf->Output($idTomaDicho.'.pdf', 'I');

			// Alternativa para guardar en archivo:
			// $ruta_final = $ruta_repositorio.$id_carta.'.pdf';
			// $ruta_final=addslashes($ruta_final);
			// $pdf->Output($ruta_final, 'F');
				
					
				

		}


	}
}


class MYPDF extends TCPDF {

	private $rutaVisto1;
	private $estado;
	private $nombreAnual;
	private $nombreDecenio;

	protected $last_page_flag = false;

	public function setRutaVisto1($RutaVisto1) {
		$this->rutaVisto1=$RutaVisto1;
	}

	public function setEstado($Estado) {
		$this->estado=$Estado;
	}

	public function setNombreAnual($NombreAnual) {
		$this->nombreAnual=$NombreAnual;
	}

	public function setNombreDecenio($NombreDecenio) {
		$this->nombreDecenio=$NombreDecenio;
	}

	public function Header() {

		// Cabecera al margen
		$img = str_replace('\\', '/', ROOT . 'reportes' . DS . 'carta' . DS . 'Logout5.jpg');
		$html = '
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tr>
				<td width="70%" style="vertical-align:middle; font-size:10px; font-family:helvetica;">
					<strong>I.LIMA</strong><br>
					<strong>COBRANZA COACTIVA</strong>
				</td>
				<td width="30%" align="right">
					<img src="' . $img . '" width="180" height="60" />
				</td>
			</tr>
		</table>';

		$this->writeHTMLCell($w = 0, $h = 0, $x = '', $y = 18, $html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);
	}

	public function Close() {
	    $this->last_page_flag = true;
	    parent::Close();
	}

	public function Footer(){
	    /*if($this->last_page_flag){
	        $footer_html = ''; //HTML for the footer on the last page


	    }
	    else{
	    	if($this->estado == "04" || $this->estado == "05" ){

	    		$footer_html = '
		    	<table cellspacing="0" cellpadding="0" border="0">
					<tr>
						<td align="center">				
							<img src="'.$this->rutaVisto1.'" width="400" height="400">				
						</td>
					</tr>
				</table>'; //HTML for the rest of the pages
	    	}else{
	    		$footer_html = '';
	    	}
	        
	    }

	    

	   	$this->writeHTMLCell($w = 24, $h = 24, $x = 2, $y = 175, $footer_html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);
	   	*/

	    $html = '
    	<table cellspacing="0" cellpadding="0" border="0">
    		
			<tr>
				<td align="center">
					<!--<img src=".\reportes\carta\pie.jpg" width="900" height="60">-->		
				</td>
			</tr>
		</table>';

    	$this->writeHTMLCell($w = 190, $h = 13, $x = 10, $y = 275, $html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);

    	$this->setPageMark();
	}
}

?>