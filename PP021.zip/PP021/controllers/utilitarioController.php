<?php 
class utilitarioController extends Controller{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
	}

	public function convertirPdfPdfa(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('UTILITARIO/CONVERTIRPDFPDFA',true)){

				$title = 'Convertir de PDF a PDF/A';
			    $shape = '1';

			    
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('convertirPdfPdfa'));
				$this->_view->renderizar('convertirPdfPdfa');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function unirPdf(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('UTILITARIO/UNIRPDF',true)){

				$title = 'Unir Archivos PDF';
			    $shape = '1';

			    
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('unirPdf'));
				$this->_view->renderizar('unirPdf');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function generarZipSine(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('UTILITARIO/GENERARZIPSINE',true)){

				$title = 'Generar Arhivo Zip Sine';
			    $shape = '1';

			    
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('generarZipSine'));
				$this->_view->renderizar('generarZipSine');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}



	public function convertirPdfPdfaAccion(){

		if(isset($_SESSION['id'])){
		
			$id_dependencia = '';
			
			if(isset($_SESSION['id_dependencia'])){
				$id_dependencia = $_SESSION['id_dependencia'];
			}
						

			$objAplicacion = $this->loadModel('aplicacion');			
			$result = $objAplicacion->getRutasDependencia('000_001',$id_dependencia,'','',array());
			
			$rutaTemporal='';

			while ($row = $result->fetch()){
			     $rutaTemporal=$row['ruta']; 
			}

			$nombreCarpeta=time();

			//creando la carpeta si no existe
			if (is_dir($rutaTemporal.$nombreCarpeta)==false){
				mkdir($rutaTemporal.$nombreCarpeta);
				mkdir($rutaTemporal.$nombreCarpeta.'\\pdfConvertidos');
			}
			else{
				rmdir($rutaTemporal.$nombreCarpeta);
				rmdir($rutaTemporal.$nombreCarpeta.'\\pdfConvertidos');
			}


			$pfdsArray = array();
			
			foreach($_FILES["archivos"]['tmp_name'] as $key => $tmp_name)
			{
				//condicional si el fuchero existe
				if($_FILES["archivos"]["name"][$key]) {
					// Nombres de archivos de temporales
					$archivonombre = $_FILES["archivos"]["name"][$key]; 
					$origen = $_FILES["archivos"]["tmp_name"][$key]; 					
									
					$dir=opendir($rutaTemporal.$nombreCarpeta."\\");
					$destino = $rutaTemporal.$nombreCarpeta."\\".$archivonombre; 
					
					if(move_uploaded_file($origen, $destino)) {	
						array_push($pfdsArray, $archivonombre);
					}else {	
						echo "Se ha producido un error, por favor revise los archivos e intentelo de nuevo.<br>";
					}
					closedir($dir); //Cerramos la conexion con la carpeta destino
				}
			}

			sort($pfdsArray);

			if (count($pfdsArray)>0){

				if (count($pfdsArray)==1){

					foreach($pfdsArray as $pdfHijo)
			 		{
			 			
			 			$inputFile = $rutaTemporal.$nombreCarpeta.'\\'.$pdfHijo;
			 			$outputFile = $rutaTemporal.$nombreCarpeta.'\\pdfConvertidos\\pdfa_'.$pdfHijo;

			 			$cmd = 'gswin64c -dPDFA -dBATCH -dNOPAUSE -dPDFACompatibilityPolicy=1  -sDEVICE=pdfwrite -sOutputFile="'.$outputFile.'" "'.$inputFile.'"';

			 			
						exec($cmd, $output, $return);


						$fileDescarga= $outputFile;
					
						if(file_exists($fileDescarga)){        
							$this->addContador2();                
			                header('Content-Description: File Transfer');
							header("Content-Type: application/pdf");
							header('Content-Disposition: attachment; filename="'.basename($fileDescarga).'"');
							header('Expires: 0');
							header('Cache-Control: must-revalidate');
							header('Pragma: public');
							header('Content-Length: ' . filesize($fileDescarga));
							ob_clean();
							readfile($fileDescarga);
		                	//exit;               
		            	}

					}
				}


				if (count($pfdsArray)>1){

					foreach($pfdsArray as $pdfHijo)
			 		{
			 			
			 			$inputFile = $rutaTemporal.$nombreCarpeta.'\\'.$pdfHijo;
			 			$outputFile = $rutaTemporal.$nombreCarpeta.'\\pdfConvertidos\\pdfa_'.$pdfHijo;

			 			$cmd = 'gswin64c -dPDFA -dBATCH -dNOPAUSE -dPDFACompatibilityPolicy=1  -sDEVICE=pdfwrite -sOutputFile="'.$outputFile.'" "'.$inputFile.'"';

			 			
						exec($cmd, $output, $return);

					}

				
					$cmd = "7z a ".$rutaTemporal.$nombreCarpeta."\\pdfConvertidos.zip ".$rutaTemporal.$nombreCarpeta."\\pdfConvertidos";

					exec($cmd, $output, $return);
				

					$fileDescarga= $rutaTemporal.$nombreCarpeta."\\pdfConvertidos.zip";
					
					if(file_exists($fileDescarga)){  
						$this->addContador2();                      
		                header('Content-Description: File Transfer');
						header("Content-Type: application/pdf");
						header('Content-Disposition: attachment; filename="'.basename($fileDescarga).'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate');
						header('Pragma: public');
						header('Content-Length: ' . filesize($fileDescarga));
						ob_clean();
						readfile($fileDescarga);
	                	//exit;               
	            	}
				}
			}
		}
	}

	public function unirPdfAccion(){

		if(isset($_SESSION['id'])){
					
			$id_dependencia = '';			

			if(isset($_SESSION['id_dependencia'])){
				$id_dependencia = $_SESSION['id_dependencia'];
			}
						
			//Obteniendo ruta temporal servidor
			$objAplicacion = $this->loadModel('aplicacion');			
			$result = $objAplicacion->getRutasDependencia('000_001',$id_dependencia,'','',array());
			
			$rutaTemporal='';

			while ($row = $result->fetch()){
			     $rutaTemporal=$row['ruta']; 
			}

			//creando carpeta
			$nombreCarpeta=time();

			//creando la carpeta si no existe
			if (is_dir($rutaTemporal.$nombreCarpeta)==false){
				mkdir($rutaTemporal.$nombreCarpeta);
			}
			else{
				rmdir($rutaTemporal.$nombreCarpeta);
			}

			
			$pfdsArray = array();
			
			foreach($_FILES["archivos"]['tmp_name'] as $key => $tmp_name)
			{
				//condicional si el fuchero existe
				if($_FILES["archivos"]["name"][$key]) {
					// Nombres de archivos de temporales
					$archivoNombre = $_FILES["archivos"]["name"][$key]; 
					$origen = $_FILES["archivos"]["tmp_name"][$key]; 					
									

					$dir=opendir($rutaTemporal.$nombreCarpeta."\\");
					$destino = $rutaTemporal.$nombreCarpeta."\\".$archivoNombre; 
					
					if(move_uploaded_file($origen, $destino)) {	
						array_push($pfdsArray, $archivoNombre);
					}else {	
						echo "Se ha producido un error, por favor revise los archivos e intentelo de nuevo.<br>";
					}
					closedir($dir); //Cerramos la conexion con la carpeta destino
				}
			}
			

			sort($pfdsArray);

			$pdfsHijos='';

			if (count($pfdsArray)>0){

				foreach($pfdsArray as $pdfHijo){
		 			
		 			$pdfsHijos=$pdfsHijos.' "'.$rutaTemporal.$nombreCarpeta."\\".$pdfHijo.'"';

				}


				$inputFile = $pdfsHijos;
	 			$outputFile = $rutaTemporal.$nombreCarpeta.'\\PDF_Unido.pdf';


	 			$cmd = 'gswin64c -dPDFA -dBATCH -dNOPAUSE -dPDFACompatibilityPolicy=1  -sDEVICE=pdfwrite -sOutputFile="'.$outputFile.'" '.$inputFile;
	 			
				exec($cmd, $output, $return);


				$fileDescarga= $outputFile;
			
				if(file_exists($fileDescarga)){  
					$this->addContador1();           
	                header('Content-Description: File Transfer');
					header("Content-Type: application/pdf");
					header('Content-Disposition: attachment; filename="'.basename($fileDescarga).'"');
					header('Expires: 0');
					header('Cache-Control: must-revalidate');
					header('Pragma: public');
					header('Content-Length: ' . filesize($fileDescarga));
					ob_clean();
					readfile($fileDescarga);
                	//exit;               
            	}
				
			}

		}
	}

	public function generarZipSineAccion(){

		if(isset($_SESSION['id'])){
					
			$id_dependencia = '';			
			$tipoGeneracion = '';
			
			if(isset($_SESSION['id_dependencia'])){
				$id_dependencia = $_SESSION['id_dependencia'];
			}
			if(isset($_POST['tipoGeneracion'])){
				$tipoGeneracion = trim($_POST['tipoGeneracion']);
			}

			//Obteniendo ruta temporal servidor
			$objAplicacion = $this->loadModel('aplicacion');			
			$result = $objAplicacion->getRutasDependencia('000_001',$id_dependencia,'','',array());
			
			$rutaTemporal='';

			while ($row = $result->fetch()){
			     $rutaTemporal=$row['ruta']; 
			}



			if($tipoGeneracion=='01'){

				//creando carpeta
				$nombreCarpeta='ZIP'.time();

				//creando la carpeta si no existe
				if (is_dir($rutaTemporal.$nombreCarpeta)==false){
					mkdir($rutaTemporal.$nombreCarpeta);
				}
				else{
					rmdir($rutaTemporal.$nombreCarpeta);
				}

				$pfdsArray = array();
				
				foreach($_FILES["archivos"]['tmp_name'] as $key => $tmp_name)
				{
					//condicional si el fuchero existe
					if($_FILES["archivos"]["name"][$key]) {
						// Nombres de archivos de temporales
						$archivoNombre = $_FILES["archivos"]["name"][$key]; 
						$origen = $_FILES["archivos"]["tmp_name"][$key]; 					
										

						$dir=opendir($rutaTemporal.$nombreCarpeta);
						$destino = $rutaTemporal.$nombreCarpeta.'\\'.$archivoNombre; 
						
						if(move_uploaded_file($origen, $destino)) {	
							array_push($pfdsArray, $archivoNombre);
						}else {	
							echo 'Se ha producido un error, por favor revise los archivos e intentelo de nuevo.<br>';
						}
						closedir($dir); //Cerramos la conexion con la carpeta destino
					}
				}
				

				sort($pfdsArray);

				$pdfsHijos='';


				if (count($pfdsArray)>0){

					
					//creando archivo files.txt
					$file = fopen($rutaTemporal.$nombreCarpeta.'\\'.'files.txt','w');
					$a = 0;
					foreach($pfdsArray as $pdfHijo){

						$a++;
						if ($a <> count($pfdsArray)){
							fwrite($file,str_replace('_', '|',substr($pdfHijo, 0 , strlen($pdfHijo) - 4)).PHP_EOL);
						}else{
							fwrite($file,str_replace('_', '|',substr($pdfHijo, 0 , strlen($pdfHijo) - 4)));
						}
						
			 			// $pdfsHijos=$pdfsHijos.' "'.$rutaTemporal.$nombreCarpeta."\\".$pdfHijo.'"';

					}

					fclose($file);

					// $inputFile = $pdfsHijos;
		 			// $outputFile = $rutaTemporal.$nombreCarpeta.'\\PDF_Unido.pdf';


		 			// $cmd = 'gswin64c -dPDFA -dBATCH -dNOPAUSE -dPDFACompatibilityPolicy=1  -sDEVICE=pdfwrite -sOutputFile="'.$outputFile.'" '.$inputFile;
		 			
		 			$cmd = "7z a ".$rutaTemporal.$nombreCarpeta.".zip ".$rutaTemporal.$nombreCarpeta;
					exec($cmd, $output, $return);




					$fileDescarga= $rutaTemporal.$nombreCarpeta.'.zip';
				
					if(file_exists($fileDescarga)){  
						$this->addContador3();                      
		                header('Content-Description: File Transfer');
						header("Content-Type: application/pdf");
						header('Content-Disposition: attachment; filename="'.basename($fileDescarga).'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate');
						header('Pragma: public');
						header('Content-Length: ' . filesize($fileDescarga));
						ob_clean();
						readfile($fileDescarga);
	                	//exit;               
	            	}
					
					
					
				}

			}

			if($tipoGeneracion=='02'){

				//creando carpeta
				$nombreCarpeta='DESCOMPRIMIR'.time();

				//creando la carpeta si no existe
				if (is_dir($rutaTemporal.$nombreCarpeta)==false){
					mkdir($rutaTemporal.$nombreCarpeta);
				}
				else{
					rmdir($rutaTemporal.$nombreCarpeta);
				}

				$pfdsArray = array();
				
				foreach($_FILES["archivos"]['tmp_name'] as $key => $tmp_name)
				{
					//condicional si el fuchero existe
					if($_FILES["archivos"]["name"][$key]) {
						// Nombres de archivos de temporales
						$archivoNombre = $_FILES["archivos"]["name"][$key]; 
						$origen = $_FILES["archivos"]["tmp_name"][$key]; 					
										

						$nombreSubCarpeta = 'ZIP'.substr($archivoNombre, 0 , strlen($archivoNombre) - 4);

						//creando la carpeta si no existe
						if (is_dir($rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta)==false){
							mkdir($rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta);
						}
						else{
							rmdir($rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta);
						}


						$dir=opendir($rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta);
						$destino = $rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta.'\\'.$archivoNombre; 
						
						if(move_uploaded_file($origen, $destino)) {	
							array_push($pfdsArray, $archivoNombre);
						}else {	
							echo "Se ha producido un error, por favor revise los archivos e intentelo de nuevo.<br>";
						}
						closedir($dir); //Cerramos la conexion con la carpeta destino
					}
				}
				

				sort($pfdsArray);

				$pdfsHijos='';


				if (count($pfdsArray)>0){
			
					foreach($pfdsArray as $pdfHijo){

						
						$nombreSubCarpeta = 'ZIP'.substr($pdfHijo, 0 , strlen($pdfHijo) - 4);

						$file = fopen($rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta.'\\'.'files.txt', 'w');
						fwrite($file,str_replace('_', '|',substr($pdfHijo, 0 , strlen($pdfHijo) - 4)));
						fclose($file);

						$cmd = '7z a '.$rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta.'.zip '.$rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta;

						exec($cmd, $output, $return);

						$this->eliminarCarpeta($rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta);

						$this->addContador3();
						
						//unlink('prueba.html')						
						//unlink($rutaTemporal.$nombreCarpeta.'\\'.$nombreSubCarpeta);

			 			// $pdfsHijos=$pdfsHijos.' "'.$rutaTemporal.$nombreCarpeta."\\".$pdfHijo.'"';

					}

					

					// $inputFile = $pdfsHijos;
		 			// $outputFile = $rutaTemporal.$nombreCarpeta.'\\PDF_Unido.pdf';


		 			// $cmd = 'gswin64c -dPDFA -dBATCH -dNOPAUSE -dPDFACompatibilityPolicy=1  -sDEVICE=pdfwrite -sOutputFile="'.$outputFile.'" '.$inputFile;
		 			
		 			$cmd = '7z a '.$rutaTemporal.$nombreCarpeta.'.zip '.$rutaTemporal.$nombreCarpeta;
					exec($cmd, $output, $return);




					$fileDescarga= $rutaTemporal.$nombreCarpeta.'.zip';
				
					if(file_exists($fileDescarga)){
						                        
		                header('Content-Description: File Transfer');
						header("Content-Type: application/pdf");
						header('Content-Disposition: attachment; filename="'.basename($fileDescarga).'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate');
						header('Pragma: public');
						header('Content-Length: ' . filesize($fileDescarga));
						ob_clean();
						readfile($fileDescarga);
	                	//exit;               
	            	}
					
				}

			}
		}
	}


	public function addContador1(){

		if(isset($_SESSION['id'])){

			$id_dependencia = $_SESSION['id_dependencia'];

			$objModel = $this->loadModel('utilitario');
			$objModel->addContador1($id_dependencia);

		}
	}

	public function addContador2(){

		if(isset($_SESSION['id'])){

			$id_dependencia = $_SESSION['id_dependencia'];

			$objModel = $this->loadModel('utilitario');
			$objModel->addContador2($id_dependencia);

		}
	}
	
	public function addContador3(){

		if(isset($_SESSION['id'])){

			$id_dependencia = $_SESSION['id_dependencia'];

			$objModel = $this->loadModel('utilitario');
			$objModel->addContador3($id_dependencia);

		}
	}

	public function getContador1(){

		if(isset($_SESSION['id'])){

			$id_dependencia = $_SESSION['id_dependencia'];

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getContadoresDependencia('004001',$id_dependencia,'','',array());
			
			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
					
		}
	}

	public function getContador2(){

		if(isset($_SESSION['id'])){

			$id_dependencia = $_SESSION['id_dependencia'];

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getContadoresDependencia('004002',$id_dependencia,'','',array());
			
			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
					
		}
	}

	public function getContador3(){

		if(isset($_SESSION['id'])){

			$id_dependencia = $_SESSION['id_dependencia'];

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getContadoresDependencia('004003',$id_dependencia,'','',array());
			
			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
					
		}
	}


	function eliminarCarpeta($carpeta){
		foreach(glob($carpeta . "/*") as $archivos_carpeta){             
			if (is_dir($archivos_carpeta)){
				rmDir_rf($archivos_carpeta);
			}
			else{
				unlink($archivos_carpeta);
			}
		}
		rmdir($carpeta);
	}



	



	
}

?>