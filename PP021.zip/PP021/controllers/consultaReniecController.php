<?php 
class consultaReniecController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	public function consulta(){

		if(isset($_SESSION['id'])){
					
			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;			
			
			if ($objLayout->validarAccesoOpcion('CONSULTARENIEC/CONSULTA',true)){
				
			    $num_docide_pnat = '';
		    	$title = 'Consulta Ficha DNI';

			    if(isset($_GET['num_docide_pnat'])){
					$num_docide_pnat = trim($_GET['num_docide_pnat']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				$this->_view->num_docide_pnat = $num_docide_pnat;
				$this->_view->title = $title;

				$this->_view->setJs(array('consulta')); 
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}



	public function getDatosDni(){

		if(isset($_SESSION['id'])){
			
		    $num_docide_pnat = "";		   
		    //$idUsuarioSession = $_SESSION['id'];
		    $objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
		    
		    
			if(isset($_POST['num_docide_pnat'])){
				$num_docide_pnat = trim($_POST['num_docide_pnat']);
			}


			$objModel = $this->loadModel('consultaReniec');
			$result = $objModel->getDatosDni($num_docide_pnat);
			

			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);
		
		}
	}


   }


	


?>