<?php 

class seguimientoController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	
	public function biAccionesVirualesCampo(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BIACCIONESVIRUALESCAMPO',true)){

			    
			    $title = 'BI Acciones Virtuales Campo';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biAccionesVirualesCampo')); 
				$this->_view->renderizar('biAccionesVirualesCampo');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biCasosEspecialesSelectivo(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BICASOSESPECIALESSELECTIVO',true)){

			    
			    $title = 'BI Casos Especiales Selectivo';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biCasosEspecialesSelectivo')); 
				$this->_view->renderizar('biCasosEspecialesSelectivo');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biCobranza(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BICOBRANZA',true)){

			    
			    $title = 'PBI Cobranza';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biCobranza')); 
				$this->_view->renderizar('biCobranza');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biCobranzaCampo(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BICOBRANZACAMPO',true)){

			    
			    $title = 'PBI Cobranza Campo';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biCobranzaCampo')); 
				$this->_view->renderizar('biCobranzaCampo');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biCorreos(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BICORREOS',true)){

			    
			    $title = 'BI Correos';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biCorreos')); 
				$this->_view->renderizar('biCorreos');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biCorreosEscritos(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BICORREOSESCRITOS',true)){

			    
			    $title = 'BI Correos Escritos';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biCorreosEscritos')); 
				$this->_view->renderizar('biCorreosEscritos');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biEfectividadRecuperabilidad(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BIEFECTIVIDADRECUPERABILIDAD',true)){

			    
			    $title = 'BI Efectividad Recuperabilidad';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biEfectividadRecuperabilidad')); 
				$this->_view->renderizar('biEfectividadRecuperabilidad');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biEscritos(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BIESCRITOS',true)){

			    
			    $title = 'BI Escritos';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biEscritos')); 
				$this->_view->renderizar('biEscritos');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biInformeEmbargosCampo(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BIINFORMEEMBARGOSCAMPO',true)){

			    
			    $title = 'BI Informe Embargos Campo';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biInformeEmbargosCampo')); 
				$this->_view->renderizar('biInformeEmbargosCampo');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biInformeLabores(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BIINFORMELABORES',true)){

			    
			    $title = 'BI Informe Labores';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biInformeLabores')); 
				$this->_view->renderizar('biInformeLabores');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biInformeLabores2(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BIINFORMELABORES2',true)){

			    
			    $title = 'BI Informe Labores 2';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biInformeLabores2')); 
				$this->_view->renderizar('biInformeLabores2');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function biResponsabilidadSolidaria(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SEGUIMIENTO/BIRESPONSABILIDADSOLIDARIA',true)){

			    
			    $title = 'BI Responsabilidad Solidaria';
			    $shape = '1';
			   	
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('biResponsabilidadSolidaria')); 
				$this->_view->renderizar('biResponsabilidadSolidaria');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}


}


?>