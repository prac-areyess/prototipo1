<?php 
class liquidacionController extends Controller{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
	}

	public function consulta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('LIQUIDACION/CONSULTA',true)){
			
				$ID = '';		
				$RLADUANA = '';
				$RLANO = '';
				$RLNROLIQ = '';

				$title = 'Consulta de Liquidaciones de Aduanas (Transferidas a Tributos)';
			    $shape = '1';

			    if(isset($_POST['ID'])){
					$ID = trim($_POST['ID']);
				}
				if(isset($_POST['RLADUANA'])){
					$RLADUANA = trim($_POST['RLADUANA']);
				}
				if(isset($_POST['RLANO'])){
					$RLANO = trim($_POST['RLANO']);
				}
				if(isset($_POST['RLNROLIQ'])){
					$RLNROLIQ = trim($_POST['RLNROLIQ']);
				}


				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}


				$this->_view->ID = $ID;
				$this->_view->RLADUANA = $RLADUANA;
				$this->_view->RLANO = $RLANO;
				$this->_view->RLNROLIQ = $RLNROLIQ;
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('consultaV20220621'));
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function consultaDeudor(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('LIQUIDACION/CONSULTADEUDOR',true)){

				$RLLIBTRI = '';	

				$title = 'Consulta de Liquidaciones por Deudor';
			    $shape = '1';

			    if(isset($_POST['RLLIBTRI'])){
					$RLLIBTRI = trim($_POST['RLLIBTRI']);
				}

				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				$this->_view->RLLIBTRI = $RLLIBTRI;
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('consultaDeudorV20220621'));
				$this->_view->renderizar('consultaDeudor');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function pagoAcuenta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('LIQUIDACION/PAGOACUENTA',true)){

				$RLADUANA = '';
				$RLANO = '';
				$RLNROLIQ = '';		
				$RLTIPLIQ = '';
				$title = 'Consulta de Pagos a Cuenta';
			    $shape = '1';

			    if(isset($_POST['RLADUANA'])){
					$RLADUANA = trim($_POST['RLADUANA']);
				}
				if(isset($_POST['RLANO'])){
					$RLANO = $_POST['RLANO'];
				}
				if(isset($_POST['RLNROLIQ'])){
					$RLNROLIQ = trim($_POST['RLNROLIQ']);
				}
				if(isset($_POST['RLTIPLIQ'])){
					$RLTIPLIQ = trim($_POST['RLTIPLIQ']);
				}


				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}


				$this->_view->RLADUANA = $RLADUANA;
				$this->_view->RLANO = $RLANO;
				$this->_view->RLNROLIQ = $RLNROLIQ;
				$this->_view->RLTIPLIQ = $RLTIPLIQ;				
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('pagoAcuenta'));
				$this->_view->renderizar('pagoAcuenta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function liquidacionSaldo(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('LIQUIDACION/LIQUIDACIONSALDO',true)){
			//if ($objLayout->validarAccesoOpcion('PRUEBA',true)){

				$ID = '';
				$RLADUANA = '';
				$RLANO = '';
				$RLNROLIQ = '';				
				$title = 'Saldo de Liquidaciones';
			    $shape = '1';

			    if(isset($_POST['ID'])){
					$ID = trim($_POST['ID']);
				}
			    if(isset($_POST['RLADUANA'])){
					$RLADUANA = trim($_POST['RLADUANA']);
				}
				if(isset($_POST['RLANO'])){
					$RLANO = $_POST['RLANO'];
				}
				if(isset($_POST['RLNROLIQ'])){
					$RLNROLIQ = trim($_POST['RLNROLIQ']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				$this->_view->ID = $ID;
				$this->_view->RLADUANA = $RLADUANA;
				$this->_view->RLANO = $RLANO;
				$this->_view->RLNROLIQ = $RLNROLIQ;
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('liquidacionSaldoV20220621'));
				$this->_view->renderizar('liquidacionSaldo');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/mantenimiento'));//sinAcceso
				$this->_view->renderizar('../index/mantenimiento');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function liquidacionDetalle(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('LIQUIDACION/LIQUIDACIONDETALLE',true)){

				$ID = '';
				$RLADUANA = '';
				$RLANO = '';
				$RLNROLIQ = '';	
				$title = 'Consulta de Detalle de Liquidaciones';
			    $shape = '1';

			    if(isset($_POST['ID'])){
					$ID = trim($_POST['ID']);
				}				
			    if(isset($_POST['RLADUANA'])){
					$RLADUANA = trim($_POST['RLADUANA']);
				}
				if(isset($_POST['RLANO'])){
					$RLANO = $_POST['RLANO'];
				}
				if(isset($_POST['RLNROLIQ'])){
					$RLNROLIQ = trim($_POST['RLNROLIQ']);
				}		
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				$this->_view->ID = $ID;
				$this->_view->RLADUANA = $RLADUANA;
				$this->_view->RLANO = $RLANO;
				$this->_view->RLNROLIQ = $RLNROLIQ;			
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('liquidacionDetalleV20220621'));
				$this->_view->renderizar('liquidacionDetalle');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}
	
	public function calculadora(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('USUARIO/CONSULTA',true)){

				$RLADUANA = '';
				$RLANO = '';
				$RLNROLIQ = '';				
				$title = 'calculadora de Liquidaciones de Cobranza';
			    $shape = '1';

			    if(isset($_POST['RLADUANA'])){
					$RLADUANA = trim($_POST['RLADUANA']);
				}
				if(isset($_POST['RLANO'])){
					$RLANO = $_POST['RLANO'];
				}
				if(isset($_POST['RLNROLIQ'])){
					$RLNROLIQ = trim($_POST['RLNROLIQ']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}


				$this->_view->RLADUANA = $RLADUANA;
				$this->_view->RLANO = $RLANO;
				$this->_view->RLNROLIQ = $RLNROLIQ;
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('calculadora'));
				$this->_view->renderizar('calculadora');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function getLiquidaciones(){

		if(isset($_SESSION['id'])){
			
			$ID = '';
			$RLADUANA = '';
			$RLANO = '';
			$RLNROLIQ = '';
			$RLLIBTRI = '';
			$EXP_COACTIVO = '';
			$SUPERVISOR = '';
			$EQUIPO = '';
			$IND_ASOC = '';
			$ultimosRegistros = '';	

			if(isset($_POST['ID'])){
				$ID = trim($_POST['ID']);
			}
		   	if(isset($_POST['RLADUANA'])){
				$RLADUANA = trim($_POST['RLADUANA']);
			}
			if(isset($_POST['RLANO'])){
				$RLANO = trim($_POST['RLANO']);
			}
			if(isset($_POST['RLNROLIQ'])){
				$RLNROLIQ = trim($_POST['RLNROLIQ']);
			}
			if(isset($_POST['RLLIBTRI'])){
				$RLLIBTRI = trim($_POST['RLLIBTRI']);
			}		
			if(isset($_POST['EXP_COACTIVO'])){
				$EXP_COACTIVO = trim($_POST['EXP_COACTIVO']);
			}
			if(isset($_POST['SUPERVISOR'])){
				$SUPERVISOR = trim($_POST['SUPERVISOR']);
			}
			if(isset($_POST['EQUIPO'])){
				$EQUIPO = trim($_POST['EQUIPO']);
			}
			if(isset($_POST['IND_ASOC'])){
				$IND_ASOC = trim($_POST['IND_ASOC']);
			}
			if(isset($_POST['ultimosRegistros'])){
				$ultimosRegistros = trim($_POST['ultimosRegistros']);
			}	


			$objModel = $this->loadModel('liquidacion');
			$result = $objModel->getLiquidaciones($ID,$RLADUANA,$RLANO,$RLNROLIQ,$RLLIBTRI,$EXP_COACTIVO,$SUPERVISOR,$EQUIPO,$IND_ASOC,$ultimosRegistros);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function getDatosDeudor(){

		if(isset($_SESSION['id'])){
			
			$RLLIBTRI = '';
						
			if(isset($_POST['RLLIBTRI'])){
				$RLLIBTRI = trim($_POST['RLLIBTRI']);
			}		
			
			$objModel = $this->loadModel('liquidacion');
			$result = $objModel->getDatosDeudor($RLLIBTRI);

			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function getPagosACuenta(){

		if(isset($_SESSION['id'])){
			
			$RLADUANA = '';
			$RLANO = '';
			$RLNROLIQ = '';
			$RLCODDES = '';
			$RLCODUSU = '';
			$RLTIPLIQ = '';
			$RLTIPDOC = '';
			$RLLIBTRI = '';
			$RLCOMITE = '';
			$RLCODORI = '';
			$RLDIRECC = '';
			$RLADUASO = '';
			$RLANOASO = '';
			$RLNUMASO = '';

		   	if(isset($_POST['RLADUANA'])){
				$RLADUANA = trim($_POST['RLADUANA']);
			}
			if(isset($_POST['RLANO'])){
				$RLANO = $_POST['RLANO'];
			}
			if(isset($_POST['RLNROLIQ'])){
				$RLNROLIQ = trim($_POST['RLNROLIQ']);
			}
			if(isset($_POST['RLCODDES'])){
				$RLCODDES = trim($_POST['RLCODDES']);
			}
			if(isset($_POST['RLCODUSU'])){
				$RLCODUSU = trim($_POST['RLCODUSU']);
			}
			if(isset($_POST['RLTIPLIQ'])){
				$RLTIPLIQ = trim($_POST['RLTIPLIQ']);
			}
			if(isset($_POST['RLTIPDOC'])){
				$RLTIPDOC = trim($_POST['RLTIPDOC']);
			}
			if(isset($_POST['RLLIBTRI'])){
				$RLLIBTRI = trim($_POST['RLLIBTRI']);
			}
			if(isset($_POST['RLCOMITE'])){
				$RLCOMITE = trim($_POST['RLCOMITE']);
			}
			if(isset($_POST['RLCODORI'])){
				$RLCODORI = trim($_POST['RLCODORI']);
			}
			if(isset($_POST['RLDIRECC'])){
				$RLDIRECC = trim($_POST['RLDIRECC']);
			}
			if(isset($_POST['RLADUASO'])){
				$RLADUASO = trim($_POST['RLADUASO']);
			}
			if(isset($_POST['RLANOASO'])){
				$RLANOASO = $_POST['RLANOASO'];
			}
			if(isset($_POST['RLNUMASO'])){
				$RLNUMASO = trim($_POST['RLNUMASO']);
			}

			$objModel = $this->loadModel('liquidacion');
			$result = $objModel->getPagosACuenta($RLADUANA,$RLANO,$RLNROLIQ,$RLLIBTRI,$RLADUASO,$RLANOASO,$RLNUMASO);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function getLiquidacionesAsociadas(){

		if(isset($_SESSION['id'])){
			
			$ID = '';
			$RLADUANA = '';
			$RLANO = '';
			$RLNROLIQ = '';
						
			if(isset($_POST['ID'])){
				$ID = trim($_POST['ID']);
			}
		   	if(isset($_POST['RLADUANA'])){
				$RLADUANA = trim($_POST['RLADUANA']);
			}
			if(isset($_POST['RLANO'])){
				$RLANO = $_POST['RLANO'];
			}
			if(isset($_POST['RLNROLIQ'])){
				$RLNROLIQ = trim($_POST['RLNROLIQ']);
			}
			

			$objModel = $this->loadModel('liquidacion');
			$result = $objModel->getLiquidacionesAsociadas($ID,$RLADUANA,$RLANO,$RLNROLIQ);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function getLiquidacionesAsociadasDetalle(){

		if(isset($_SESSION['id'])){
			
			$ID = '';
			$RLADUANA = '';
			$RLANO = '';
			$RLNROLIQ = '';
						
			if(isset($_POST['ID'])){
				$ID = trim($_POST['ID']);
			}
		   	if(isset($_POST['RLADUANA'])){
				$RLADUANA = trim($_POST['RLADUANA']);
			}
			if(isset($_POST['RLANO'])){
				$RLANO = $_POST['RLANO'];
			}
			if(isset($_POST['RLNROLIQ'])){
				$RLNROLIQ = trim($_POST['RLNROLIQ']);
			}
			

			$objModel = $this->loadModel('liquidacion');
			$result = $objModel->getLiquidacionesAsociadasDetalle($ID,$RLADUANA,$RLANO,$RLNROLIQ);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	/*public function getLiquidacionesAsociadasYO(){

		if(isset($_SESSION['id'])){
			
			$RLADUANA = '';
			$RLANO = '';
			$RLNROLIQ = '';
			$RLLIBTRI = '';
			$RLADUASO = '';
			$RLANOASO = '';
			$RLNUMASO = '';
			

		   	if(isset($_POST['RLADUANA'])){
				$RLADUANA = trim($_POST['RLADUANA']);
			}
			if(isset($_POST['RLANO'])){
				$RLANO = $_POST['RLANO'];
			}
			if(isset($_POST['RLNROLIQ'])){
				$RLNROLIQ = trim($_POST['RLNROLIQ']);
			}
			if(isset($_POST['RLLIBTRI'])){
				$RLLIBTRI = trim($_POST['RLLIBTRI']);
			}

			if(isset($_POST['RLADUASO'])){
				$RLADUASO = trim($_POST['RLADUASO']);
			}
			if(isset($_POST['RLANOASO'])){
				$RLANOASO = $_POST['RLANOASO'];
			}
			if(isset($_POST['RLNUMASO'])){
				$RLNUMASO = trim($_POST['RLNUMASO']);
			}

			$objModel = $this->loadModel('liquidacion');
			$result = $objModel->getLiquidaciones($RLADUANA,$RLANO,$RLNROLIQ,$RLLIBTRI,'','','');


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;


			    $RLADUANA2 = $row['RLADUANA'];
			    $RLANO2 = $row['RLANO'];
			    $RLNROLIQ2 = $row['RLNROLIQ'];

			    $RLLIBTRI2 = $row['RLLIBTRI'];

			    $RLADUASO2 = $row['RLADUASO'];
			    $RLANOASO2 = $row['RLANOASO'];
			    $RLNUMASO2 = $row['RLNUMASO'];


			    $result2 = $objModel->getLiquidaciones($RLADUASO2,$RLANOASO2,$RLNUMASO2,$RLLIBTRI2,'','','');

			    

		    	while ($row2 = $result2->fetch())  {

		    		array_push($arreglo['data'],$row2);	

				    $RLADUASO2 = $row2['RLADUASO'];
			    	$RLANOASO2 = $row2['RLANOASO'];
			    	$RLNUMASO2 = $row2['RLNUMASO'];

			    	$RLLIBTRI2 = $row2['RLLIBTRI'];
			    	
				    				    
		    		$result2 = $objModel->getLiquidaciones($RLADUASO2,$RLANOASO2,$RLNUMASO2,$RLLIBTRI2,'','','');
				}

					
			    $result2 = $objModel->getLiquidaciones('','','',$RLLIBTRI2,$RLADUANA2,$RLANO2,$RLNROLIQ2);

			    

		    	while ($row2 = $result2->fetch())  {
				    
		    		array_push($arreglo['data'],$row2);	

				    $RLADUANA2 = $row2['RLADUANA'];
			    	$RLANO2 = $row2['RLANO'];
			    	$RLNROLIQ2 = $row2['RLNROLIQ'];

			    	$RLLIBTRI2 = $row2['RLLIBTRI'];
				    				    
			    	$result2 = $objModel->getLiquidaciones('','','',$RLLIBTRI2,$RLADUANA2,$RLANO2,$RLNROLIQ2);
				}

					
			}	


			echo json_encode($arreglo);
		}
	}*/

	public function getLiquidacionesDetalle(){

		if(isset($_SESSION['id'])){
			
			$ID = '';
			$RLADUANA = '';
			$RLANO = '';
			$RLNROLIQ = '';

			if(isset($_POST['ID'])){
				$ID = trim($_POST['ID']);
			}
		   	if(isset($_POST['RLADUANA'])){
				$RLADUANA = trim($_POST['RLADUANA']);
			}
			if(isset($_POST['RLANO'])){
				$RLANO = $_POST['RLANO'];
			}
			if(isset($_POST['RLNROLIQ'])){
				$RLNROLIQ = trim($_POST['RLNROLIQ']);
			}			

			$objModel = $this->loadModel('liquidacion');
			$result = $objModel->getLiquidacionesDetalle($ID,$RLADUANA,$RLANO,$RLNROLIQ);

			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);		

		}
	}

	public function getLiquidacionesAsociadasCalculadoraEnPrueba(){

		if(isset($_SESSION['id'])){
			
			$RLADUANA = '';
			$RLANO = '';
			$RLNROLIQ = '';
			$RLLIBTRI = '';
			$RLADUASO = '';
			$RLANOASO = '';
			$RLNUMASO = '';
			

		   	if(isset($_POST['RLADUANA'])){
				$RLADUANA = trim($_POST['RLADUANA']);
			}
			if(isset($_POST['RLANO'])){
				$RLANO = $_POST['RLANO'];
			}
			if(isset($_POST['RLNROLIQ'])){
				$RLNROLIQ = trim($_POST['RLNROLIQ']);
			}
			if(isset($_POST['RLLIBTRI'])){
				$RLLIBTRI = trim($_POST['RLLIBTRI']);
			}

			if(isset($_POST['RLADUASO'])){
				$RLADUASO = trim($_POST['RLADUASO']);
			}
			if(isset($_POST['RLANOASO'])){
				$RLANOASO = $_POST['RLANOASO'];
			}
			if(isset($_POST['RLNUMASO'])){
				$RLNUMASO = trim($_POST['RLNUMASO']);
			}

			$objModel = $this->loadModel('liquidacion');
			$result = $objModel->getLiquidaciones($RLADUANA,$RLANO,$RLNROLIQ,$RLLIBTRI,'','','');


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;


			    $RLADUANA2 = $row['RLADUANA'];
			    $RLANO2 = $row['RLANO'];
			    $RLNROLIQ2 = $row['RLNROLIQ'];

			    $RLLIBTRI2 = $row['RLLIBTRI'];

			    $RLADUASO2 = $row['RLADUASO'];
			    $RLANOASO2 = $row['RLANOASO'];
			    $RLNUMASO2 = $row['RLNUMASO'];


			    $result2 = $objModel->getLiquidaciones($RLADUASO2,$RLANOASO2,$RLNUMASO2,$RLLIBTRI2,'','','');

			    // echo $RLADUANA2.'-'.$RLANO2.'-'.$RLNROLIQ2;
			    // echo '\n';
			    // echo $RLADUASO2.'-'.$RLANOASO2.'-'.$RLNUMASO2;
			    // echo '\n';
			    // echo ($result2->rowCount());
			    //while ($result2->rowCount()>0){

			    	while ($row2 = $result2->fetch())  {
					    //$arreglo['data'][] = $row;

			    		array_push($arreglo['data'],$row2);	

					    $RLADUASO2 = $row2['RLADUASO'];
				    	$RLANOASO2 = $row2['RLANOASO'];
				    	$RLNUMASO2 = $row2['RLNUMASO'];

				    	$RLLIBTRI2 = $row2['RLLIBTRI'];
				    	
				    	// echo 'gasas';
				    	// echo $row2['RLADUANA'].'-'.$row2['RLANO'].'-'.$row2['RLNROLIQ'];
			    		// echo '\n';
					    				    
			    		$result2 = $objModel->getLiquidaciones($RLADUASO2,$RLANOASO2,$RLNUMASO2,$RLLIBTRI2,'','','');
					}

					//$result2 = $objModel->getLiquidaciones($RLADUASO2,$RLANOASO2,$RLNUMASO2,'','','');
			    //}

			    ////
			    $result2 = $objModel->getLiquidaciones('','','',$RLLIBTRI2,$RLADUANA2,$RLANO2,$RLNROLIQ2);

			    //while ($result2->rowCount()>0){

			    	while ($row2 = $result2->fetch())  {
					    //$arreglo['data'][] = $row;
			    		array_push($arreglo['data'],$row2);	

					    $RLADUANA2 = $row2['RLADUANA'];
				    	$RLANO2 = $row2['RLANO'];
				    	$RLNROLIQ2 = $row2['RLNROLIQ'];

				    	$RLLIBTRI2 = $row2['RLLIBTRI'];
					    				    
				    	$result2 = $objModel->getLiquidaciones('','','',$RLLIBTRI2,$RLADUANA2,$RLANO2,$RLNROLIQ2);
					}

					//$result2 = $objModel->getLiquidaciones('','','',$RLADUANA2,$RLANO2,$RLNROLIQ2);
			    //}

			}	


			//var row = jsonData.data[i];	
			$datosArray = array();
			
			

			//echo count($arreglo['data']);
			//echo '-';

			$row = $arreglo['data'][0];

			//echo $row['RLNROLIQ'];
			

			array_push($datosArray,$row);


			$row = $arreglo['data'][1];

			//echo $row['RLNROLIQ'];

			array_push($datosArray,$row);


			$this->arraySortByColumn($datosArray, 'RLFECLIQ',SORT_ASC);

			 // echo ' ||0|| ';
			 // echo $datosArray[0][0];
			 // echo ' ||1|| ';
			 // echo $datosArray[1][0];


	   //  	  echo ' ||0fEClIQ|| ';
			 // echo $datosArray[0][25];
			 // echo ' ||1fEClIQ|| ';
			 // echo $datosArray[1][25];


			

			
			$RLFECLIQAnterior = '';
			$RLFECLIQ = '';

			$saldo=0;
			//echo '||||';

			for($i=0;$i<count($datosArray);$i++) {

				$row=$datosArray[$i];

				//echo $row['RLNROLIQ'];
				//echo '||||';

				$RLFECLIQ = $row['RLFECLIQ'];
				$RLFECLIQ = substr($RLFECLIQ,0,4).'-'.substr($RLFECLIQ,4,2).'-'.substr($RLFECLIQ,6,2);

				$IDPosterior = '';
				$RLFECLIQPosterior = '';
				$TOTALDOLARESPosterior = 0;
			

				if($i>=(count($datosArray)-1)){
					$RLFECLIQPosterior = 'ULTIMO';
					//$saldo=$row['TOTALDOLARES'];
				}else{
					$row2=$datosArray[$i + 1];
					$IDPosterior = $row2['ID'];
					$RLFECLIQPosterior = $row2['RLFECLIQ'];
					$TOTALDOLARESPosterior = $row2['TOTALDOLARES'];
				}

				
				$RLTIPLIQ = $row['RLTIPLIQ'];

				if($i==0){
					error_log('A');
					if($RLTIPLIQ=='0015'){
						$saldo= 0;
					}else{
						$saldo=$row['TOTALDOLARES'];
					}

				}else{
					
					if($RLTIPLIQ == '0015'){
						$pago = intval($row['TOTALDOLARES']);
						$saldo = $saldo + $pago;
					}else{
						$pago = intval($row['TOTALDOLARES']);
						$saldo = $saldo + $pago;
					}

				}

				

				if($RLFECLIQPosterior <> 'ULTIMO'){

					$RLFECLIQPosterior = substr($RLFECLIQPosterior,0,4).'-'.substr($RLFECLIQPosterior,4,2).'-'.substr($RLFECLIQPosterior,6,2);


					$fecha1 = new DateTime($RLFECLIQPosterior);
					$fecha2 = new DateTime($RLFECLIQ);
					$diff = $fecha2->diff($fecha1);
				}else{
					$fecha1 = new DateTime();
					$fecha2 = new DateTime($RLFECLIQ);
					$diff = $fecha2->diff($fecha1);
				}



				$arrayAdd =array();
				
				$tasa = intval(($diff)->format('%R%a'))*0.02;

				$arrayAdd['ID'] = $row['ID'].'-INTERESES';
				$arrayAdd['IDASO'] = '';
				$arrayAdd['RLTIPLIQ'] = '';
				$arrayAdd['RLTIPLIQDESC'] = 'Intereses -> Dias: '.($diff)->format('%R%a días').' x 0.02 = tasa: '.$tasa;
				$arrayAdd['RLLIBTRI'] = '';
				$arrayAdd['RLCOMITE'] = '';
				$arrayAdd['RLFECLIQ'] = '';
				$arrayAdd['RLFECCAN'] = '';
				$arrayAdd['RLDMONTOT'] = '';
				$arrayAdd['RLSMONTOT'] = '';
				$arrayAdd['TIPOCAMBIO'] = '';
				$arrayAdd['TOTALDOLARES'] = abs(intval($saldo * $tasa / 100));
				$saldo = $saldo + abs(intval($saldo * $tasa / 100));					
				$arrayAdd['RLCODORIDESC'] = '';

					
				
					

				array_push($arreglo['data'],$arrayAdd);	
			


			
			}


			// $arrayAdd['ID'] = '999-99-999999-SALDO';
			// $arrayAdd['IDASO'] = '';
			// $arrayAdd['RLTIPLIQ'] = '';
			// $arrayAdd['RLTIPLIQDESC'] = 'SALDO';
			// $arrayAdd['RLLIBTRI'] = '';
			// $arrayAdd['RLCOMITE'] = '';
			// $arrayAdd['RLFECLIQ'] = '';
			// $arrayAdd['RLFECCAN'] = '';
			// $arrayAdd['RLDMONTOT'] = '';
			// $arrayAdd['RLSMONTOT'] = '';
			// $arrayAdd['TIPOCAMBIO'] = '';
			// $arrayAdd['TOTALDOLARES'] = $saldo;				
			// $arrayAdd['RLCODORIDESC'] = '';

			
				

			// array_push($arreglo['data'],$arrayAdd);	

			
			// El resultados sera 3 dias
			//echo $diff->days . ' dias';
					

			// foreach ($datosArray as $row) {	
			// 	//$idTomaDicho=$row['idTomaDicho'];

			



			// 	echo '||||';
			// 	echo $row['RLNROLIQ'];
			// }

			


			echo json_encode($arreglo);
		}
	}

	

	public function arraySortByColumn(&$arr, $col, $dir = SORT_ASC) {

   		$sort_col = array();
    	foreach ($arr as $key => $row) {
        	$sort_col[$key] = $row[$col];
    	}

	    array_multisort($sort_col, $dir, $arr);
	}

	


	
}

?>