<?php 

class aduanaLlamadaModel extends Model{
	public function __construct(){
		parent::__construct();
	}

	public function generarId(){
		$sql="DECLARE @idAduanaLLamada varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '012001','002000','6', @idAduanaLLamada output ;
		select @idAduanaLLamada as idAduanaLLamada;";
		
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	
	
	public function getAduanasLlamadas($idAduanaLlamada,$idAduanaLlamadaArray,$fecLlamadaIni,$fecLlamadaFin,$tipoDocIdentidad,$docIdentidad,$apellidoPaterno,$apellidoMaterno,$nombres,$expCoactivo,$usuReg,$fecRegIni,$fecRegFin,$estado,$estadoArray){

		$sql="SELECT 
		a.id,
		CONVERT(char(10), a.fecLlamada, 126) as fecLlamada,		
		a.tipoDocIdentidad,
    	case
    	when a.tipoDocIdentidad='1' then 'DNI'
    	when a.tipoDocIdentidad='6' then 'RUC'
    	when a.tipoDocIdentidad='7' then 'OTRO'
    	end as tipoDocIdentidadDesc,
		a.docIdentidad,
		a.razonSocial,
		a.telefono,
		a.apellidoPaterno,
		a.apellidoMaterno,
		a.nombres,
		a.cargo,
		case
		when a.cargo='0250001' then 'ABOGADO'
	    when a.cargo='0250002' then 'ACCIONISTA'
	    when a.cargo='0250003' then 'ADMINISTRADOR'
	    when a.cargo='0250004' then 'ADMINISTRADOR JUDICIAL'
	    when a.cargo='0250005' then 'APODERADO'
	    when a.cargo='0250006' then 'CONTADOR'
	    when a.cargo='0250007' then 'DIRECTOR CENTRO EDUCTIVO'
	    when a.cargo='0250008' then 'DIRECTOR GENERAL'
	    when a.cargo='0250009' then 'FAMILIAR DEL TITULAR'
	    when a.cargo='0250010' then 'FUNCIONARIO PÚBLICO'
	    when a.cargo='0250011' then 'GERENTE GENERAL'
	    when a.cargo='0250013' then 'MIEMBRO DEL DIRECTORIO'
	    when a.cargo='0250014' then 'PRESIDENTE DE DIRECTORIO'
	    when a.cargo='0250015' then 'RECTOR'
	    when a.cargo='0250016' then 'REPRESENTANTE LEGAL'
	    when a.cargo='0250017' then 'SECRETARIA'
	    when a.cargo='0250018' then 'SIN RELACION'
	    when a.cargo='0250019' then 'SOCIO-ACCCIONISTA'
	    when a.cargo='0250020' then 'SUBGERENTE'
	    when a.cargo='0250021' then 'TESORERO'
	    when a.cargo='0250022' then 'TITULAR'
	    when a.cargo='0250023' then 'TRABAJADOR'
	    when a.cargo='0250024' then 'VICE-RECTOR'
	    else a.cargo
    	end as cargoDesc,
		a.contribuyenteContactado,

		case
		when a.contribuyenteContactado='SI' then 'SI CONTACTADO'
		when a.contribuyenteContactado='NO' then 'NO CONTACTADO'
		end as contribuyenteContactadoDesc,
		

		a.resultadoLlamada,

		case
		when a.resultadoLlamada = '0230001' then 'CONTESTA'
		when a.resultadoLlamada = '0230007' then 'CONTESTA CORREO'
		when a.resultadoLlamada = '0230004' then 'FUERA DE SERVICIO'
		when a.resultadoLlamada = '0230002' then 'NO CONTESTA'
		when a.resultadoLlamada = '0230005' then 'NO EXISTE NÚMERO'
		when a.resultadoLlamada = '0230008' then 'NO SE LLAMO'
		when a.resultadoLlamada = '0230009' then 'SE DEJO MENSAJE DE VOZ'
		when a.resultadoLlamada = '0230010' then 'SE ENVIO CORREO ELECTRONICO'
		when a.resultadoLlamada = '0230011' then 'SIN TELEFONOS'
		when a.resultadoLlamada = '0230006' then 'SOLICITA RELLAMADA'
		when a.resultadoLlamada = '0230003' then 'TELEFONO NO CORRESPONDE'
		end as resultadoLlamadaDesc,



		a.resultadoNegociacion,

		case
		when a.resultadoNegociacion = '0240001' then 'CANCELADO'
	    when a.resultadoNegociacion = '0240008' then 'CANCELADO ANTES DE INDUCCION'
	    when a.resultadoNegociacion = '0240010' then 'COMPENSARA'
	    when a.resultadoNegociacion = '0240004' then 'CON PODER DE NEGOCIACIÓN SIN INTENCION DE PAGO'
	    when a.resultadoNegociacion = '0240013' then 'ENTREGARA CHEQUE'
	    when a.resultadoNegociacion = '0240005' then 'FRACCIONAMIENTO'
	    when a.resultadoNegociacion = '0240009' then 'IMPUGNARA'
	    when a.resultadoNegociacion = '0240002' then 'PAGO ERRADO'
	    when a.resultadoNegociacion = '0240011' then 'PAGO PARCIAL'
	    when a.resultadoNegociacion = '0240012' then 'PRESENTARA FORMULARIO VIRTUAL O ESCRITO'
	    when a.resultadoNegociacion = '0240003' then 'PROPUESTA DE PAGO'
	    when a.resultadoNegociacion = '0240006' then 'SIN PODER DE NEGOCIACION'
	    when a.resultadoNegociacion = '0240007' then 'SIN RESULTADO'
	    end as resultadoNegociacionDesc,

		a.tipoLLamada,

		case 
		when a.tipoLLamada='0380001' then 'ENTRANTE'
		when a.tipoLLamada='0380002' then 'SALIENTE'
		end as tipoLLamadaDesc,
		
		a.observacion,
		a.expCoactivo,
		a.rcEmbargo,
		a.respuesta,

		case 
		when a.respuesta='0730002' then 'ES CLIENTE DEL EJECUTADO, CON MONTO A RETENER'
		when a.respuesta='0730001' then 'SIN RESPUESTA'
		end as respuestaDesc,


		CONVERT(char(10), a.fecEstimadaEntrega, 126) as fecEstimadaEntrega,
		a.usuReg,
		CONVERT(char(10), a.fecReg, 126) as fecReg,
		a.usuMod,
		CONVERT(char(10), a.fecMod, 126) as fecMod,
		a.estado,
		case
		when a.estado = '01'  then '01 - ACTIVO'
		end as estadoDesc
		from db_6E2000.dbo.a012_aduanaLlamada a
		where
		a.id is not null";

		if ($idAduanaLlamada=='*'){
			if (count($idTomaDichoArray)>0){

				$idAduanaLlamadaSerie='';
				foreach($idAduanaLlamadaArray as $item){
		 			$idAduanaLlamadaSerie.="'".$item."',";
		 		}

				$idAduanaLlamadaSerie = substr($idAduanaLlamadaSerie, 0, strlen($idAduanaLlamadaSerie) - 1 );
				$sql=$sql." and a.id in ($idAduanaLlamadaSerie)";
			}

		}else{
			if($idAduanaLlamada<>''){
				$sql=$sql." and a.id = '$idAduanaLlamada'";
			}
		}	

		if (strtotime(str_replace('/', '-', $fecLlamadaIni)) and strtotime(str_replace('/', '-', $fecLlamadaFin))){

			$fecLlamadaIni=date('Y-m-d',strtotime(str_replace('/', '-', $fecLlamadaIni)));
			$fecLlamadaFin=date('Y-m-d',strtotime(str_replace('/', '-', $fecLlamadaFin)));

			$sql=$sql." and a.fecLlamada between '".$fecLlamadaIni." 00:00:00' and '".$fecLlamadaFin." 23:59:59'";
		}

		if ($tipoDocIdentidad != '' ){
			$sql=$sql." and a.tipoDocIdentidad = '$tipoDocIdentidad'";
		}
		if ($docIdentidad != '' ){
			$sql=$sql." and a.docIdentidad = '$docIdentidad'";
		}
		if ($apellidoPaterno != '' ){
			$sql=$sql." and a.apellidoPaterno = '$apellidoPaterno'";
		}	
		if ($apellidoMaterno != '' ){
			$sql=$sql." and a.apellidoMaterno = '$apellidoMaterno'";
		}	
		if ($nombres != '' ){
			$sql=$sql." and a.nombres = '$nombres'";
		}
		
		if ($usuReg != '' ){
			$sql=$sql." and a.usuReg = '$usuReg'";
		}		
		
		if (strtotime(str_replace('/', '-', $fecRegIni)) and strtotime(str_replace('/', '-', $fecRegFin))){

			$fecRegIni=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegIni)));
			$fecRegFin=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegFin)));

			$sql=$sql." and a.fecLlamada between '".$fecRegIni." 00:00:00' and '".$fecRegFin." 23:59:59'";
		}

		if ($estado=='*'){
			if (count($estadoArray)>0){

				$estadoSerie='';
				foreach($estadoArray as $item){
		 			$estadoSerie.="'".$item."',";
		 		}

				$estadoSerie = substr($estadoSerie, 0, strlen($estadoSerie) - 1 );
				$sql=$sql." and a.estado in ($estadoSerie)";
			}

		}else{
			if($estado<>''){
				$sql=$sql." and a.estado = '$estado'";
			}
		}	

		$sql=$sql." order by a.id desc";

		//echo $sql;
		


		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function insAduanaLlamada($idAduanaLlamada,$telefono,$fecLlamada,$tipoDocIdentidad,$docIdentidad,$razonSocial,$apellidoPaterno,$apellidoMaterno,$nombres,$cargo,$contribuyenteContactado,$resultadoLlamada,$resultadoNegociacion,$tipoLLamada,$observacion,$expCoactivo,$rcEmbargo,$respuesta,$fecEstimadaEntrega,$usuReg,$estado){


		$razonSocial = str_replace("'", "''", $razonSocial);
		


		$sql="INSERT INTO db_6E2000.dbo.a012_aduanaLlamada(
		id,telefono,fecLlamada,tipoDocIdentidad,docIdentidad,razonSocial,apellidoPaterno,apellidoMaterno,nombres,cargo,contribuyenteContactado,resultadoLlamada,resultadoNegociacion,tipoLLamada,observacion,expCoactivo,rcEmbargo,respuesta,fecEstimadaEntrega,usuReg,fecReg,estado) VALUES	('$idAduanaLlamada','$telefono',getdate(),'$tipoDocIdentidad','$docIdentidad','$razonSocial','$apellidoPaterno','$apellidoMaterno','$nombres','$cargo','$contribuyenteContactado','$resultadoLlamada','$resultadoNegociacion','$tipoLLamada','$observacion','$expCoactivo','$rcEmbargo','$respuesta','$fecEstimadaEntrega','$usuReg',getdate(),'$estado');";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updAduanaLlamada($idAduanaLlamada,$fecLlamada,$telefono,$razonSocial,$apellidoPaterno,$apellidoMaterno,$nombres,$cargo,$contribuyenteContactado,$resultadoLlamada,$resultadoNegociacion,$tipoLLamada,$observacion,$expCoactivo,$rcEmbargo,$respuesta,$fecEstimadaEntrega,$usuMod,$estado){

		$sql="UPDATE db_6E2000.dbo.a012_aduanaLlamada 
		SET 
		telefono = '$telefono',
		razonSocial = '$razonSocial',
		apellidoPaterno = '$apellidoPaterno',
		apellidoMaterno = '$apellidoMaterno',
		nombres = '$nombres',
		cargo = '$cargo',
		contribuyenteContactado = '$contribuyenteContactado',
		resultadoLlamada = '$resultadoLlamada',
		resultadoNegociacion = '$resultadoNegociacion',
		tipoLLamada = '$tipoLLamada',
		observacion = '$observacion',
		expCoactivo = '$expCoactivo',
		rcEmbargo = '$rcEmbargo',
		respuesta = '$respuesta',
		fecEstimadaEntrega = '$fecEstimadaEntrega',
		fecMod = getdate(),
		usuMod = '$usuMod',
		estado = '$estado'
		WHERE 
		id = '$idAduanaLlamada'";
		//echo $telefono;
		
		$this->_db1->query($sql) or die($sql);
	}
	

	public function delAduanaLlamada($idAduanaLlamada){
		
		$sql="UPDATE db_6E2000.dbo.a012_aduanaLlamada 
		SET 
		estado='DE'
		WHERE 
		id = '$idAduanaLlamada' ";
		
		
		$this->_db1->query($sql) or die($sql);


	}

	

	public function getDatosDni($dni){
		
		$sql="select 
		a.num_docide_pnat as dni,
		a.des_apepat_pnat + ' ' + a.des_apemat_pnat + ', '+ a.des_nombre_pnat as razonSocial
		from db_fext.reps.FICHA_RENIEC a
		where
		a.num_docide_pnat ='$dni'";
		
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}


	public function getDatosRuc($ruc){
		
		$sql="select 
		a.ruc as ruc,
		a.razon_social as razonSocial
		from db_fext.reps.ficha_nacional a
		where
		a.ruc='$ruc'";
		
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}

	

	/*public function getDatosRC($rc){
		
		$sql="select 
		top 1 
		a.num_rc as rc, 
		a.num_ruc as ruc, 
		a.num_exp_rc as rec, 
		a.razon_social as razonSocial
		from db_cobranza.intr.embargos_terceros a
		where a.num_rc='$rc'";
				
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}

	public function getListaTerceros($rc){
		
		$sql="select 
		a.num_ter as codTercero,
		a.num_ruc_ter as rucTercero,
		a.nom_ter as nombreTercero
		from db_cobranza.intr.embargos_terceros a
		where a.num_rc='$rc'
		order by a.nom_ter";
		
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}*/


	
}
?>