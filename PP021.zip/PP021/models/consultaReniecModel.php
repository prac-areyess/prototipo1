<?php 

class consultaReniecModel extends Model{
	public function __construct(){
		parent::__construct();
	}

	
	
	public function getDatosDni($num_docide_pnat){

		$sql="SELECT num_docide_pnat
			  ,des_nombre_pnat
			  ,des_apepat_pnat
      		  ,des_apemat_pnat
			  ,datediff(year,convert(date,fec_nac_pnat,103),getdate()) as edad 
		      ,fec_nac_pnat
		      ,des_estciv_pnat
		      ,des_sexo_pnat
		      ,des_domici_pnat
		      ,departamento
		      ,provincia
		      ,distrito
		  FROM [db_fext].[reps].[FICHA_RENIEC]
		  where
		  num_docide_pnat ='$num_docide_pnat'";
		
		$sql=$sql." order by 3";

		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}

	
}
?>