<?php 
class aplicacionModel extends Model{

	protected $id_usuario;
	protected $id_dependencia;

	public function __construct(){
		parent::__construct();
	}


	///////SOLO LOGIN

	public function validarCuenta($username,$id_dependencia){

		$username=strtoupper($username);

		$sql = "select 
		a.id, a.nombres, 
		a.apellido_paterno, 
		a.apellido_materno, 
		lower(a.correo)  as correo, 
		a.id_area, 
		a.id_modalidad_contrato, 
		a.estado, 
		a.perfil, 
		a.sexo, 
		a.username, 
		a.jefe, 
		a.foto, 
		a.id_dependencia 
		from db_6E2000.dbo.a000_usuario a 
		inner join db_6E2000.dbo.a000_cta b on b.id_usuario = a.id and b.id_dependencia = '$id_dependencia'
		where 
		upper(a.username) = '$username'
		and
		a.estado = '01'";

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
		
	}

	public function validarPassword($usuario,$clave){
		//deshabilita el error solo en esta pagina
		error_reporting(0);
		if ($clave!=''){
			putenv('LDAPTLS_REQCERT=never');
	        $ldapconn = ldap_connect("ldap://dcsis11.sunat.peru",389) or die("Could not connect to LDAP server.");
	        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
	        ldap_set_option($ldapconn, LDAP_OPT_REFERRALS,0); 
	        if ($ldapconn) {
	            $user="SUNAT\\".$usuario;           
	            $ldapbind = ldap_bind($ldapconn, $user, $clave);
	            if ($ldapbind ) {
	                 return true;                  
	            } else {
	                 return false;
	            }
	        }
		}else{
			return false;
		}
		
	}

	public function registrarSesion($username,$idDependencia){
		$sql="declare @res as varchar(45);
		EXECUTE [db_6E2000].[dbo].[sp_a000_01_seccion] '$username', '$idDependencia', '01',@res output;
		select @res as id_session";

		$result=$this->_db1->query($sql) or die($sql);

		return $result;
	}


	///////TABLAS PARAMETROS
	public function getModulos($id_modulo,$estado){

		$sql="select  
		a.id_modulo as id,
		a.descripcion,
		a.estado,
		case 
		when a.estado='00' then '00 - INACTIVO'
		when a.estado='01' then '01 - ACTIVO'
		end as estadoDesc
		from db_6E2000.dbo.a000_modulo a
		where a.id_modulo is not null";

		if ($id_modulo != '' ){
			$sql=$sql." and a.id_modulo = '$id_modulo'";
		}
		if ($estado != '' ){
			$sql=$sql." and a.estado = '$estado'";
		}
		
		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
	}

	public function insModulo($id_modulo,$descripcion,$estado){

		$sql="INSERT INTO db_6E2000.dbo.a000_modulo(id_modulo,descripcion,estado) VALUES('$id_modulo','$descripcion','$estado');";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updModulo($id_modulo,$descripcion,$estado){

		$sql="UPDATE db_6E2000.dbo.a000_modulo 
		SET 
		id_modulo = '$id_modulo',
		descripcion = '$descripcion',
		estado = '$estado'
		WHERE 
		id_modulo = '$id_modulo'";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function delModulo($id_modulo){
		
		$sql="delete from db_6E2000.dbo.a000_modulo 
		where
		id_modulo = '$id_modulo' ";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function getPerfiles($id_perfil,$estado,$idCuentaInd){

		$sql="select  
		a.id_perfil as id,
		a.descripcion,
		(select 
		count(*)
		from 
		db_6E2000.dbo.a000_perfil p
		inner join db_6E2000.dbo.a000_perfil_det op on op.id_perfil = p.id_perfil
		inner join db_6E2000.dbo.a000_opcion o on o.id_opcion = op.id_opcion
		where op.id_perfil = a.id_perfil
		) as totalOpcionesVinculadas,
		a.id_usuario_actualiza,
		a.fecha_actualiza,
		a.estado,
		case
		when a.estado='00' then '00 - INACTIVO'
		when a.estado='01' then '01 - ACTIVO'
		end as estadoDesc,
		(select top 1 c.id_cuenta 
		from  db_6E2000.dbo.a000_cta c
		inner join db_6E2000.dbo.a000_cta_per cp on cp.id_cuenta = c.id_cuenta
		inner join db_6E2000.dbo.a000_perfil p on p.id_perfil = cp.id_perfil
		where c.id_cuenta = '$idCuentaInd' and p.id_perfil = a.id_perfil) as idCuentaInd
		from db_6E2000.dbo.a000_perfil a
		where a.id_perfil is not null";

		if ($id_perfil != '' ){
			$sql=$sql." and a.id_perfil = '$id_perfil'";
		}
		if ($estado != '' ){
			$sql=$sql." and a.estado = '$estado'";
		}
		
		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
	}

	public function insPerfil($id_perfil,$descripcion,$id_usuario_actualiza,$estado){

		$sql="INSERT INTO db_6E2000.dbo.a000_perfil(id_perfil,descripcion,id_usuario_actualiza,fecha_actualiza,estado) VALUES('$id_perfil','$descripcion','$id_usuario_actualiza',getdate(),'$estado');";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updPerfil($id_perfil,$descripcion,$id_usuario_actualiza,$estado){

		$sql="UPDATE db_6E2000.dbo.a000_perfil 
		SET 
		id_perfil = '$id_perfil',
		descripcion = '$descripcion',
		id_usuario_actualiza = '$id_usuario_actualiza',
		estado = '$estado'
		WHERE 
		id_perfil = '$id_perfil'";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function delPerfil($id_perfil){
		
		$sql="delete from db_6E2000.dbo.a000_perfil 
		where
		id_perfil = '$id_perfil' ";
		
		$this->_db1->query($sql) or die($sql);


		$sql="delete from db_6E2000.dbo.a000_perfil_det 
		where
		id_perfil = '$id_perfil' ";
		
		$this->_db1->query($sql) or die($sql);


		$sql="delete from db_6E2000.dbo.a000_cta_per 
		where
		id_perfil = '$id_perfil' ";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function vinPerfil($id_perfil,$id_cuenta){

		$sql="INSERT INTO db_6E2000.dbo.a000_cta_per(id_perfil,id_cuenta) 
		select '$id_perfil',id_cuenta from db_6E2000.dbo.a000_cta where id_cuenta = '$id_cuenta';";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function desPerfil($id_perfil,$id_cuenta){
		
		$sql="delete from db_6E2000.dbo.a000_cta_per 
		where
		id_perfil = '$id_perfil'
		and
		id_cuenta = '$id_cuenta'";
		$this->_db1->query($sql) or die($sql);
	}

	public function getCuentas($id_cuenta,$id_cuentaArray,$id_usuario,$id_dependencia,$estado){

		$sql="select 
		a.id_cuenta as id,
		a.id_usuario,
		(select u.id  +  ' - ' + u.apellido_paterno +  ' ' + u.apellido_materno + ', ' + u.nombres from db_6E2000.dbo.a000_usuario u where u.id=a.id_usuario) as id_usuarioDesc,
		a.id_dependencia,
		(select d.id_dependencia + ' - ' + d.desc_dependencia from a000_dep d where d.id_dependencia = a.id_dependencia) as id_dependenciaDesc,
		(select 
		count(*)
		from  db_6E2000.dbo.a000_cta c
		inner join db_6E2000.dbo.a000_cta_per cp on cp.id_cuenta = c.id_cuenta
		inner join db_6E2000.dbo.a000_perfil p on p.id_perfil = cp.id_perfil
		where c.id_cuenta = a.id_cuenta
		) as totalPerfilesVinculados,
		a.clave,
		a.estado,
		case
		when a.estado='00' then '00 - INACTIVO'
		when a.estado='01' then '01 - ACTIVO'
		end as estadoDesc,
		a.contador_ingreso,
		a.ultimo_ingreso
		from db_6E2000.dbo.a000_cta a
		where a.id_cuenta is not null";

		if ($id_cuenta=='*'){
			if (count($id_cuentaArray)>0){

				$id_cuentaSerie='';
				foreach($id_cuentaArray as $item){
		 			$id_cuentaSerie.="'".$item."',";
		 		}

				$id_cuentaSerie = substr($id_cuentaSerie, 0, strlen($id_cuentaSerie) - 1 );
				$sql=$sql." and a.id_cuenta in ($id_cuentaSerie)";
			}

		}else{
			if($id_cuenta<>''){
				$sql=$sql." and a.id_cuenta = '$id_cuenta'";
			}
		}	
		if ($id_usuario != '' ){
			$sql=$sql." and a.id_usuario = '$id_usuario'";
		}
		if ($id_dependencia != '' ){
			$sql=$sql." and a.id_dependencia = '$id_dependencia'";
		}
		if ($estado != '' ){
			$sql=$sql." and a.estado = '$estado'";
		}
		
		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
	}

	public function insCuenta($id_usuario,$id_dependencia,$estado){

		$sql="INSERT INTO db_6E2000.dbo.a000_cta(id_cuenta,id_usuario,id_dependencia,estado,contador_ingreso) 
		select u.id + '$id_dependencia', u.id, '$id_dependencia','$estado','0' from db_6E2000.dbo.a000_usuario u where u.id='$id_usuario'";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updCuenta($id_cuenta,$id_usuario,$id_dependencia,$estado){

		$sql="UPDATE db_6E2000.dbo.a000_cta 
		SET 
		id_cuenta = '$id_usuario$id_dependencia',
		id_usuario = '$id_usuario',
		id_dependencia = '$id_dependencia',
		estado = '$estado'
		WHERE 
		id_cuenta = '$id_cuenta'";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function delCuenta($id_cuenta){
		
		$sql="delete from db_6E2000.dbo.a000_cta 
		where
		id_cuenta = '$id_cuenta' ";
		
		$this->_db1->query($sql) or die($sql);


		$sql="delete from db_6E2000.dbo.a000_cta_per 
		where
		id_cuenta = '$id_cuenta' ";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function getOpciones($id_opcion,$id_modulo,$estado,$idPerfilInd){

		$sql="select  
		a.id_opcion as id,
		a.opcion,
		a.id_modulo,
		(select m.descripcion from db_6E2000.dbo.a000_modulo m where m.id_modulo = a.id_modulo) as id_moduloDesc,
		a.observacion,
		a.estado,
		case
		when a.estado='00' then '00 - INACTIVO'
		when a.estado='01' then '01 - ACTIVO'
		end as estadoDesc,
		(select top 1 p.id_perfil 
		from  db_6E2000.dbo.a000_perfil p
		inner join db_6E2000.dbo.a000_perfil_det op on op.id_perfil = p.id_perfil
		inner join db_6E2000.dbo.a000_opcion o on o.id_opcion = op.id_opcion
		where p.id_perfil = '$idPerfilInd' and o.id_opcion = a.id_opcion) as idPerfilInd
		from db_6E2000.dbo.a000_opcion a
		where a.id_opcion is not null";

		if ($id_opcion != '' ){
			$sql=$sql." and a.id_opcion = '$id_opcion'";
		}
		if ($id_modulo != '' ){
			$sql=$sql." and a.id_modulo = '$id_modulo'";
		}
		if ($estado != '' ){
			$sql=$sql." and a.estado = '$estado'";
		}
		
		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
	}

	public function insOpcion($id_opcion,$opcion,$id_modulo,$observacion,$estado){

		$sql="INSERT INTO db_6E2000.dbo.a000_opcion(id_opcion,opcion,id_modulo,observacion,estado) VALUES('$id_opcion','$opcion','$id_modulo','$observacion','$estado');";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updOpcion($id_opcion,$opcion,$id_modulo,$observacion,$estado){

		$sql="UPDATE db_6E2000.dbo.a000_opcion 
		SET 
		id_opcion = '$id_opcion',
		opcion = '$opcion',
		id_modulo = '$id_modulo',
		observacion = '$observacion',
		estado = '$estado'
		WHERE 
		id_opcion = '$id_opcion'";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function delOpcion($id_opcion){
		
		$sql="delete from db_6E2000.dbo.a000_opcion 
		where
		id_opcion = '$id_opcion' ";
		
		$this->_db1->query($sql) or die($sql);


		$sql="delete from db_6E2000.dbo.a000_perfil_det 
		where
		id_opcion = '$id_opcion' ";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function vinOpcion($id_opcion,$id_perfil){

		$sql="INSERT INTO db_6E2000.dbo.a000_perfil_det(id_opcion,id_perfil) VALUES('$id_opcion','$id_perfil');";
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function desOpcion($id_opcion,$id_perfil){
		
		$sql="delete from db_6E2000.dbo.a000_perfil_det 
		where
		id_opcion = '$id_opcion'
		and
		id_perfil = '$id_perfil'";
		$this->_db1->query($sql) or die($sql);
	}

	public function getDependencias($id_dependencia,$id_dependenciaArray,$term,$estado,$estadoArray){

		
		$sql = "select 
		a.id_dependencia as id,
		a.desc_dependencia,
		a.estado 
		from a000_dep a
		where
		a.id_dependencia is not null";

		if ($id_dependencia=='*'){
			if (count($id_dependenciaArray)>0){

				$id_dependenciaSerie='';
				foreach($id_dependenciaArray as $item){
		 			$id_dependenciaSerie.="'".$item."',";
		 		}

				$id_dependenciaSerie = substr($id_dependenciaSerie, 0, strlen($id_dependenciaSerie) - 1 );
				$sql=$sql." and a.id_dependencia in ($id_dependenciaSerie)";
			}

		}else{
			if($id_dependencia<>''){
				$sql=$sql." and a.id_dependencia = '$id_dependencia'";
			}
		}	

		if ($term<>''){
			$term=strtoupper($term);
			$sql=$sql." and (a.id_dependencia like '$term%' or upper(a.desc_dependencia) like '%$term%')";
		}

		if ($estado=='*'){
			if (count($estadoArray)>0){

				$estadoSerie='';
				foreach($estadoArray as $item){
		 			$estadoSerie.="'".$item."',";
		 		}

				$estadoSerie = substr($estadoSerie, 0, strlen($estadoSerie) - 1 );
				$sql=$sql." and a.estado in ($estadoSerie)";
			}

		}else{
			if($estado<>''){
				$sql=$sql." and a.estado = '$estado'";
			}
		}	


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getAreas($id_area,$id_areaArray,$term,$id_dependencia,$id_dependenciaArray,$estado,$estadoArray){

		$sql = "select 
		a.id_area,
		a.descripcion,
		a.id_dependencia,
		a.estado
		from 
		a000_area a
		where
		a.id_area is not null";

		if ($id_area=='*'){
			if (count($id_areaArray)>0){

				$id_areaSerie='';
				foreach($id_dependenciaArray as $item){
		 			$id_areaSerie.="'".$item."',";
		 		}

				$id_areaSerie = substr($id_areaSerie, 0, strlen($id_areaSerie) - 1 );
				$sql=$sql." and a.id_area in ($id_areaSerie)";
			}

		}else{
			if($id_area<>''){
				$sql=$sql." and a.id_area = '$id_area'";
			}
		}

		if ($term<>''){
			$term=strtoupper($term);
			$sql=$sql." and (upper(a.id_area) like '$term%' or upper(a.descripcion) like '%$term%')";
		}

		if ($id_dependencia=='*'){
			if (count($id_dependenciaArray)>0){

				$id_dependenciaSerie='';
				foreach($id_dependenciaArray as $item){
		 			$id_dependenciaSerie.="'".$item."',";
		 		}

				$id_dependenciaSerie = substr($id_dependenciaSerie, 0, strlen($id_dependenciaSerie) - 1 );
				$sql=$sql." and a.id_dependencia in ($id_dependenciaSerie)";
			}

		}else{
			if($id_dependencia<>''){
				$sql=$sql." and a.id_dependencia = '$id_dependencia'";
			}
		}	

		

		if ($estado=='*'){
			if (count($estadoArray)>0){

				$estadoSerie='';
				foreach($estadoArray as $item){
		 			$estadoSerie.="'".$item."',";
		 		}

				$estadoSerie = substr($estadoSerie, 0, strlen($estadoSerie) - 1 );
				$sql=$sql." and a.estado in ($estadoSerie)";
			}

		}else{
			if($estado<>''){
				$sql=$sql." and a.estado = '$estado'";
			}
		}	

		

		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getRutasDependencia($id_ruta,$id_dependencia,$id_modulo,$estado,$estadoArray){

		$sql = "select
		b.id_ruta,
		b.id_dependencia,
		b.ruta,
		b.id_modulo,
		b.observacion,
		b.estado
		from db_6E2000.dbo.a000_ruta a
		inner join db_6E2000.dbo.a000_ruta_dep b on b.id_ruta = a.id_ruta
		where b.id_ruta is not null ";

		if ($id_ruta != '' ){
			$sql=$sql." and b.id_ruta = '$id_ruta'";
		}
		if ($id_dependencia != '' ){
			$sql=$sql." and b.id_dependencia = '$id_dependencia'";
		}
		if ($id_modulo != '' ){
			$sql=$sql." and b.id_modulo = '$id_modulo'";
		}
		

		if ($estado=='*'){
			if (count($estadoArray)>0){

				$estadoSerie='';
				foreach($estadoArray as $item){
		 			$estadoSerie.="'".$item."',";
		 		}

				$estadoSerie = substr($estadoSerie, 0, strlen($estadoSerie) - 1 );
				$sql=$sql." and b.estado in ($estadoSerie)";
			}

		}else{
			if($estado<>''){
				$sql=$sql." and b.estado = '$estado'";
			}
		}	



		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getContadoresDependencia($id_contador,$id_dependencia,$ano,$estado,$estadoArray){

		$sql = "select 
		b.id_contador,
		b.id_dependencia,
		b.observacion,
		b.contador,
		b.ano,
		b.estado
		from 
		db_6E2000.dbo.a000_cont a
		inner join db_6E2000.dbo.a000_cont_dep b on b.id_contador = a.id_contador
		where b.id_contador is not null ";

		if ($id_contador != '' ){
			$sql=$sql." and b.id_contador = '$id_contador'";
		}
		if ($id_dependencia != '' ){
			$sql=$sql." and b.id_dependencia = '$id_dependencia'";
		}
		if ($ano != '' ){
			$sql=$sql." and b.ano = '$ano'";
		}
		

		if ($estado=='*'){
			if (count($estadoArray)>0){

				$estadoSerie='';
				foreach($estadoArray as $item){
		 			$estadoSerie.="'".$item."',";
		 		}

				$estadoSerie = substr($estadoSerie, 0, strlen($estadoSerie) - 1 );
				$sql=$sql." and b.estado in ($estadoSerie)";
			}

		}else{
			if($estado<>''){
				$sql=$sql." and b.estado = '$estado'";
			}
		}	



		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}
	

	public function validarPerfilUsuario($idPerfil){
		
		$sql = "  select 
		a.id_perfil,
		b.descripcion
		from 
		db_6E2000.dbo.a000_cta_per a
		inner join db_6E2000.dbo.a000_perfil b on b.id_perfil = a.id_perfil
		where 
		a.id_cuenta in ('".$this->getId_Usuario().$this->getId_Dependencia()."')
		and b.id_perfil='".$idPerfil."'";

	
		$result=$this->_db1->query($sql) or die($sql);
	
		if ($result->rowCount()){
			return true;
		}
		else
		{
			return false;				
		}
	}

	public function getNotificaciones(){
		$sql = "select * from [db_6E2000].[dbo].[a000_not] a 
		inner join [db_6E2000].[dbo].[a000_not_u] b on a.id_notificacion = b.id_notificacion
		where b.id_usuario = '$this->id_usuario'";

		$result =$this->_db1->query($sql) or die($sql);

		return $result;
	}
	public function getTotalNotificaciones(){
		$sql = "select count(*) as total from [db_6E2000].[dbo].[a000_not] a 
		inner join [db_6E2000].[dbo].[a000_not_u] b on a.id_notificacion = b.id_notificacion
		where b.id_usuario = '$this->id_usuario'";
	
		$result =$this->_db1->query($sql) or die($sql);
		

		$total = 0;
        foreach ($result as $row) {
        	$total=$row['total'];
        }
        return $total;
	}

	

			

	public function configurarObjetoMailer($mail) { 
	
		//$this->getLibrary ( 'phpmailer/class.phpmailer' );
		//$this->getLibrary ( 'phpmailer/class.smtp' );


		//$Host = "correo-02.sunat.peru";
		//$SMTPAuth = true;
		//$Username = "vchacaliazad";
		//$Username = "fiscapro";
		//$Password = "Sunat2018";

		//$SMTPSecure = "tls";
		//$Port = 587;
		//$verify_peer = false;
		//$verify_peer_name = false;
		//$allow_self_signed = true;



		//$mail = new PHPMailer ();
		$mail->IsSMTP();
		$mail->SMTPAuth = true;
		//$mail->SMTPSecure = "tls";
		$mail->Host = "correo-01.sunat.peru";
		$mail->Port = 587;
		$mail->Username = "cobraly@sunat.gob.pe";
		$mail->Password = 'Clave2021';

		$mail->isHTML(true);                                  
		$mail->CharSet = 'UTF-8';

		$mail->SMTPOptions = array(
			    'ssl' => array(
			        'verify_peer' => false,
			        'verify_peer_name' => false,
			        'allow_self_signed' => true
			    )
		);			

		$mail->From = "cobraly@sunat.gob.pe";
		$mail->FromName = "Cobraly";

		
		return $mail;
	}

	public function setId_Usuario($id_usuario){
		$this->id_usuario=$id_usuario;
	}
	public function getId_Usuario(){
		return $this->id_usuario;
	}

	public function setId_Dependencia($id_dependencia){
		$this->id_dependencia=$id_dependencia;
	}
	public function getId_Dependencia(){
		return $this->id_dependencia;
	}




	public function getSupervisor($id_area){
		$sql = "select 
		a.*
		from 
		[db_6E2000].[dbo].[a000_usuario] a
		inner join [db_6E2000].[dbo].[a000_cta] b on b.id_usuario = a.id
		inner join [db_6E2000].[dbo].[a000_cta_per] c on c.id_cuenta = b.id_cuenta
		inner join [db_6E2000].[dbo].[a000_perfil] d on d.id_perfil = c.id_perfil
		where c.id_perfil='PERFIL_700_003'
		and a.id_area='$id_area'";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getJefe($id_area){
		$sql = "select 
		a.*
		from 
		[DB_SUNAT].[dbo].[a000_usuario] a


		where id in
		(
		 select [t12cod_jefat] from [DPO2].[dbo].[t12uorga] where [t12cod_uorga] = '$id_area'
		 union
		 select [t12cod_encar] from [DPO2].[dbo].[t12uorga] where [t12cod_uorga] = '$id_area'

		)
		";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getJefeUsuario($id_usuario){
		$sql = "
		select * from [DB_SUNAT].[dbo].[a000_usuario]  where id in ( 
		select a.jefe from [DB_SUNAT].[dbo].[a000_usuario] a where id ='$id_usuario')";

		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	

	public function getAreasDependencia($idDependencia){
		//Ruc o Razón

		$sql = "select 
		id_area,
		descripcion 
		from 
		DB_SUNAT.dbo.a000_area 
		where 
		id_dependencia='$idDependencia' and estado='01'";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getAreasSubordinadas($idArea){
		//Ruc o Razón

		$sql = "select 
		id_area, 
		descripcion 
		from 
		DB_SUNAT.dbo.a000_area 
		where 
		id_area like '$idArea' and estado='01'";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	//select2
	public function getRucCombo($ruc_razon){
		//Ruc o Razón

		$sql = "select 
		ruc,
		razon 
		from padron_final
		where
		ruc like'$ruc_razon%' or razon like '%$ruc_razon%' ";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getAreaCombo($id_desc){
		//Ruc o Razón

		$sql = "select id_area,descripcion from a000_area  
  		where 
		id_area like'$id_desc%' 
		or 
		descripcion like '%$id_desc%' ";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getUsuarioSelect2($reg_nombres){
		//Ruc o Razón

		$sql = "Select usuario.id, usuario.nombres from 
		(select 
		id, 
		apellido_paterno + ' ' + apellido_materno + ', ' + nombres  as nombres 
		from db_6E2000.dbo.a000_usuario) as usuario 
  		where 
		usuario.id like'$reg_nombres%' 
		or 
		usuario.nombres like '%$reg_nombres%'";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}
	//fin select2

	public function getUsuariosSubordinados($idUsuario,$indIncluirJefe){
		//Ruc o Razón

		$sql = "Select 
		*,
		case when id='$idUsuario' then '1' else '0' end as idUsuarioCheck
		 from [DB_SUNAT].[dbo].[a000_usuario] 
		where 
		jefe='$idUsuario' 
		and
		estado='01'";

		if ($indIncluirJefe == true){
			$sql = $sql. " or id = '$idUsuario' ";
		}
		

		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}	

	public function getDependenciaCombo($id_desc){
		//Ruc o Razón

		$sql = "select id_dependencia,desc_dependencia from [dbo].[a000_dep] 
  		where 
		id_dependencia like'$id_desc%' 
		or 
		desc_dependencia like '%$id_desc%' ";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}


	public function getAdministradoresSistema(){
		//Ruc o Razón

		$sql = "select id_dependencia,desc_dependencia from [dbo].[a000_dep] 
  		where 
		id_dependencia like'$id_desc%' 
		or 
		desc_dependencia like '%$id_desc%' ";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}


	public function validarRuc($ruc){
		//Ruc o Razón

		$sql = "select ruc from padron_final where ruc = '$ruc' ";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}



	public function getFeriados(){
		//Ruc o Razón

		$sql = "select convert(varchar,fecha)  as fecha from feriados";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}


	public function getRutaTemporal(){
		$sql="SELECT [DB_SUNAT].[dbo].[a000_ft01_ruta] ('20000001','001000')";
		
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function getDiasTransHoy($fecha){

		//$fecha="2020-01-22";
		$fecha1 = new DateTime("2020-01-22");
		$fecha2 = new DateTime(date('Y-m-d'));
		$diff = $fecha1->diff($fecha2)->days;

		return $diff;
	}


	public function getParametros($codigo){
		//Ruc o Razón

		$sql = "select 
		t1,
		t2,
		t3,
		t4
		from 
		DPO2.dbo.Parametros 
		where 
		t1='$codigo' and ssest='S'";


		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getIdParametros($codigo,$argumento){
		//Ruc o Razón

		$sql = "select 
		t1,
		t2,
		t3,
		t4
		from 
		DPO2.dbo.Parametros 
		where 
		t1='$codigo' and t2 = '$argumento' and ssest='S'";

		$result =$this->_db1->query($sql) or die($sql);
		return $result;
	}

	
}
?>