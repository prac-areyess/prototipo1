<?php 

class solicitudServicioModel extends Model{
	public function __construct(){
		parent::__construct();
	}

	public function generarId(){
		$sql="DECLARE @idSolicitudServicio varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '015001','002000','6', @idSolicitudServicio output ;
		select @idSolicitudServicio as idSolicitudServicio;";
		
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	
	
	public function getSolicitudesServicios($idSolicitudServicio,$usuReg,$fecRegIni,$fecRegFin,$usuTrabajador,$estado,$estadoArray){

		$sql="select  
		a.id,
		a.tipoSolicitud,
		a.tipoRes,
		a.rutaArchivoPdf,
		a.rutaArchivoExcel,
		a.totalDocumentos,
		a.usuReg,
		a.fecReg,
		a.usuAsigna,
		a.fecAsigna,
		a.usuTrabajador,
		a.fecTrabajador,
		a.usuCancela,
		a.fecCancela,
		a.estado,
		a.obsRegistro,
		a.obsAtencion
		from db_6E2000.cobraly.a015_solicitudServicio a
		where
		a.id is not null";

		
		if ($idSolicitudServicio != '' ){
			$sql=$sql." and a.id = '$idSolicitudServicio'";
		}

		if ($usuReg != '' ){
			$sql=$sql." and a.usuReg = '$usuReg'";
		}

		if (strtotime(str_replace('/', '-', $fecRegIni)) and strtotime(str_replace('/', '-', $fecRegFin))){

			$fecRegIni=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegIni)));
			$fecRegFin=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegFin)));

			$sql=$sql." and a.fecReg between '".$fecRegIni." 00:00:00' and '".$fecRegFin." 23:59:59'";
		}

		if ($usuTrabajador != '' ){
			$sql=$sql." and a.usuTrabajador = '$usuTrabajador'";
		}		
		
		
		if ($estado=='*'){
			if (count($estadoArray)>0){

				$estadoSerie='';
				foreach($estadoArray as $item){
		 			$estadoSerie.="'".$item."',";
		 		}

				$estadoSerie = substr($estadoSerie, 0, strlen($estadoSerie) - 1 );
				$sql=$sql." and a.estado in ($estadoSerie)";
			}

		}else{
			if($estado<>''){
				$sql=$sql." and a.estado = '$estado'";
			}
		}	

		$sql=$sql." order by a.id desc";

		//echo $sql;
		


		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}



	public function insSolicitudServicio($idSolicitudServicio,$tipoSolicitud,$tipoRes,$rutaArchivoPdf,$rutaArchivoExcel,$totalDocumentos,$usuReg,$estado,$obsRegistro,$obsAtencion){

		//$razonSocial = str_replace("'", "''", $razonSocial);
		
		$sql="INSERT INTO db_6E2000.cobraly.a015_solicitudServicio(
		id,tipoSolicitud,tipoRes,rutaArchivoPdf,rutaArchivoExcel,totalDocumentos,usuReg,fecReg,estado,obsRegistro,obsAtencion) VALUES	('$idSolicitudServicio','$tipoSolicitud','$tipoRes','$rutaArchivoPdf','$rutaArchivoExcel','$totalDocumentos','$usuReg',getdate(),'$estado','$obsRegistro','$obsAtencion');";

		
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updSolicitudServicio($idAduanaLlamada,$fecLlamada,$telefono,$razonSocial,$apellidoPaterno,$apellidoMaterno,$nombres,$cargo,$contribuyenteContactado,$resultadoLlamada,$resultadoNegociacion,$tipoLLamada,$observacion,$expCoactivo,$rcEmbargo,$respuesta,$fecEstimadaEntrega,$usuMod,$estado){

		// $sql="UPDATE db_6E2000.dbo.a012_aduanaLlamada 
		// SET 
		// telefono = '$telefono',
		// razonSocial = '$razonSocial',
		// apellidoPaterno = '$apellidoPaterno',
		// apellidoMaterno = '$apellidoMaterno',
		// nombres = '$nombres',
		// cargo = '$cargo',
		// contribuyenteContactado = '$contribuyenteContactado',
		// resultadoLlamada = '$resultadoLlamada',
		// resultadoNegociacion = '$resultadoNegociacion',
		// tipoLLamada = '$tipoLLamada',
		// observacion = '$observacion',
		// expCoactivo = '$expCoactivo',
		// rcEmbargo = '$rcEmbargo',
		// respuesta = '$respuesta',
		// fecEstimadaEntrega = '$fecEstimadaEntrega',
		// fecMod = getdate(),
		// usuMod = '$usuMod',
		// estado = '$estado'
		// WHERE 
		// id = '$idAduanaLlamada'";
		// //echo $telefono;
		
		// $this->_db1->query($sql) or die($sql);
	}
	
	public function asiSolicitudServicio($idSolicitudServicio,$usuAsigna,$usuTrabajador){

		$sql="UPDATE db_6E2000.cobraly.a015_solicitudServicio 
		SET 
		usuAsigna = '$usuAsigna',
		fecAsigna = getdate(),
		usuTrabajador = '$usuTrabajador',
		estado = '02'				
		WHERE 
		id = '$idSolicitudServicio'";
				
		$this->_db1->query($sql) or die($sql);
	}

	public function conSolicitudServicio($idSolicitudServicio,$obsAtencion){

		$sql="UPDATE db_6E2000.cobraly.a015_solicitudServicio 
		SET 
		obsAtencion = '$obsAtencion',
		estado = '03',
		fecCancela = getdate()				
		WHERE 
		id = '$idSolicitudServicio'";
				
		$this->_db1->query($sql) or die($sql);
	}


	public function delSolicitudServicio($idSolicitudServicio){
		
		$sql="UPDATE db_6E2000.cobraly.a015_solicitudServicio  
		SET 
		estado='DE' 
		WHERE 
		id = '$idSolicitudServicio' ";
		
		
		$this->_db1->query($sql) or die($sql);


	}

	public function getEstadisticos(){
		
		$sql="select
			(select count(estado) from db_6E2000.cobraly.a015_solicitudServicio where estado = '01') as pendientes,
			(select count(estado) from db_6E2000.cobraly.a015_solicitudServicio where estado = '03') as concluidas
			";
		
	
		$this->_db1->query($sql) or die($sql);


	}

	

	



	
}
?>