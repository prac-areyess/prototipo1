/* *** Referencias de busqueda
*** manejo de puppeteer https://www.adictosaltrabajo.com/2020/02/27/testing-funcional-con-puppeteer/
*** delay https://stackoverflow.com/questions/14249506/how-can-i-wait-in-node-js-javascript-l-need-to-pause-for-a-period-of-time

*/
console.log('\x1b[44m', '*******************************************************************************************************************');
console.log('');
console.log('\x1b[43m', '\t\t\t\t\t\t  INTENDENCIA REGIONAL - LIMA  ');
console.log('\x1b[41m', '\t\t\t\t\t\t GERENCIA DE COBRANZA COACTIVA ');
console.log('\x1b[42m', '\t\t\t\t\t\t  SUPERVISION DE PROGRAMACIÓN  ');
console.log('');
console.log("\x1b[44m", '******************************************************************************************************************');
console.log('\x1b[40m', '');
console.log('\x1b[41m', 'RECOMENDACIONES:');
console.log('\x1b[40m', '');
console.log('\x1b[41m', 'En la carpeta debe estar el archivo Excel "DATA_GENERAL.xlsx" y los archivos usuario.txt y contraseña.txt del Intranet');
console.log('\x1b[40m', 'Programador: Victor Santiago');
// console.log('\x1b[40m','Descripción: El presente programa descargará el último Recibo por Honorarios generado por el Contribuyente');
console.log('\x1b[40m', 'Descripción: El programa descargará la CONSULTA PARA OBTENER LA TITULARIDAD DE LOS BIENES PERSONA JURIDICA-SUNARP PIDE');
console.log('\x1b[40m', '');
//--->
//const fs = require('fs');
//
//-->

// const puppeteer = require('puppeteer-core');
const puppeteer = require('puppeteer-core')
// const StealthPlugin = require('puppeteer-extra-plugin-stealth')
// puppeteer.use(StealthPlugin())
// const AdblockerPlugin = require('puppeteer-extra-plugin-adblocker')
// puppeteer.use(AdblockerPlugin({ blockTrackers: true }))
const { PendingXHR } = require('pending-xhr-puppeteer');
var XLSXZ = require("xlsx")
var xlsx = require("xlsx")
// var excel = require('excel4node');
// const querystring = require('querystring')
let fs = require("fs");//Lectura de archivos txt
const util = require('util'); //Esto implementa el utilmódulo Node.js para entornos que no lo tienen, como los navegadores.
// const mkdirp = require('mkdirp');
// const path = require('path');
const readFile = util.promisify(fs.readFile); //generamos una promesa del archivo txt
let os = require("os");
const { Console } = require('console');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
let maquina = os.hostname()
let usuarioMaquina = os.userInfo().username.toUpperCase()
var dir = process.cwd();
var fecha_hoy = new Date();
var dd = fecha_hoy.getDate();
var mm = fecha_hoy.getMonth() + 1;
var yyyy = fecha_hoy.getFullYear();
var hora = fecha_hoy.getHours();
var minu = fecha_hoy.getMinutes();
var segu = fecha_hoy.getSeconds();
if (dd < 10) dd = '0' + dd;
if (mm < 10) mm = '0' + mm;
if (hora < 10) hora = '0' + hora;
if (minu < 10) minu = '0' + minu;
if (segu < 10) segu = '0' + segu;
fecha_hoy = dd + '_' + mm + '_' + yyyy + '_' + hora + 'H_' + minu + 'M_' + segu + 'S';
var solo_fecha = dd + '_' + mm + '_' + yyyy
const path = require('path');
const logFile = fs.createWriteStream(path.join(__dirname, 'log.txt'), { flags: 'a' });
/*
console.log = function(message) {  
    console.log(message)  
    logFile.write(new Date().toISOString() + ' - ' + message + '\n');
    process.stdout.write(message + '\n');
  };
*/
if (yyyy == '2024' || yyyy == '2025') {
    var dir_resultado = './RESULTADO_DESCARGA_SUNARP_' + String(usuarioMaquina) + '_' + fecha_hoy;
    // var carpetaAcumulada = 'CPE_GE_'+String(usuarioMaquina)+'_'+fecha_hoy;
    if (!fs.existsSync(dir_resultado)) {
        fs.mkdirSync(dir_resultado);
    }
    (async () => { //Declaramos el async
        const browser = await puppeteer.launch({
            executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', headless: true, defaultViewport: null,
            args: [
                '--no-sandbox', //Para utilizar con Chromium
                '--disable-setuid-sandbox',//Para utilizar con Chromium
                '--start-maximized',  // Pagina maximizada
                '--aggressive-cache-discard']
        });
        const page = await browser.newPage(); //Abrimos una nueva pagina de chrome
        const pendingXHR = new PendingXHR(page);// clase que le permite esperar a que se completen las solicitudes AJAX en Puppeteer
        const usuario = await readFile('usuario.txt', 'utf-8');//Leemos el txt de usuario intranet
        const contrasena = await readFile('contraseña.txt', 'utf-8');

        console.log("===>Abriendo el Intranet...");
        //await page.goto("http://intranet.sunat.peru/cl-at-iamenu/menuS01Alias?accion=autenticar&cuenta="+usuario+"&password="+contrasena+"",{waitUntil: 'networkidle0', timeout: 120000}).then(() => console.log("===>Abrió el Intranet")).catch((e) => console.log("PELIGRO!!! :No abrió el Intranet => "+e)); 
        await page.goto("http://intranet.sunat.peru/cl-at-iamenu/", { waitUntil: 'networkidle0', timeout: 120000 }).then(() => console.log("===>Abrió el Intranet")).catch((e) => console.log("PELIGRO!!! :No abrió el Intranet => " + e));
        // Seleccionamos del input de usuario
        const username = await page.$("[name=cuenta]");
        // Se hace focus sobre el elemento
        await username.focus();
        // Simulamos el teclado
        await page.keyboard.type(usuario);
        //console.log(usuario);
        // Pasamos el focus al siguiente elemento
        await page.keyboard.press("Tab");
        // Simulamos el teclado
        await page.keyboard.type(contrasena);
        //console.log(contrasena);
        // Pulsamos enter
        await page.keyboard.press("Enter");

        await page.waitForResponse(response => response.ok())
        await page.waitForTimeout(1000); //Esperamos un segundo   
        await page.goto("http://intranet.sunat.peru/cl-at-iamenu/menuS03Alias?accion=invocarPrograma&programa=5:5.14.15", { waitUntil: 'networkidle0', timeout: 120000 }).then(() => console.log("===>Abrió la Consulta SUNARP PIDE")).catch((e) => console.log("PELIGRO!!! :No Abrió la Consulta SUNARP PIDE => " + e));
        //await page.waitForTimeout(3000); //Esperamos un segundo   
        //await page.waitForResponse(response => response.ok())
        console.log("===>...");
        function waitForFrame(page) {
            let fulfill;
            const promise = new Promise(x => fulfill = x);
            checkFrame();
            return promise;

            function checkFrame() {
                const frame = page.frames().find(f => f.url().includes('menuSistema'));
                if (frame)
                    fulfill(frame);
                else
                    page.once('framenavigated', checkFrame);
            }
        }
        function waitForFrames(page) {
            let fulfill;
            const promise = new Promise(x => fulfill = x);
            checkFrame();
            return promise;

            function checkFrame() {
                const frame = page.frames().find(f => f.url().includes('programaSistema'));
                if (frame)
                    fulfill(frame);
                else
                    page.once('framenavigated', checkFrame);
            }
        }
        function waitForFramez(page) {
            let fulfill;
            const promise = new Promise(x => fulfill = x);
            checkFrame();
            return promise;
            function checkFrame() {
                const frame = page.frames().find(f => f.url().includes('/cl-ti-iaconsultasunarp'));
                if (frame)
                    fulfill(frame);
                else
                    page.once('framenavigated', checkFrame);
            }
        }

        function ingresointranet(page) {

        }
        //console.log('ssasas');
        const frame_menu = await waitForFrame(page);
        //console.log('opop');
        await frame_menu.waitForSelector("[id='5.14.15.1']");//
        //console.log('mlml');
        await frame_menu.click("[id='5.14.15.1']")
        //console.log('mlml_click');
        await frame_menu.waitForSelector("[id='5.14.15.1M'] > li:nth-child(2) > a ");//
        //console.log('mlml_1');
        await frame_menu.click("[id='5.14.15.1M'] > li:nth-child(2) > a ")
        console.log('mlml_click_1');
        // {visible:true, timeout: 300000}
        // await page.waitForTimeout(4000); //Esperamos un segundo   
        var frame_dets = await waitForFrames(page);
        console.log("===>...");
        // await page.waitForTimeout(4000);
        console.log('===>....');
        //Esperamos un segundo   
        var frame_det = await waitForFramez(page);
        console.log("===>Cargando la página...");
        // console.log('zaaaaaaaaa');
        var mensaje_de_resultado = '-'
        page.on('response', async (response) => {
            const status = response.status();
            // console.log(status);
            console.log("Response status -->")
            console.log(status)
            if (response.url().includes('buscarTitularidadBienesPJ') && status == 200) {
                console.log('===>Data Encontrada');
                try{                    
                    mensaje_de_resultado = await response.json();
                    // console.log(mensaje_de_resultado);
                } catch (error) {
                    mensaje_de_resultado = '-'
                    console.error(error)
                    console.log("revisar Error -page.on linea 180")
                }
            }
        });
        
        const workbookz = XLSXZ.readFile('DATA_GENERAL.xlsx');//Tomamos el archivos Excel Data de las Solicitudes
        const sheet_name_listz = workbookz.SheetNames;//Creamos una lista de las hojas que tenga el archivo Excel
        let dataz = XLSXZ.utils.sheet_to_json(workbookz.Sheets[sheet_name_listz[0]])//Tomamos la primera hojda del archivo Excel
        let first_sheet_namez = workbookz.SheetNames[0];
        let worksheetz = workbookz.Sheets[first_sheet_namez];
        let filaresuli = 1;
        let filaresulf = 1;
        XLSXZ.utils.sheet_add_aoa(worksheetz, [['OBSERVACION_RESULTADO']], { origin: 'G1' });
        XLSXZ.utils.sheet_add_aoa(worksheetz, [['CANTIDAD_BIENES']], { origin: 'H1' });
        XLSXZ.writeFile(workbookz, dir_resultado + '\\' + 'RESULTADO_DESCARGA_SUNARP_' + String(usuarioMaquina) + "_" + String(maquina) + "_" + String(fecha_hoy) + '.xlsx');
        var objeto = [];
        var resultadob = [];
        let cont = 0;
        for (let j = 0; j < dataz.length; j++) {

            //await page.waitForTimeout(1000);
            delay(1000);
            let casos = Object.values(dataz[j]);//Formamos una lista con cada fila iterada
            var rucConsulta = casos[0];
            var indTipoC = casos[1].toString();
            var nombreB = ''
            if (indTipoC == '2') {
                var nombreRUC = casos[2].toUpperCase().replaceAll("&","%26");
                nombreB = nombreRUC
                console.log("*********************************************** CASO: " + String(j + 1) + " DE " + String(dataz.length) + " **********************************************");
                console.log(nombreRUC);
                try {
                    await page.goto("http://intranet.sunat.peru/cl-ti-iaconsultasunarp/titularidadBienesCtrl?action=buscarTitularidadBienesPJ&tipoParticipante=J&apellidoPaterno=&apellidoMaterno=&nombres=&razonSocial=" + String(nombreRUC) + "", { waitUntil: 'networkidle0', timeout: 120000 }).then(() => console.log("===>Cargó la consulta de Sunarp PIDE")).catch((e) => console.log("PELIGRO!!! :No Abrió la Consulta SUNAP PIDE => " + e));
                  } catch (error) {
                    console.error(error);
                  }
                  console.log("okPJ")
            } else {
                //await page.waitForTimeout(1000);
                //delay(1000);
                //let casos = Object.values(dataz[j]);//Formamos una lista con cada fila iterada 
                var apePatConsulta = casos[2];
                var apeMatConsulta = casos[3];
                var nombreConsulta = casos[4];
                nombreB = apePatConsulta + ' ' + apeMatConsulta + ' ' + nombreConsulta
                console.log("*********************************************** CASO: " + String(j + 1) + " DE " + String(dataz.length) + " **********************************************");
                try {
                    await page.goto("http://intranet.sunat.peru/cl-ti-iaconsultasunarp/titularidadBienesCtrl?action=buscarTitularidadBienesPJ&tipoParticipante=N&apellidoPaterno=" + String(apePatConsulta) + "&apellidoMaterno=" + String(apeMatConsulta) + "&nombres=" + String(nombreConsulta) + "&razonSocial=", { waitUntil: 'networkidle0', timeout: 120000 }).then(() => console.log("===>Cargó la consulta de Sunarp PIDE")).catch((e) => console.log("PELIGRO!!! :No Abrió la Consulta de Recibos por Honorarios => " + e));
                }catch (error) {
                    console.error(error);
                  }
                console.log("okPN")
            }
            delay(1000);

            // console.log(mensaje_de_resultado);
            // console.log(typeof(mensaje_de_resultado['lstTitularidadBienes'][0]));
            // console.log(mensaje_de_resultado['lstTitularidadBienes']);
            // console.log('iiiiiiiiiiiiiii');
            console.log("CodigoError --->")
            console.log(mensaje_de_resultado['codigoError'])
            console.log("<---")

            if (mensaje_de_resultado['codigoError'] != '0' && cont <= 3) {
                console.log("===>Descarga con error");
                XLSXZ.utils.sheet_add_aoa(worksheetz, [['NO TIENE INFORMACION EN SUNARP']], { origin: 'G' + (j + 2) })
                XLSXZ.utils.sheet_add_aoa(worksheetz, [['0']], { origin: 'H' + (j + 2) });
                XLSXZ.writeFile(workbookz, dir_resultado + '\\' + 'RESULTADO_DESCARGA_SUNARP_' + String(usuarioMaquina) + "_" + String(maquina) + "_" + String(fecha_hoy) + '.xlsx');
                cont = cont + 1
                j = j - 1
                console.log("Busqueda no exitosa--Error --->")
                console.error();
                console.log(nombreB)
                console.log("<---")
                continue
            }
            if ((mensaje_de_resultado['lstTitularidadBienes'] == '[]' || mensaje_de_resultado == '-' )&& cont <= 3) {
                console.log("===>El RUC no tiene informacion de SUNARP");
                XLSXZ.utils.sheet_add_aoa(worksheetz, [['NO TIENE INFORMACION EN SUNARP']], { origin: 'G' + (j + 2) })
                XLSXZ.utils.sheet_add_aoa(worksheetz, [['0']], { origin: 'H' + (j + 2) });
                XLSXZ.writeFile(workbookz, dir_resultado + '\\' + 'RESULTADO_DESCARGA_SUNARP_' + String(usuarioMaquina) + "_" + String(maquina) + "_" + String(fecha_hoy) + '.xlsx');
                cont = cont + 1
                j = j - 1
                console.log("Busqueda no exitosa--[] --->")
                console.error();
                console.log(nombreB)
                console.log("<---")
                continue
            }
            if (cont > 3) {
                cont = 0
                continue
            }
            cont = 0
            // console.log(mensaje_de_resultado['lstTitularidadBienes']);
            let final = JSON.parse(mensaje_de_resultado['lstTitularidadBienes'])
            //console.log(final);
            let cantidad_bienes = Object.keys(final).length
            console.log('===>' + nombreB + '===> Cantidad de Bienes: ' + String(cantidad_bienes)); //
            objeto = objeto.concat(final)
            // obj = obj.concat(final)
            //console.log(objeto)
            var newWB = xlsx.utils.book_new();
            var wsInteresOk = xlsx.utils.json_to_sheet(final, { skipHeader: false, origin: "A1" });
            xlsx.utils.book_append_sheet(newWB, wsInteresOk, 'SUNARP')
            xlsx.writeFile(newWB, dir_resultado + "/" + rucConsulta + ".xlsx")

            XLSXZ.utils.sheet_add_aoa(worksheetz, [['SI TIENE INFORMACION EN SUNARP']], { origin: 'G' + (j + 2) });
            XLSXZ.utils.sheet_add_aoa(worksheetz, [[String(cantidad_bienes)]], { origin: 'H' + (j + 2) });
            XLSXZ.writeFile(workbookz, dir_resultado + '\\' + 'RESULTADO_DESCARGA_SUNARP_' + String(usuarioMaquina) + "_" + String(maquina) + "_" + String(fecha_hoy) + '.xlsx');

            console.log('===>Descargando el Excel...')
            var newWB = xlsx.utils.book_new();
            var wsInteresOk = xlsx.utils.json_to_sheet(objeto, { skipHeader: false, origin: "A1" });
            xlsx.utils.sheet_add_aoa(wsInteresOk, [['RUC_Busq']], { origin: 'N1' });

            filaresulf = filaresuli + cantidad_bienes
            resultadob.push({
                'Nombre': rucConsulta,
                'FilaI': filaresuli + 1,
                'FilaF': filaresulf
            })
            filaresuli = filaresulf
            for (let k = 0; k < resultadob.length; k++) {
                for (let r = resultadob[k].FilaI; r <= resultadob[k].FilaF; r++) {
                    xlsx.utils.sheet_add_aoa(wsInteresOk, [[resultadob[k].Nombre]], { origin: 'N' + r });
                }
            }
            xlsx.utils.book_append_sheet(newWB, wsInteresOk, 'SUNARP')
            xlsx.writeFile(newWB, dir_resultado + "/TOTAL_DESCARGA_SUNARP_" + String(fecha_hoy) + ".xlsx")
            console.log(resultadob[0].Nombre)
            console.log('length resultadob')
            console.log(resultadob.length)
        }

        console.log("=============================> EL PROGRAMA HA FINALIZADO <=======================================");

        console.log("Programador: Victor Santiago - NN96");
        await page.close();
        await browser.close();
    })();

} else {
    console.log("===>No estas autorizado para usar el programa.......................");
}
