import os
import shutil

def crear_carpeta(directorio_base, nombre_carpeta):
    
    directorio_final = os.path.join(directorio_base, nombre_carpeta)

    if os.path.exists(directorio_final):
        print('El directorio ya existe.')
        return directorio_final
    else:
        os.mkdir(directorio_final)
        return directorio_final

def mover_y_renombrar_archivo(ruta_origen, ruta_destino, nuevo_nombre):
    # Asegurarse de que el directorio de destino existe
    if not os.path.exists(ruta_destino):
        os.makedirs(ruta_destino)

    # Construir la ruta completa del archivo de destino con el nuevo nombre
    ruta_destino_completa = os.path.join(ruta_destino, nuevo_nombre)

    # Mover y renombrar el archivo
    shutil.move(ruta_origen, ruta_destino_completa)

    return ruta_destino_completa

def leer_contenido_archivo(directorio_base, nombre_archivo):
    directorio_final = os.path.join(directorio_base, nombre_archivo)

    with open(directorio_final, 'r', encoding='utf-8') as file:
        contenido = file.read()
        return contenido