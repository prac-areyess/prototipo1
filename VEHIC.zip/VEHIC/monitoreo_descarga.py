import os
import time

def descarga_completa_boleta(directorio_base, timeout=180):
    start_time = time.time()

    while True:
        lista_elementos = os.listdir(directorio_base)

        # Buscar el primer archivo PDF en el directorio
        documento_pdf = next((documento for documento in lista_elementos if documento.lower().endswith(".pdf")), None)

        if documento_pdf:
            file_path = os.path.join(directorio_base, documento_pdf)
            if os.path.exists(file_path):
                return file_path

        if time.time() - start_time > timeout:
            raise TimeoutError('Descarga fuera de tiempo.')

        time.sleep(3)