from selenium import webdriver
from selenium.webdriver.common.keys import Keys #Teclas
from selenium.webdriver.common.by import By #Comodines By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException #
from selenium.webdriver.chrome.options import Options #Para configurar modo oculto Chrome


class ServiceSelenium:

    def __init__(self, ruta_chrome, directorio_descarga) -> str:
        self.chrome_options = Options()
        self.service = Service(ruta_chrome)
        
        # self.chrome_options.add_argument('--headless') #Segundo Plano
        
        # options.add_argument("--headless")
        # self.chrome_options.add_argument("--window-size=1920,1080")

        prefs = {"download.default_directory": directorio_descarga}
        self.chrome_options.add_experimental_option("prefs", prefs)

        self.driver = webdriver.Chrome(service=self.service, options=self.chrome_options)

        # self.driver = webdriver.Chrome(service=self.service)
        self.driver.maximize_window()

    def navegar_a_sunarp(self, URL):
        try:
            self.driver.get(URL)
        except NameError as e:
            print(e)
    
    def cerrar_navegador(self):
        self.driver.quit()

    def refrescar_pagina(self):
        self.driver.refresh()

    def clickear_boton_cierre(self, tipo_selector:str , selector:str, tiempo = 30):
        try:
            if tipo_selector.lower() == "xpath":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.XPATH, selector))
                )
            if tipo_selector.lower() == "css_selector":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                )
                
            elemento.click()
            return True
        except ElementClickInterceptedException as e:
            print(f'Error al interactuar con el elemento: {selector}')
            return False
            # self.cerrar_navegador()

        except TimeoutException as e:
            print(f'El tiempo de espera para el elemento {selector} a sido superado')
            return False
            # self.cerrar_navegador()
        
    
    def clickear_elemento(self, tipo_selector:str , selector:str, tiempo = 30):
        try:
            if tipo_selector.lower() == "xpath":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.XPATH, selector))
                )
            if tipo_selector.lower() == "css_selector":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                )
                
            elemento.click()
        except ElementClickInterceptedException as e:
            print(f'Error al interactuar con el elemento: {selector}')
            self.cerrar_navegador()

        except TimeoutException as e:
            print(f'El tiempo de espera para el elemento {selector} a sido superado')
            self.cerrar_navegador()

    def clickear_elemento_JavaScript(self, tipo_selector:str , selector:str, tiempo = 30):
        try:
            if tipo_selector.lower() == "xpath":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.XPATH, selector))
                )
            if tipo_selector.lower() == "css_selector":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                )
                
            self.driver.execute_script("arguments[0].click();", elemento)

        except ElementClickInterceptedException as e:
            print(f'Error al interactuar con el elemento: {selector}')
            self.cerrar_navegador()

        except TimeoutException as e:
            print(f'El tiempo de espera para el elemento {selector} a sido superado')
            self.cerrar_navegador()
    
    def escribir_texto(self,tipo_selector, selector, texto, tiempo = 30):
        try:
            if tipo_selector.lower() == "xpath":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.XPATH, selector))
                )
            if tipo_selector.lower() == "css_selector":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                )
                
            elemento.send_keys(texto)
        except NameError as e:
            print(e)
    
    def presionar_tecla(self,tipo_selector, selector, tecla, tiempo = 30):
        try:
            if tecla.lower() == 'enter':
                if tipo_selector.lower() == "xpath":
                    elemento = WebDriverWait(self.driver, tiempo).until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )

                if tipo_selector.lower() == "css_selector":
                    elemento = WebDriverWait(self.driver, tiempo).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )

                elemento.send_keys(Keys.ENTER)
            
            if tecla.lower() == 'escape':
                if tipo_selector.lower() == "xpath":
                    elemento = WebDriverWait(self.driver, tiempo).until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )

                if tipo_selector.lower() == "css_selector":
                    elemento = WebDriverWait(self.driver, tiempo).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )

                elemento.send_keys(Keys.ESCAPE)


        except NameError as e:
            print(e)

    def capturar_elemento(self, tipo_selector, selector, nombre_archivo, tiempo=30):
        try:
            if tipo_selector.lower() == "xpath":
                    elemento = WebDriverWait(self.driver, tiempo).until(
                        EC.presence_of_element_located((By.XPATH, selector))
                    )

            if tipo_selector.lower() == "css_selector":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                )

            elemento.screenshot(nombre_archivo)
            #print(f"Captura de pantalla guardada como {nombre_archivo}")
        except TimeoutException as e:
            print(f"Error: {e}")
    

    def capturar_texto(self, tipo_selector, selector, tiempo=30):
        try:
            if tipo_selector.lower() == "xpath":
                    elemento = WebDriverWait(self.driver, tiempo).until(
                        EC.presence_of_element_located((By.XPATH, selector))
                    )

            if tipo_selector.lower() == "css_selector":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                )

            return elemento.text if elemento else None  
            #print(f"Captura de pantalla guardada como {nombre_archivo}")
        except TimeoutException as e:
            print(f'')
            #print(f'Tiempo de espera para obtener el texto {selector} ha sido superado')
    
    def limpiar_campo_texto(self,tipo_selector, selector, tiempo = 30):
        try:
            if tipo_selector.lower() == "xpath":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.XPATH, selector))
                )
            if tipo_selector.lower() == "css_selector":
                elemento = WebDriverWait(self.driver, tiempo).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                )
                
            elemento.clear()
        except NameError as e:
            print(e)
    
    def obtener_elementos(self, tipo_selector:str , selector:str, tiempo = 30):
        try:
            if tipo_selector.lower() == "xpath":
                elementos = WebDriverWait(self.driver, tiempo).until(
                    EC.presence_of_all_elements_located((By.XPATH, selector))
                )
            if tipo_selector.lower() == "css_selector":
                elementos = WebDriverWait(self.driver, tiempo).until(
                    EC.presence_of_all_elements_located((By.CSS_SELECTOR, selector))
                )
                
            return elementos
        except TimeoutException as e:
            return False

