import pandas as pd
from pywinauto.application import Application
import time

def leer_credenciales(ruta_txt):
    with open(ruta_txt, 'r') as f:
        usuario, contrasena = f.readline().strip().split(',')
    return usuario, contrasena

def leer_expedientes(ruta_excel):
    return pd.read_excel(ruta_excel)

def procesar_expedientes(expedientes, usuario, contrasena):
    # Lanzar RSIRAT (ajusta la ruta al ejecutable)
    app = Application(backend="uia").start(r"C:\Ruta\A\RSIRAT.exe")
    time.sleep(5)  # Esperar que cargue

    # Iniciar sesión
    dlg = app.window(title_re=".*Login.*")
    dlg['UsuarioEdit'].set_text(usuario)
    dlg['ContraseñaEdit'].set_text(contrasena)
    dlg['IngresarButton'].click()
    time.sleep(3)

    for idx, exp in expedientes.iterrows():
        nro_exp = str(exp['EXPEDIENTE'])
        tipo_medida = str(exp['TIPO DE MEDIDA'])
        resultado = ""

        # Navegar por los menús usando nombres de controles
        main_win = app.window(title_re=".*RSIRAT.*")
        main_win['Cobranza Coactiva'].click_input()
        main_win['Exp. Cob. Coactiva - Individual'].double_click_input()
        time.sleep(2)

        # Ingresar número de expediente
        exp_win = app.window(title_re=".*Selección de Expediente Coactivo.*")
        exp_win['NúmeroEdit'].set_text(nro_exp)
        exp_win['BuscarButton'].click()
        time.sleep(2)

        # Verificar campo "Grupo"
        grupo = exp_win['GrupoEdit'].window_text()
        if not grupo.strip():
            resultado = "Sin ejecutor asignado"
            expedientes.at[idx, 'RESULTADO'] = resultado
            continue

        exp_win['AceptarButton'].click()
        time.sleep(1)

        # Proceso de embargo según tipo de medida
        main_win['Proceso de Embargo'].click_input()
        main_win['Trabar Embargo'].click_input()
        time.sleep(2)

        if tipo_medida == "IEI":
            main_win['IEIOption'].click_input()
            time.sleep(2)
            # Paso 11: Ingresar INTERVENTOR y PLAZO
            iei_win = app.window(title_re=".*Trabar Intervención en Información.*")
            iei_win['InterventorEdit'].set_text(str(exp['INTERVENTOR']))
            iei_win['InterventorEdit'].type_keys('{TAB}')
            time.sleep(1)
            iei_win['PlazoEdit'].set_text(str(exp['PLAZO']))
            time.sleep(1)
            iei_win.type_keys('%A')  # Alt + A para aceptar
            time.sleep(2)
            # Paso 12: Grabar resolución
            grabar_win = app.window(title_re=".*Grabar Resolución.*")
            grabar_win.type_keys('%S')  # Alt + S para grabar
            resultado = "Intervención en Información emitida"
        elif tipo_medida == "DSE":
            main_win['DSEOption'].click_input()
            resultado = "Depósito Sin Extracción emitido"
        elif tipo_medida == "IER":
            main_win['IEROption'].click_input()
            resultado = "Intervención en Recaudación emitida"
        else:
            resultado = "Tipo de medida no procesado"
            continue

        expedientes.at[idx, 'RESULTADO'] = resultado

    expedientes.to_excel("expedientes.xlsx", index=False)

if __name__ == "__main__":
    ruta_txt = "credenciales.txt"
    ruta_excel = "expedientes.xlsx"
    usuario, contrasena = leer_credenciales(ruta_txt)
    expedientes = leer_expedientes(ruta_excel)
    procesar_expedientes(expedientes, usuario, contrasena)